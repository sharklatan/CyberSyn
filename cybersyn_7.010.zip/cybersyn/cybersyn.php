<?php
/*
  Plugin Name: CyberSEO Lite
  Version: 7.010
  Author: CyberSEO.net
  Author URI: https://www.cyberseo.net/
  Plugin URI: https://www.cyberseo.net/cyberseo-lite/
  Description: CyberSEO Lite (aka CyberSyn) is a simplified version of CyberSEO Pro - the most advanced and easy-to-use autoblogging and content curation plugin for WordPress.
 */
if (!defined('ABSPATH')) {
    require_once('../../../wp-config.php');
    status_header(404);
    nocache_headers();
    include(get_404_template());
    exit();
}
define('CSYN_MAX_CURL_REDIRECTS', 10);
define('CSYN_POST_LIFE_CHECK_PERIOD', 3600);
define('CSYN_CURL_USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:97.0) Gecko/20100101 Firefox/97.0/3871tuT2p1u-81');
define('CSYN_HIDE_PASSWORDS', false);
define('CSYN_AMAZON_TAG', 'cxxx_amazon_tag');
define('CSYN_FULL_TEXT_EXTRACTOR', 'cxxx_full_text_extractor');
define('CSYN_POST_IMAGES', 'cxxx_post_images');
define('CSYN_URLS_NOFOLLOW', 'cxxx_urls_nofollow');
define('CSYN_URLS_NOREFERRER', 'cxxx_urls_noreferrer');
define('CSYN_URLS_ENCRYPT', 'cxxx_urls_encrypt');
define('CSYN_URLS_TARGET_BLANK', 'cxxx_urls_target_blank');
define('CSYN_FEED_OPTIONS', 'cxxx_feed_options');
define('CSYN_FEEDS_UPDATED', 'cxxx_feeds_updated');
define('CSYN_SYNDICATED_FEEDS', 'cxxx_syndicated_feeds');
define('CSYN_RSS_PULL_MODE', 'cxxx_rss_pull_mode');
define('CSYN_CRON_MAGIC', 'cxxx_cron_magic');
define('CSYN_RAND_SHA', 'cxxx_rand_sha');
define('CSYN_PSEUDO_CRON_INTERVAL', 'cxxx_pseudo_cron_interval');
define('CSYN_DO_UPGRADE', 'cxxx_do_upgrade');
define('CSYN_DISABLE_DUPLICATION_CONTROL', 'cxxx_disable_feed_duplication_control');
define('CSYN_ENABLE_DEBUG_MODE', 'cxxx_enable_debug_mode');
define('CSYN_SORT_FEED_SOURCES', 'cxxx_sort_feed_sources');
define('CSYN_SHUFFLE_PROXIES', 'cxxx_shuffle_proxies');
define('CSYN_SPINNERCHIEF_OPTIONS', 'cxxx_spinnerchief_options');
define('CSYN_SPINREWRITER_OPTIONS', 'cxxx_spinrewriter_options');
define('CSYN_CHIMPREWRITER_OPTIONS', 'cxxx_spinchimp_options');
define('CSYN_XSPINNER_OPTIONS', 'cxxx_xspinner_options');
define('CSYN_WORDAI_OPTIONS', 'cxxx_wordai_options');
define('CSYN_CANONICAL_LINK', 'cxxx_canonical_link');
define('CSYN_LINK_TO_SOURCE', 'cxxx_link_to_source');
define('CSYN_MORE', '<!' . '--more--' . '>');
define('CSYN_BLOCK_DIVIDER', '825670622173');
define('CSYN_DUMMY_FEED_PATTERN', '/^\#\d+$/');
define('CSYN_KEEP_IMAGES', 'cxxx_keep_images');
define('CSYN_DISABLE_SPINNER', 0);
define('CSYN_SPINNERCHIEF', 1);
define('CSYN_SPINREWRITER', 2);
define('CSYN_CHIMPREWRITER', 3);
define('CSYN_WORDAI', 5);
define('CSYN_XSPINNER', 7);
define('CSYN_YANDEX_TRANSLATE_LANGS', array(
    'hy-ru' => 'Armenian-Russian',
    'az-ru' => 'Azerbaijani-Russian',
    'be-bg' => 'Belarusian-Bulgarian',
    'be-cs' => 'Belarusian-Czech',
    'be-de' => 'Belarusian-German',
    'be-en' => 'Belarusian-English',
    'be-es' => 'Belarusian-Spanish',
    'be-fr' => 'Belarusian-French',
    'be-it' => 'Belarusian-Italian',
    'be-pl' => 'Belarusian-Polish',
    'be-ro' => 'Belarusian-Romanian',
    'be-ru' => 'Belarusian-Russian',
    'be-sr' => 'Belarusian-Serbian',
    'be-tr' => 'Belarusian-Turkish',
    'bg-be' => 'Bulgarian-Belarusian',
    'bg-ru' => 'Bulgarian-Russian',
    'bg-uk' => 'Bulgarian-Ukrainian',
    'ca-en' => 'Catalan-English',
    'ca-ru' => 'Catalan-Russian',
    'zh-de' => 'Chinese-German',
    'zh-en' => 'Chinese-English',
    'zh-fr' => 'Chinese-French',
    'zh-ja' => 'Chinese-Japanese',
    'zh-it' => 'Chinese-Italian',
    'zh-ru' => 'Chinese-Russian',
    'zh-es' => 'Chinese-Spanish',
    'cs-be' => 'Czech-Belarusian',
    'cs-en' => 'Czech-English',
    'cs-ru' => 'Czech-Russian',
    'cs-uk' => 'Czech-Ukrainian',
    'da-en' => 'Danish-English',
    'da-ru' => 'Danish-Russian',
    'en-be' => 'English-Belarusian',
    'en-ca' => 'English-Catalan',
    'en-zh' => 'English-Chinese',
    'en-cs' => 'English-Czech',
    'en-da' => 'English-Danish',
    'en-de' => 'English-German',
    'en-el' => 'English-Greek',
    'en-es' => 'English-Spanish',
    'en-et' => 'English-Estonian',
    'en-fi' => 'English-Finnish',
    'en-fr' => 'English-French',
    'en-ja' => 'English-Japanese',
    'en-hu' => 'English-Hungarian',
    'en-it' => 'English-Italian',
    'en-lt' => 'English-Lithuanian',
    'en-lv' => 'English-Latvian',
    'en-mk' => 'English-Macedonian',
    'en-nl' => 'English-Dutch',
    'en-no' => 'English-Norwegian',
    'en-pt' => 'English-Portuguese',
    'en-ru' => 'English-Russian',
    'en-sk' => 'English-Slovak',
    'en-sl' => 'English-Slovenian',
    'en-sq' => 'English-Albanian',
    'en-sv' => 'English-Swedish',
    'en-tr' => 'English-Turkish',
    'en-uk' => 'English-Ukrainian',
    'de-be' => 'German-Belarusian',
    'de-zh' => 'German-Chinese',
    'de-en' => 'German-English',
    'de-es' => 'German-Spanish',
    'de-fr' => 'German-French',
    'de-ja' => 'German-Japanese',
    'de-it' => 'German-Italian',
    'de-ru' => 'German-Russian',
    'de-tr' => 'German-Turkish',
    'de-uk' => 'German-Ukrainian',
    'el-en' => 'Greek-English',
    'el-ru' => 'Greek-Russian',
    'et-en' => 'Estonian-English',
    'et-ru' => 'Estonian-Russian',
    'fi-en' => 'Finnish-English',
    'fi-ru' => 'Finnish-Russian',
    'fr-be' => 'French-Belarusian',
    'fr-zh' => 'French-Chinese',
    'fr-de' => 'French-German',
    'fr-en' => 'French-English',
    'fr-ja' => 'French-Japanese',
    'fr-it' => 'French-Italian',
    'fr-ru' => 'French-Russian',
    'fr-uk' => 'French-Ukrainian',
    'ja-en' => 'Japanese-English',
    'ja-ru' => 'Japanese-Russian',
    'ja-zh' => 'Japanese-Chinese',
    'ja-de' => 'Japanese-German',
    'ja-fr' => 'Japanese-French',
    'hr-ru' => 'Croatian-Russian',
    'hu-en' => 'Hungarian-English',
    'hu-ru' => 'Hungarian-Russian',
    'it-be' => 'Italian-Belarusian',
    'it-zh' => 'Italian-Chinese',
    'it-de' => 'Italian-German',
    'it-en' => 'Italian-English',
    'it-fr' => 'Italian-French',
    'it-ru' => 'Italian-Russian',
    'it-uk' => 'Italian-Ukrainian',
    'lt-en' => 'Lithuanian-English',
    'lt-ru' => 'Lithuanian-Russian',
    'lv-en' => 'Latvian-English',
    'lv-ru' => 'Latvian-Russian',
    'mk-en' => 'Macedonian-English',
    'mk-ru' => 'Macedonian-Russian',
    'nl-en' => 'Dutch-English',
    'nl-ru' => 'Dutch-Russian',
    'no-en' => 'Norwegian-English',
    'no-ru' => 'Norwegian-Russian',
    'pl-be' => 'Polish-Belarusian',
    'pl-ru' => 'Polish-Russian',
    'pl-uk' => 'Polish-Ukrainian',
    'pt-en' => 'Portuguese-English',
    'pt-ru' => 'Portuguese-Russian',
    'ro-be' => 'Romanian-Belarusian',
    'ro-ru' => 'Romanian-Russian',
    'ro-uk' => 'Romanian-Ukrainian',
    'ru-az' => 'Russian-Azerbaijani',
    'ru-be' => 'Russian-Belarusian',
    'ru-bg' => 'Russian-Bulgarian',
    'ru-ca' => 'Russian-Catalan',
    'ru-cs' => 'Russian-Czech',
    'ru-da' => 'Russian-Danish',
    'ru-de' => 'Russian-German',
    'ru-el' => 'Russian-Greek',
    'ru-en' => 'Russian-English',
    'ru-es' => 'Russian-Spanish',
    'ru-et' => 'Russian-Estonian',
    'ru-fi' => 'Russian-Finnish',
    'ru-fr' => 'Russian-French',
    'ru-hr' => 'Russian-Croatian',
    'ru-hu' => 'Russian-Hungarian',
    'ru-hy' => 'Russian-Armenian',
    'ru-it' => 'Russian-Italian',
    'ru-ja' => 'Russian-Japanese',
    'ru-lt' => 'Russian-Lithuanian',
    'ru-lv' => 'Russian-Latvian',
    'ru-mk' => 'Russian-Macedonian',
    'ru-nl' => 'Russian-Dutch',
    'ru-no' => 'Russian-Norwegian',
    'ru-pl' => 'Russian-Polish',
    'ru-pt' => 'Russian-Portuguese',
    'ru-ro' => 'Russian-Romanian',
    'ru-sk' => 'Russian-Slovak',
    'ru-sl' => 'Russian-Slovenian',
    'ru-sq' => 'Russian-Albanian',
    'ru-sr' => 'Russian-Serbian',
    'ru-sv' => 'Russian-Swedish',
    'ru-tr' => 'Russian-Turkish',
    'ru-uk' => 'Russian-Ukrainian',
    'sk-en' => 'Slovak-English',
    'sk-ru' => 'Slovak-Russian',
    'es-be' => 'Spanish-Belarusian',
    'es-zh' => 'Spanish-Chinese',
    'es-de' => 'Spanish-German',
    'es-en' => 'Spanish-English',
    'es-ru' => 'Spanish-Russian',
    'es-uk' => 'Spanish-Ukrainian',
    'sl-en' => 'Slovenian-English',
    'sl-ru' => 'Slovenian-Russian',
    'sq-en' => 'Albanian-English',
    'sq-ru' => 'Albanian-Russian',
    'sr-be' => 'Serbian-Belarusian',
    'sr-ru' => 'Serbian-Russian',
    'sr-uk' => 'Serbian-Ukrainian',
    'sv-en' => 'Swedish-English',
    'sv-ru' => 'Swedish-Russian',
    'tr-be' => 'Turkish-Belarusian',
    'tr-de' => 'Turkish-German',
    'tr-en' => 'Turkish-English',
    'tr-ru' => 'Turkish-Russian',
    'tr-uk' => 'Turkish-Ukrainian',
    'uk-bg' => 'Ukrainian-Bulgarian',
    'uk-cs' => 'Ukrainian-Czech',
    'uk-de' => 'Ukrainian-German',
    'uk-en' => 'Ukrainian-English',
    'uk-es' => 'Ukrainian-Spanish',
    'uk-fr' => 'Ukrainian-French',
    'uk-it' => 'Ukrainian-Italian',
    'uk-pl' => 'Ukrainian-Polish',
    'uk-ro' => 'Ukrainian-Romanian',
    'uk-ru' => 'Ukrainian-Russian',
    'uk-sr' => 'Ukrainian-Serbian',
    'uk-tr' => 'Ukrainian-Turkish'));
define('CSYN_GOOGLE_TRANSLATE_LANGS', array(
    'af' => 'Afrikaans',
    'sq' => 'Albanian',
    'ar' => 'Arabic',
    'az' => 'Azerbaijani',
    'eu' => 'Basque',
    'be' => 'Belarusian',
    'bn' => 'Bengali',
    'bg' => 'Bulgarian',
    'ca' => 'Catalan',
    'zh-CN' => 'Chinese Simplified',
    'zh-TW' => 'Chinese Traditional',
    'hr' => 'Croatian',
    'cs' => 'Czech',
    'da' => 'Danish',
    'nl' => 'Dutch',
    'en' => 'English',
    'eo' => 'Esperanto',
    'et' => 'Estonian',
    'tl' => 'Filipino',
    'fi' => 'Finnish',
    'fr' => 'French',
    'gl' => 'Galician',
    'ka' => 'Georgian',
    'de' => 'German',
    'el' => 'Greek',
    'gu' => 'Gujarati',
    'ht' => 'Haitian Creole',
    'iw' => 'Hebrew',
    'hi' => 'Hindi',
    'hu' => 'Hungarian',
    'is' => 'Icelandic',
    'id' => 'Indonesian',
    'ga' => 'Irish',
    'it' => 'Italian',
    'ja' => 'Japanese',
    'kn' => 'Kannada',
    'ko' => 'Korean',
    'la' => 'Latin',
    'lv' => 'Latvian',
    'lt' => 'Lithuanian',
    'mk' => 'Macedonian',
    'ms' => 'Malay',
    'mt' => 'Maltese',
    'no' => 'Norwegian',
    'fa' => 'Persian',
    'pl' => 'Polish',
    'pt' => 'Portuguese',
    'ro' => 'Romanian',
    'ru' => 'Russian',
    'sr' => 'Serbian',
    'sk' => 'Slovak',
    'sl' => 'Slovenian',
    'es' => 'Spanish',
    'sw' => 'Swahili',
    'sv' => 'Swedish',
    'ta' => 'Tamil',
    'te' => 'Telugu',
    'th' => 'Thai',
    'tr' => 'Turkish',
    'uk' => 'Ukrainian',
    'ur' => 'Urdu',
    'vi' => 'Vietnamese',
    'cy' => 'Welsh',
    'yi' => 'Yiddish'));

function csyn_get_headers($url) {
    if (parse_url($url, PHP_URL_SCHEME) != '') {
        if (function_exists('curl_init')) {
            $max_redirects = CSYN_MAX_CURL_REDIRECTS;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_REFERER, $url);
            curl_setopt($ch, CURLOPT_HEADER, true);
            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_setopt($ch, CURLOPT_FORBID_REUSE, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            if (ini_get('open_basedir') == '') {
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_MAXREDIRS, $max_redirects);
            } else {
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
                $rch = curl_copy_handle($ch);
                do {
                    curl_setopt($rch, CURLOPT_URL, $url);
                    curl_setopt($rch, CURLOPT_REFERER, $url);
                    $header = curl_exec($rch);
                    if (curl_errno($rch)) {
                        $code = 0;
                    } else {
                        $code = curl_getinfo($rch, CURLINFO_HTTP_CODE);
                        if ($code == 301 || $code == 302) {
                            preg_match('/Location:(.*?)\n/', $header, $matches);
                            $url = trim(array_pop($matches));
                        } else {
                            $code = 0;
                        }
                    }
                } while ($code && --$max_redirects);
                curl_close($rch);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_REFERER, $url);
            }
            $headers = @explode(PHP_EOL, trim(curl_exec($ch)));
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($code != 200) {
                unset($headers);
            }
        }
        if (!isset($headers)) {
            stream_context_set_default(array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                ),
                'http' => array(
                    'method' => 'HEAD',
                    'user_agent' => CSYN_CURL_USER_AGENT,
                ),
            ));
            $headers = @get_headers($url, 0);
        }
        return $headers;
    }
    return false;
}

function csyn_is_valid_url($url = '') {
    if (strlen(trim($url))) {
        $headers = csyn_get_headers($url);
        if ($headers) {
            return (preg_match('/\n(HTTP|FTP).+200[ |\n]/i', PHP_EOL . implode(PHP_EOL, $headers)) == 1);
        }
    }
    return false;
}

function csyn_file_get_contents($url, $as_array = false, $headers = '', $referrer = 'self', $user_agent = false) {
    global $csyn_syndicator, $csyn_last_effective_url;
    if (parse_url($url, PHP_URL_SCHEME) != '' && function_exists('curl_init')) {
        $max_redirects = CSYN_MAX_CURL_REDIRECTS;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        if (strtolower($referrer) == 'self') {
            curl_setopt($ch, CURLOPT_REFERER, $url);
        } elseif (strlen($referrer)) {
            curl_setopt($ch, CURLOPT_REFERER, $referrer);
        }
        if ($user_agent) {
            curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
        } elseif (isset($csyn_syndicator)) {
            if ($csyn_syndicator->preview) {
                curl_setopt($ch, CURLOPT_USERAGENT, $csyn_syndicator->global_options['user_agent']);
            } else {
                if (isset($csyn_syndicator->current_feed['options']['user_agent'])) {
                    curl_setopt($ch, CURLOPT_USERAGENT, $csyn_syndicator->current_feed['options']['user_agent']);
                }
            }
        }
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $headers = trim($headers);
        if (strlen($headers)) {
            $headers_array = explode(PHP_EOL, $headers);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
        }
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        if (ini_get('open_basedir') == '') {
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_MAXREDIRS, $max_redirects);
        } else {
            $base_url = $url;
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
            $rch = curl_copy_handle($ch);
            curl_setopt($rch, CURLOPT_HEADER, true);
            curl_setopt($rch, CURLOPT_NOBODY, true);
            curl_setopt($rch, CURLOPT_FORBID_REUSE, false);
            curl_setopt($rch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($rch, CURLOPT_SSL_VERIFYPEER, false);
            do {
                curl_setopt($rch, CURLOPT_URL, $url);
                curl_setopt($rch, CURLOPT_REFERER, $url);
                $header = curl_exec($rch);
                if (curl_errno($rch)) {
                    $code = 0;
                } else {
                    $code = curl_getinfo($rch, CURLINFO_HTTP_CODE);
                    if ($code == 301 || $code == 302) {
                        preg_match('/Location:(.*?)\n/', $header, $matches);
                        $url = trim(array_pop($matches));
                        if (strlen($url) && substr($url, 0, 1) == '/') {
                            $url = $base_url . $url;
                        }
                    } else {
                        $code = 0;
                    }
                }
            } while ($code && --$max_redirects);
            curl_close($rch);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_REFERER, $url);
        }
        curl_setopt($ch, CURLOPT_HEADER, false);
        $content = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $csyn_last_effective_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        if ($code != 200) {
            $content = false;
        } else {
            if ($as_array) {
                $content = explode(PHP_EOL, trim($content));
            }
        }
        @curl_close($ch);
    }
    if (!isset($content) || $content === false) {
        $ua = CSYN_CURL_USER_AGENT;
        if (isset($csyn_syndicator)) {
            if ($csyn_syndicator->preview) {
                $ua = $csyn_syndicator->global_options['user_agent'];
            } else {
                if (isset($csyn_syndicator->current_feed['options']['user_agent'])) {
                    $ua = $csyn_syndicator->current_feed['options']['user_agent'];
                }
            }
        }
        stream_context_set_default(array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
            ),
            'http' => array(
                'method' => 'HEAD',
                'user_agent' => $ua,
            ),
        ));
        if ($as_array) {
            $content = @file($url, FILE_IGNORE_NEW_LINES);
        } else {
            $content = @file_get_contents($url);
        }
        $csyn_last_effective_url = $url;
    }
    return $content;
}

function csyn_xor($text, $key) {
    for ($i = 0; $i < strlen($text);) {
        for ($j = 0; ($j < strlen($key) && $i < strlen($text)); $j++, $i++) {
            $text[$i] = $text[$i] ^ $key[$j];
        }
    }
    return $text;
}

function csyn_array_stripslashes($value) {
    $res = is_array($value) ? array_map('csyn_array_stripslashes', $value) : stripslashes($value);
    return $res;
}

function csyn_mk_post_data($data) {
    $result = '';
    foreach ($data as $key => $value) {
        $result .= $key . '=' . urlencode($value) . '&';
    }
    return $result;
}

function csyn_curl_post($url, $data, &$info, $connection_timeout = false) {
    $ch = curl_init();
    if ($connection_timeout !== false) {
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $connection_timeout);
    }
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_REFERER, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, csyn_mk_post_data($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $result = trim(curl_exec($ch));
    $info = curl_getinfo($ch);
    curl_close($ch);
    return $result;
}

function csyn_chop_str($str, $max_length = 0, $ending = '...') {
    $length = strlen($str);
    if ($max_length > 1 && $length > $max_length) {
        $ninety = $max_length * 0.9;
        $length = $length - $ninety;
        $first = substr($str, 0, -$length);
        $last = substr($str, $ninety - $max_length);
        $str = $first . $ending . $last;
    }
    return $str;
}

function csyn_shorten_html($text, $max_length = 0, $ending = '...', $exact = false) {
    if ($max_length == 0 || strlen(preg_replace('/<.*?>/', '', $text)) <= $max_length) {
        return $text;
    }
    $total_length = strlen($ending);
    $open_tags = [];
    $truncated_text = '';
    preg_match_all('/(<.+?>)?([^<>]*)/s', $text, $lines, PREG_SET_ORDER);
    foreach ($lines as $line_matchings) {
        if (!empty($line_matchings[1])) {
            if (preg_match('/^<(\s*.+?\/\s*|\s*(img|br|input|hr|area|base|basefont|col|frame|isindex|link|meta|param)(\s.+?)?)>$/is', $line_matchings[1])) {
                
            } else if (preg_match('/^<\s*\/([^\s]+?)\s*>$/s', $line_matchings[1], $tag_matchings)) {
                $pos = array_search($tag_matchings[1], $open_tags);
                if ($pos !== false) {
                    unset($open_tags[$pos]);
                }
            } else if (preg_match('/^<\s*([^\s>!]+).*?>$/s', $line_matchings[1], $tag_matchings)) {
                array_unshift($open_tags, strtolower($tag_matchings[1]));
            }
            $truncated_text .= $line_matchings[1];
        }
        $content_length = strlen(preg_replace('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|[0-9a-f]{1,6};/i', ' ', $line_matchings[2]));
        if ($total_length + $content_length > $max_length) {
            $left = $max_length - $total_length;
            $entities_length = 0;
            if (preg_match_all('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|[0-9a-f]{1,6};/i', $line_matchings[2], $entities, PREG_OFFSET_CAPTURE)) {
                foreach ($entities[0] as $entity) {
                    if ($entity[1] + 1 - $entities_length <= $left--) {
                        $entities_length += strlen($entity[0]);
                    } else {
                        break;
                    }
                }
            }
            $truncated_text .= substr($line_matchings[2], 0, $left + $entities_length);
            break;
        } else {
            $truncated_text .= $line_matchings[2];
            $total_length += $content_length;
        }
        if ($total_length >= $max_length) {
            break;
        }
    }
    if (!$exact) {
        $space_pos = strrpos($truncated_text, ' ');
        if (isset($space_pos)) {
            $truncated_text = substr($truncated_text, 0, $space_pos);
        }
    }
    $truncated_text .= $ending;
    foreach ($open_tags as $tag) {
        $truncated_text .= '</' . $tag . '>';
    }
    return $truncated_text;
}

function csyn_date3339($timestamp) {
    $date = date('Y-m-d\TH:i:s', $timestamp);
    $matches = [];
    if (preg_match('/^([\-+])(\d{2})(\d{2})$/', date('O', $timestamp), $matches)) {
        $date .= $matches[1] . $matches[2] . ':' . $matches[3];
    } else {
        $date .= 'Z';
    }
    return $date;
}

function csyn_REQUEST_URI() {
    return strtok($_SERVER['REQUEST_URI'], '?') . '?' . strtok('?');
}

function csyn_fix_white_spaces($str) {
    return preg_replace('/\s\s+/', ' ', preg_replace('/\s\"/', ' "', preg_replace('/\s\'/', ' \'', $str)));
}

function csyn_delete_media_by_url($media_urls) {
    $wp_upload_dir = wp_upload_dir();
    if (!is_array($media_urls)) {
        $media_urls = array($media_urls);
    }
    if (count($media_urls)) {
        $media_urls = array_values(array_unique($media_urls));
        foreach ($media_urls as $url) {
            preg_match('/\/wp-content\/(.*?)$/', $url, $link_match);
            preg_match('/.*?\/wp-content\//', $wp_upload_dir['path'], $path_match);
            if (isset($path_match[0]) && isset($link_match[1])) {
                @unlink($path_match[0] . $link_match[1]);
            } else {
                @unlink(str_replace($wp_upload_dir['url'], $wp_upload_dir['path'], $url));
            }
        }
    }
}

function csyn_delete_post_media($post_id) {
    $post = get_post($post_id, ARRAY_A);
    $wp_upload_dir = wp_upload_dir();
    preg_match_all('/<img(.+?)src=[\'\"](.+?)[\'\"](.*?)>/is', $post['post_content'] . $post['post_excerpt'], $matches);
    $media_urls = $matches[2];
    preg_match_all('/<img.*?srcset=[\'\"](.+?)[\'\"].*?>/is', $post['post_content'] . $post['post_excerpt'], $matches);
    if (count($matches[1])) {
        foreach ($matches[1] as $item) {
            preg_match_all('/(.+?)\s+.+?[\,\'\"]/is', $item, $srcsets);
            if (count($srcsets[1])) {
                foreach ($srcsets[1] as $link) {
                    $media_urls[] = trim($link);
                }
            }
        }
    }
    $media_urls = array_values(array_unique($media_urls));
    $custom_field_keys = get_post_custom_keys($post_id);
    if (is_array($custom_field_keys)) {
        foreach ($custom_field_keys as $key_id => $key_value) {
            $tr = trim($key_value);
            if ($tr[0] == '_') {
                continue;
            }
            $value = get_post_meta($post_id, $tr, true);
            if (!is_array($value) && preg_match('/^' . preg_quote($wp_upload_dir['url'], '/') . '.*?(\.jpg|\.jpeg|\.gif|\.png|\.bmp|\.wbmp|\.webm|\.xbm)$/i', $value)) {
                $media_urls[] = $value;
            }
        }
    }
    preg_match_all('/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|](\.mp4|\.m4v\.mov|\.wmv|\.avi|\.mpg|\.ogv|\.3gp|\.3g2)/i', $post['post_content'] . $post['post_excerpt'], $matches);
    foreach ($matches[0] as $url) {
        if (strlen(trim($url))) {
            $media_urls[] = trim($url);
        }
    }
    csyn_delete_media_by_url($media_urls);
    $args = array(
        'numberposts' => - 1,
        'post_mime_type' => 'image',
        'post_parent' => $post_id,
        'post_status' => null,
        'post_type' => 'attachment'
    );
    $img_attachments = get_children($args);
    if ($img_attachments) {
        foreach ($img_attachments as $attachment) {
            wp_delete_attachment($attachment->ID, true);
        }
    }
}

function csyn_escape_guid(&$post, $document_type) {
    if ($document_type == 'HTML' && isset($post['link'])) {
        $url = parse_url($post['link']);
        $guid = $url['scheme'] . '://' . $url['host'] . $url['path'] . '/' . md5((isset($url['query']) ? $url['query'] : '*')) . '/' . md5($post['post_title'] . $post['post_excerpt'] . $post['post_content']);
    } else {
        if (mb_strlen($post['guid']) < 8) {
            $components = parse_url($post['link']);
            if (!isset($components['host'])) {
                $components['host'] = '';
            }
            $guid = 'tag:' . $components['host'];
            if ($post['post_date'] != '') {
                $guid .= '://post.' . $post['post_date'];
            } else {
                $guid .= '://' . md5($post['link'] . '/' . $post['post_title']);
            }
        } else {
            $guid = trim($post['guid']);
            if (stripos($guid, 'http://') === false && stripos($guid, 'https://') === false) {
                $guid = 'http://' . $guid;
            }
        }
        $guid = addslashes($guid);
        if (mb_strlen($guid) > 255) {
            $guid = mb_substr($guid, 0, 255);
        }
    }
    $post['guid'] = $guid;
    $post['post_title'] = csyn_fix_white_spaces($post['post_title']);
}

function csyn_post_exists(&$post) {
    global $wpdb, $csyn_syndicator;
    $method = $csyn_syndicator->current_feed['options']['duplicate_check_method'];
    $name = sanitize_title($post['post_title']);
    $guid = htmlentities($post['guid']);
    if (isset($post['options']) && is_array($post['options'])) {
        if (!in_array('bypass_singularity_check', $post['options'])) {
            $post['options'][] = 'bypass_singularity_check';
        }
    } else {
        $post['options'] = array('bypass_singularity_check');
    }
    switch ($method) {
        case 'guid':
            return $wpdb->get_var("SELECT ID FROM {$wpdb->prefix}posts WHERE guid = '" . $guid . "' AND post_status NOT IN ('trash') AND post_type NOT IN ('attachment', 'revision', 'nav_menu_item')");
            break;
        case 'title':
            return $wpdb->get_var("SELECT ID FROM {$wpdb->prefix}posts as posts, {$wpdb->prefix}postmeta as postmeta WHERE posts.ID = postmeta.post_id AND ((postmeta.meta_key = 'cyberseo_post_name' AND postmeta.meta_value = '" . $name . "') OR (posts.post_name = '" . $name . "')) AND posts.post_status NOT IN ('trash') AND posts.post_type NOT IN ('attachment', 'revision', 'nav_menu_item')");
            break;
        case 'guid_and_title':
            return $wpdb->get_var("SELECT ID FROM {$wpdb->prefix}posts as posts, {$wpdb->prefix}postmeta as postmeta WHERE posts.ID = postmeta.post_id AND (((postmeta.meta_key = 'cyberseo_post_name' AND postmeta.meta_value = '" . $name . "') OR (posts.post_name = '" . $name . "')) OR (posts.guid = '" . $guid . "')) AND posts.post_status NOT IN ('trash') AND posts.post_type NOT IN ('attachment', 'revision', 'nav_menu_item')");
            break;
    }
    return false;
}

function csyn_addslash($url) {
    if ($url[strlen($url) - 1] !== '/') {
        $url .= '/';
    }
    return $url;
}

function csyn_attach_post_thumbnail($post_id, $image_url, $title) {
    $attach_id = csyn_add_image_to_library($image_url, $title, $post_id);
    if ($attach_id !== false) {
        if (set_post_thumbnail($post_id, $attach_id)) {
            return $attach_id;
        }
    }
    return false;
}

function csyn_default_options() {
    if (get_option(CSYN_ENABLE_DEBUG_MODE) === false) {
        update_option(CSYN_ENABLE_DEBUG_MODE, '');
    }
    $default_url = trim(get_option(CSYN_FULL_TEXT_EXTRACTOR));
    if ($default_url === false || $default_url == '' || !csyn_is_valid_url($default_url)) {
        if (file_exists('../fivefilters-full-text-rss/makefulltextfeed.php')) {
            $default_url = get_site_url() . '/fivefilters-full-text-rss/makefulltextfeed.php';
        } elseif (file_exists('../wp-content/fivefilters-full-text-rss/makefulltextfeed.php')) {
            $default_url = get_site_url() . '/wp-content/fivefilters-full-text-rss/makefulltextfeed.php';
        } elseif (file_exists('../wp-content/plugins/fivefilters-full-text-rss/makefulltextfeed.php')) {
            $default_url = get_site_url() . '/wp-content/plugins/fivefilters-full-text-rss/makefulltextfeed.php';
        } elseif (file_exists('../wp-content/plugins/cybersyn/fivefilters-full-text-rss/makefulltextfeed.php')) {
            $default_url = get_site_url() . '/wp-content/plugins/cybersyn/fivefilters-full-text-rss/makefulltextfeed.php';
        } else {
            $default_url = '';
        }
        update_option(CSYN_FULL_TEXT_EXTRACTOR, $default_url);
    }
    if (get_option(CSYN_AMAZON_TAG) === false) {
        update_option(CSYN_AMAZON_TAG, '');
    }
    if (get_option(CSYN_DISABLE_DUPLICATION_CONTROL) === false) {
        update_option(CSYN_DISABLE_DUPLICATION_CONTROL, '');
    }
    if (get_option(CSYN_SORT_FEED_SOURCES) === false) {
        update_option(CSYN_SORT_FEED_SOURCES, 'name');
    }
    if (get_option(CSYN_SHUFFLE_PROXIES) === false) {
        update_option(CSYN_SHUFFLE_PROXIES, '');
    }
    if (get_option(CSYN_POST_IMAGES) === false) {
        update_option(CSYN_POST_IMAGES, 'keep');
    }
    if (get_option(CSYN_URLS_NOFOLLOW) === false) {
        update_option(CSYN_URLS_NOFOLLOW, '');
    }
    if (get_option(CSYN_URLS_NOREFERRER) === false) {
        update_option(CSYN_URLS_NOREFERRER, '');
    }
    if (get_option(CSYN_URLS_ENCRYPT) === false) {
        update_option(CSYN_URLS_ENCRYPT, '');
    }
    if (get_option(CSYN_URLS_TARGET_BLANK) === false) {
        update_option(CSYN_URLS_TARGET_BLANK, '');
    }
    if (get_option(CSYN_SYNDICATED_FEEDS) === false) {
        update_option(CSYN_SYNDICATED_FEEDS, []);
    }
    if (get_option(CSYN_FEEDS_UPDATED) === false) {
        update_option(CSYN_FEEDS_UPDATED, []);
    }
    if (get_option(CSYN_CRON_MAGIC) === false) {
        update_option(CSYN_CRON_MAGIC, '%%MAGIC%%');
    }
    if (get_option(CSYN_RAND_SHA) === false) {
        update_option(CSYN_RAND_SHA, sha1(random_int(PHP_INT_MIN, PHP_INT_MAX)));
    }
    if (get_option(CSYN_RSS_PULL_MODE) === false) {
        update_option(CSYN_RSS_PULL_MODE, 'auto');
    }
    if (get_option(CSYN_PSEUDO_CRON_INTERVAL) === false) {
        update_option(CSYN_PSEUDO_CRON_INTERVAL, '10');
    }
    if (get_option(CSYN_KEEP_IMAGES) === false) {
        update_option(CSYN_KEEP_IMAGES, 'on');
    }
    if (get_option(CSYN_LINK_TO_SOURCE) === false) {
        update_option(CSYN_LINK_TO_SOURCE, 'auto');
    }
    if (get_option(CSYN_CANONICAL_LINK) === false) {
        update_option(CSYN_CANONICAL_LINK, 'auto');
    }
    if (get_option(CSYN_SPINNERCHIEF_OPTIONS) === false) {
        $options = array(
            'spintype' => '1',
            'spinfreq' => '4',
            'autospin' => '1',
            'original' => '1',
            'wordscount' => '3',
            'usehurricane' => '0',
            'chartype' => '1',
            'convertbase' => '0',
            'onecharforword' => '0',
            'percent' => '0',
            'protecthtml' => '0',
            'spinhtml' => '0',
            'orderly' => '0',
            'wordquality' => '0',
            'username' => '',
            'password' => '',
            'apikey' => '150da559a18c40049',
            'protectwords' => '0',
            'querytimes' => '0',
            'replacetype' => '0',
            'pos' => '0',
            'UseGrammarAI' => '0',
            'rule' => 'none',
            'thesaurus' => 'English',
            'phrasecount' => '2',
            'tagprotect' => '[],<>'
        );
        update_option(CSYN_SPINNERCHIEF_OPTIONS, $options);
    }
    if (get_option(CSYN_SPINREWRITER_OPTIONS) === false) {
        $options = array(
            'text_with_spintax' => 'false',
            'email_address' => '',
            'api_key' => '',
            'auto_protected_terms' => 'false',
            'protected_terms' => '',
            'confidence_level' => 'medium',
            'auto_sentences' => 'false',
            'auto_paragraphs' => 'false',
            'auto_new_paragraphs' => 'false',
            'auto_sentence_trees' => 'false',
            'use_only_synonyms' => 'false',
            'nested_spintax' => 'false'
        );
        update_option(CSYN_SPINREWRITER_OPTIONS, $options);
    }
    if (get_option(CSYN_CHIMPREWRITER_OPTIONS) === false) {
        $options = array(
            'email' => '',
            'apikey' => '',
            'aid' => 'CyberSEO',
            'quality' => '4',
            'posmatch' => '3',
            'protectedterms' => '',
            'rewrite' => '1',
            'phraseignorequality' => '0',
            'spinwithinspin' => '0',
            'spinwithinhtml' => '1',
            'applyinstantunique' => '0',
            'fullcharset' => '0',
            'spintidy' => '0',
            'tagprotect' => '',
            'maxspindepth' => '0'
        );
        update_option(CSYN_CHIMPREWRITER_OPTIONS, $options);
    }
    if (get_option(CSYN_XSPINNER_OPTIONS) === false) {
        $options = array(
            'post_url' => 'http://127.0.0.1:80/',
            'spintype' => '0',
            'removeold' => '1',
            'protectw' => '',
            'spinway' => '0',
            'thesaurus' => 'Default'
        );
        update_option(CSYN_XSPINNER_OPTIONS, $options);
    }
    $options = get_option(CSYN_WORDAI_OPTIONS);
    if ($options === false || !isset($options['use_custom_synonyms'])) {
        $options = array(
            'email' => '',
            'key' => '',
            'uniqueness' => '1',
            'return_rewrites' => 'true',
            'protect_words' => 'false',
            'use_custom_synonyms' => 'false',
        );
        update_option(CSYN_WORDAI_OPTIONS, $options);
    }
}

function csyn_yandex_translate($apikey, $text, $dir, $return_emty = false) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://translate.yandex.net/api/v1.5/tr.json/translate');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'key=' . trim($apikey) . '&lang=' . $dir . '&format=html&text=' . urlencode($text));
    $json = json_decode(curl_exec($ch), true);
    curl_close($ch);
    if ($json['code'] == 200) {
        return $json['text'][0];
    } else {
        if ($return_emty) {
            return '';
        } else {
            return false;
        }
    }
}

function csyn_google_translate($apikey, $text, $source, $target, $return_emty = false) {
    global $csyn_syndicator;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://translation.googleapis.com/language/translate/v2');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'key=' . trim($apikey) . '&source=' . $source . '&target=' . $target . '&q=' . urlencode($text));
    $json = json_decode(curl_exec($ch), true);
    curl_close($ch);
    if (isset($json['data']['translations']['0']['translatedText'])) {
        return $json['data']['translations']['0']['translatedText'];
    } else {
        if ($return_emty) {
            return '';
        } else {
            return false;
        }
    }
}

function csyn_compare_files($file_name_1, $file_name_2) {
    $file1 = csyn_file_get_contents($file_name_1);
    $file2 = csyn_file_get_contents($file_name_2);
    if ($file1 && $file2) {
        return (md5($file1) == md5($file2));
    }
    return false;
}

function csyn_save_image($image_url, $preferred_name = '') {
    global $csyn_syndicator;
    $wp_upload_dir = wp_upload_dir();
    $temp_name = wp_unique_filename($wp_upload_dir['path'], md5(time()) . '.tmp');
    $image_url = trim($image_url);
    if (strpos($image_url, '//') === 0) {
        $image_url = 'http:' . $image_url;
    } elseif (strpos($image_url, '/') === 0) {
        $parse = parse_url($csyn_syndicator->current_feed['url']);
        $image_url = $parse['scheme'] . '://' . $parse['host'] . $image_url;
    }
    if (is_writable($wp_upload_dir['path']) && function_exists('gd_info') && function_exists('getimagesize') && function_exists('image_type_to_extension')) {
        if (preg_match('/^data:(image|video).*?;base64\,(.*?)$/i', $image_url, $matches) && isset($matches[2]) && strlen($matches[2])) {
            if (isset($csyn_syndicator->current_feed['options']['store_base64_encoded_images']) && $csyn_syndicator->current_feed['options']['store_base64_encoded_images'] == 'on') {
                $image_file = base64_decode($matches[2]);
            }
        }
        if (!isset($image_file) || $image_file === false) {
            $image_file = csyn_file_get_contents($image_url);
            if ($image_file === false) {
                $image_file = csyn_file_get_contents($image_url, false, csyn_CURL_USER_AGENT);
            }
        }
        file_put_contents($wp_upload_dir['path'] . '/' . $temp_name, $image_file, LOCK_EX);
        $image_info = @getimagesize($wp_upload_dir['path'] . '/' . $temp_name);
        if ($image_info !== false) {
            $image_type = $image_info[2];
            $ext = str_replace('jpeg', 'jpg', image_type_to_extension($image_type, true));
            if ($image_type == IMAGETYPE_JPEG || $image_type == IMAGETYPE_JPEG2000) {
                $image = imagecreatefromjpeg($wp_upload_dir['path'] . '/' . $temp_name);
            } elseif ($image_type == IMAGETYPE_GIF) {
                $image = imagecreatefromgif($wp_upload_dir['path'] . '/' . $temp_name);
            } elseif ($image_type == IMAGETYPE_PNG) {
                $image = imagecreatefrompng($wp_upload_dir['path'] . '/' . $temp_name);
            } elseif ($image_type == IMAGETYPE_BMP) {
                $image = imagecreatefrombmp($wp_upload_dir['path'] . '/' . $temp_name);
            } elseif ($image_type == IMAGETYPE_WBMP) {
                $image = imagecreatefromwbmp($wp_upload_dir['path'] . '/' . $temp_name);
            } elseif ($image_type == IMAGETYPE_WEBP) {
                $image = imagecreatefromwebp($wp_upload_dir['path'] . '/' . $temp_name);
            } elseif ($image_type == IMAGETYPE_XBM) {
                $image = imagecreatefromxbm($wp_upload_dir['path'] . '/' . $temp_name);
            } else {
                return false;
            }
            if ($image == false) {
                return $image_url;
            }
            $default_file_name = sanitize_file_name(sanitize_title($preferred_name) . $ext);
            if ($preferred_name != '' && strpos($default_file_name, '%') === false) {
                $file_name = $default_file_name;
            } else {
                $file_name = basename($image_url);
            }
            if (file_exists($wp_upload_dir['path'] . '/' . $file_name)) {
                if (csyn_compare_files($wp_upload_dir['path'] . '/' . $temp_name, $wp_upload_dir['path'] . '/' . $file_name)) {
                    imagedestroy($image);
                    unlink($wp_upload_dir['path'] . '/' . $temp_name);
                    return $wp_upload_dir['url'] . '/' . $file_name;
                }
                $file_name = wp_unique_filename($wp_upload_dir['path'], $file_name);
            }
            $image_path = $wp_upload_dir['path'] . '/' . $file_name;
            $local_image_url = $wp_upload_dir['url'] . '/' . $file_name;
            if (isset($image) && gettype($image) == 'object' && get_class($image) == 'GdImage') {
                imagedestroy($image);
            }
            if (rename($wp_upload_dir['path'] . '/' . $temp_name, $image_path)) {
                return $local_image_url;
            }
        }
        unlink($wp_upload_dir['path'] . '/' . $temp_name);
    }
    return $image_url;
}

function csyn_add_image_to_library($image_url, $title = '', $post_id = false) {
    if (!is_string($image_url)) {
        return false;
    }
    $title = trim($title);
    if ($post_id == false) {
        global $csyn_images_to_attach;
        $csyn_images_to_attach[] = array('url' => $image_url, 'title' => $title);
    } else {
        $upload_dir = wp_upload_dir();
        if (!file_exists($upload_dir['path'] . '/' . basename($image_url))) {
            $image_url = csyn_save_image($image_url, $title);
        }
        $img_path = str_replace($upload_dir['url'], $upload_dir['path'], $image_url);
        if (file_exists($img_path) && filesize($img_path)) {
            $wp_filetype = wp_check_filetype($upload_dir['path'] . basename($image_url), null);
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', $title),
                'post_content' => '',
                'post_parent' => $post_id,
                'guid' => $upload_dir['path'] . basename($image_url),
                'post_status' => 'inherit'
            );
            $attach_id = wp_insert_attachment($attachment, $upload_dir['path'] . '/' . basename($image_url), $post_id);
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $attach_data = wp_generate_attachment_metadata($attach_id, $upload_dir['path'] . '/' . basename($image_url));
            wp_update_attachment_metadata($attach_id, $attach_data);
            return $attach_id;
        }
    }
    return false;
}

function csyn_store_image($custom_field, $preferred_name = '', $width = -1, $height = -1, $compression = -1) {
    global $csyn_images_to_save;
    $csyn_images_to_save[] = array('custom_field' => $custom_field, 'preferred_name' => $preferred_name, 'width' => $width, 'height' => $height, 'compression' => $compression);
}

function csyn_get_header_field_value($header, $field) {
    if (is_array($header)) {
        $end = count($header) - 1;
        if ($end) {
            for ($i = $end; $i >= 0; $i--) {
                list($name, $value) = explode(':', $header[$i]);
                if (strtolower(trim($name)) == strtolower($field)) {
                    return trim($value);
                }
            }
        }
    }
    return '';
}

function csyn_is_binary($url) {
    $header = csyn_get_headers($url);
    if (stripos(csyn_get_header_field_value($header, 'content-type'), 'text') !== false || intval(csyn_get_header_field_value($header, 'content-length')) == 0) {
        return false;
    }
    return true;
}

function csyn_check_files() {
    global $csyn_urls_to_check;
    $csyn_urls_to_check = array_values(array_unique($csyn_urls_to_check));
    if (count($csyn_urls_to_check)) {
        foreach ($csyn_urls_to_check as $url) {
            if (!csyn_is_binary($url)) {
                return false;
            }
        }
    }
    return true;
}

function csyn_unzip($content) {
    $wp_upload_dir = wp_upload_dir();
    $tempfile = $wp_upload_dir['path'] . '/' . wp_unique_filename($wp_upload_dir['path'], 'zip-' . date('Y-m-d-H-i') . '.tmp');
    $success = file_put_contents($tempfile, $content, LOCK_EX);
    if (!$success) {
        return $content;
    }
    $open = zip_open($tempfile);
    if (is_numeric($open)) {
        unlink($tempfile);
        return $content;
    } else {
        while ($zip = zip_read($open)) {
            @zip_entry_open($zip);
            $result = zip_entry_read($zip, zip_entry_filesize($zip));
            zip_entry_close($zip);
        }
    }
    zip_close($open);
    unlink($tempfile);
    return $result;
}

function csyn_xspinner($content) {
    $csyn_xs_options = get_option(CSYN_XSPINNER_OPTIONS);
    $ch = curl_init(trim($csyn_xs_options['post_url']));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'xstext=' . urlencode($content) . '&spintype=' . $csyn_xs_options['post_url'] . '&removeold=' . $csyn_xs_options['removeold'] .
            '&protectw=' . urlencode($csyn_xs_options['protectw']) . '&spinway=' . $csyn_xs_options['spinway'] . '&thesaurus=' . urlencode($csyn_xs_options['thesaurus']));
    $response = trim(curl_exec($ch));
    return $response;
}

function csyn_wordai($content) {
    $csyn_wa_options = get_option(CSYN_WORDAI_OPTIONS);
    $ch = curl_init('https://wai.wordai.com/api/rewrite');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'rewrite_num=1&input=' . urlencode($content) . '&email=' . trim($csyn_wa_options['email']) . '&key=' . trim($csyn_wa_options['key']) .
            '&uniqueness=' . $csyn_wa_options['uniqueness'] . '&return_rewrites=' . $csyn_wa_options['return_rewrites'] .
            '&protect_words=' . $csyn_wa_options['protect_words'] . '&use_custom_synonyms=' . $csyn_wa_options['use_custom_synonyms']);
    $response = trim(curl_exec($ch));
    curl_close($ch);
    $api_response_interpreted = json_decode($response, true);
    if ($api_response_interpreted['status'] == 'Success') {
        if (isset($api_response_interpreted['rewrites'][0])) {
            return $api_response_interpreted['rewrites'][0];
        } else {
            return $api_response_interpreted['text'];
        }
    }
    return $content;
}

function csyn_spinnerchief($content) {
    $csyn_sc_options = get_option(CSYN_SPINNERCHIEF_OPTIONS);
    $url = '';
    foreach ($csyn_sc_options as $key => $option) {
        $url .= $key . '=' . urlencode(trim($option)) . '&';
    }
    $req = curl_init();
    curl_setopt($req, CURLOPT_URL, 'http://api.spinnerchief.com:443/' . $url);
    curl_setopt($req, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($req, CURLOPT_POST, true);
    curl_setopt($req, CURLOPT_POSTFIELDS, base64_encode($content));
    $result = base64_decode(trim(curl_exec($req)));
    curl_close($req);
    if (strpos($result, 'error=') !== 0 && strlen($result)) {
        return $result;
    }
    return $content;
}

function csyn_spinrewriter($content) {
    $csyn_sr_options = get_option(CSYN_SPINREWRITER_OPTIONS);
    $data_raw = '';
    foreach ($csyn_sr_options as $key => $option) {
        if ($key != 'text_with_spintax') {
            $data_raw .= $key . '=' . urlencode(trim($option)) . '&';
        }
    }
    if (!isset($csyn_sr_options['text_with_spintax']) || $csyn_sr_options['text_with_spintax'] == 'false') {
        $data_raw .= 'action=unique_variation&text=' . urlencode($content);
    } else {
        $data_raw .= 'action=text_with_spintax&text=' . urlencode($content);
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://www.spinrewriter.com/action/api');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_raw);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = trim(curl_exec($ch));
    curl_close($ch);
    $api_response_interpreted = json_decode($response, true);
    if ($api_response_interpreted['status'] == 'OK') {
        return $api_response_interpreted['response'];
    }
    return $content;
}

function csyn_chimprewriter($content) {
    $csyn_sp_options = get_option(CSYN_CHIMPREWRITER_OPTIONS);
    $url = '';
    foreach ($csyn_sp_options as $key => $option) {
        if (strlen($url) > 1) {
            $url .= '&';
        }
        $url .= $key . '=' . urlencode(trim($option));
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://api.chimprewriter.com/GlobalSpin?' . $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $content);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = trim(curl_exec($ch));
    curl_close($ch);
    if ($result != '' && strpos($result, 'Failure:') !== 0 && strpos($result, 'Failed:') !== 0) {
        return $result;
    }
    return $content;
}

function csyn_morph_content($content) {
    global $csyn_syndicator;
    if (isset($csyn_syndicator->current_feed['options']['spinner'])) {
        $spinner = $csyn_syndicator->current_feed['options']['spinner'];
    } else {
        $spinner = $csyn_syndicator->global_options['spinner'];
    }
    switch ($spinner) {
        case CSYN_SPINNERCHIEF:
            $content = csyn_spinnerchief($content);
            break;
        case CSYN_SPINREWRITER:
            $content = csyn_spinrewriter($content);
            break;
        case CSYN_CHIMPREWRITER:
            $content = csyn_chimprewriter($content);
            break;
        case CSYN_WORDAI:
            $content = csyn_wordai($content);
            break;
        case CSYN_XSPINNER:
            $content = csyn_xspinner($content);
            break;
    }
    return $content;
}

function csyn_modify_post_content($content, $is_runtime = false, $inc_footers = true) {
    global $csyn_syndicator;
    if (!$is_runtime) {
        if ($inc_footers) {
            $footers = explode(CSYN_MORE, stripslashes($csyn_syndicator->current_feed['options']['post_footer']));
        }
    } else {
        if ($inc_footers) {
            $footers = explode(CSYN_MORE, stripslashes($csyn_syndicator->global_options['post_footer']));
        }
    }
    if (isset($footers) && sizeof($footers) > 0) {
        $footer = $footers[mt_rand(0, sizeof($footers) - 1)];
        if (!$is_runtime) {
            if (isset($csyn_syndicator->post['link'])) {
                $footer = str_replace('####post_link####', $csyn_syndicator->post['link'], $footer);
                $footer = str_replace('%link%', $csyn_syndicator->post['link'], $footer);
            }
        }
        $content .= $footer;
    }
    return $content;
}

function csyn_runtime_post_modification($content) {
    if (get_option(CSYN_POST_IMAGES) == 'hide_all') {
        $content = preg_replace('/<img.+?src=["\'].+?["\'].*?>/is', '', $content);
    } elseif (get_option(CSYN_POST_IMAGES) == "hide_first") {
        $content = preg_replace('/<img.+?src=["\'].+?["\'].*?>/is', '', $content, 1);
    }
    $rel = array('noopener');
    if (get_option(CSYN_URLS_NOFOLLOW) == 'on') {
        $rel[] = 'nofollow';
    }
    if (get_option(CSYN_URLS_NOREFERRER) == 'on') {
        $rel[] = 'noreferrer';
    }
    $params = ' rel="' . implode(' ', $rel) . '"';
    if (get_option(CSYN_URLS_TARGET_BLANK) == 'on') {
        $params .= ' target="_blank"';
    }
    $content = preg_replace_callback("/\<a[^>]+?href[^>]*?=[^>]*?['\"]?(https?:\/\/[^>'\"]+)['\"]?[^>]*?>/uis", function ($matches) use ($params) {
        if (stripos($matches[1], 'http') === 0 && mb_strtolower(parse_url($matches[1], PHP_URL_HOST)) !== mb_strtolower(parse_url(get_site_url(), PHP_URL_HOST))) {
            $href = $matches[0];
            $href = preg_replace("/\s+?target[^>]*?=[^>]*?['\"]?[^>'\"]+['\"]?/uis", '', $href);
            $href = preg_replace("/\s+?rel[^>]*?=[^>]*?['\"]?[^>'\"]+['\"]?/uis", '', $href);
            $href = preg_replace("/\s+?href[^>]*?=[^>]*?/uis", $params . ' href=', $href);
            if (get_option(CSYN_URLS_ENCRYPT) == "on") {
                $href = str_replace($matches[1], '?out=' . urlencode(base64_encode(csyn_xor($matches[1], get_option(CSYN_RAND_SHA)))), $href);
            }
            return $href;
        } else {
            return $matches[0];
        }
    }, $content);
    return $content;
}

function csyn_apply_runtime_changes($content) {
    return csyn_modify_post_content($content, true);
}

function csyn_options_menu() {
    global $csyn_message;
    if (isset($_POST['submit_options']) && check_admin_referer('general_settings')) {
        if (isset($_POST[CSYN_PSEUDO_CRON_INTERVAL]) && intval($_POST[CSYN_PSEUDO_CRON_INTERVAL]) > 0) {
            $pseudo_cron_interval = intval($_POST[CSYN_PSEUDO_CRON_INTERVAL]);
        } else {
            $pseudo_cron_interval = 1;
        }
        if (update_option(CSYN_RSS_PULL_MODE, $_POST[CSYN_RSS_PULL_MODE])) {
            wp_clear_scheduled_hook('update_by_wp_cron');
        }
        if (update_option(CSYN_PSEUDO_CRON_INTERVAL, $pseudo_cron_interval)) {
            wp_clear_scheduled_hook('update_by_wp_cron');
        }
        update_option(CSYN_FULL_TEXT_EXTRACTOR, $_POST[CSYN_FULL_TEXT_EXTRACTOR]);
        update_option(CSYN_AMAZON_TAG, $_POST[CSYN_AMAZON_TAG]);
        update_option(CSYN_DISABLE_DUPLICATION_CONTROL, isset($_POST[CSYN_DISABLE_DUPLICATION_CONTROL]) ? 'on' : '');
        update_option(CSYN_SORT_FEED_SOURCES, isset($_POST[CSYN_SORT_FEED_SOURCES]) ? 'on' : '');
        update_option(CSYN_ENABLE_DEBUG_MODE, isset($_POST[CSYN_ENABLE_DEBUG_MODE]) ? 'on' : '');
        update_option(CSYN_SHUFFLE_PROXIES, isset($_POST[CSYN_SHUFFLE_PROXIES]) ? 'on' : '');
        update_option(CSYN_URLS_TARGET_BLANK, isset($_POST[CSYN_URLS_TARGET_BLANK]) ? 'on' : '');
        update_option(CSYN_URLS_NOFOLLOW, isset($_POST[CSYN_URLS_NOFOLLOW]) ? 'on' : '');
        update_option(CSYN_URLS_NOREFERRER, isset($_POST[CSYN_URLS_NOREFERRER]) ? 'on' : '');
        update_option(CSYN_URLS_ENCRYPT, isset($_POST[CSYN_URLS_ENCRYPT]) ? 'on' : '');
        update_option(CSYN_POST_IMAGES, $_POST[CSYN_POST_IMAGES]);
        update_option(CSYN_LINK_TO_SOURCE, isset($_POST[CSYN_LINK_TO_SOURCE]) ? 'on' : '');
        update_option(CSYN_CANONICAL_LINK, isset($_POST[CSYN_CANONICAL_LINK]) ? 'on' : '');
        update_option(CSYN_KEEP_IMAGES, isset($_POST[CSYN_KEEP_IMAGES]) ? 'on' : '');
        echo '<div id="message" class="notice updated"><p><strong>Settings saved.</strong></p></div>';
    }
    ?>
    <div class="wrap">
        <h2>General Settings</h2>
        <div class="metabox-holder postbox-container">
            <?php
            $problems = '';
            $upload_path = wp_upload_dir();
            if (!is_writable($upload_path['path'])) {
                $problems .= "Your " . $upload_path['path'] . " folder is not writable. You must chmod it to 777 if you want to use the \"Store Images Locally\" option.\n<br />";
            }
            if (!function_exists('mb_convert_case')) {
                $problems .= "The required <a href=\"http://php.net/manual/en/book.mbstring.php\" target=\"_blank\">mbstring</a> PHP extension is not installed. You must install it in order to make CyberSEO work properly.\n<br />";
            }
            if (!function_exists("gd_info") || !function_exists("getimagesize") || !function_exists("image_type_to_extension")) {
                $problems .= "The required <a href=\"http://php.net/manual/en/book.image.php\" target=\"_blank\">GD</a> PHP extension is not installed. You must install it you want to use the \"Store Images Locally\" option.\n<br />";
            }
            if (!function_exists('curl_init') && !ini_get('allow_url_fopen')) {
                $problems .= "PHP variable <a href=\"http://php.net/manual/en/filesystem.configuration.php#ini.allow-url-fopen\" target=\"_blank\">allow_url_fopen</a> is disabled. You must enable it in order to make CyberSEO work properly.\n<br />";
            }
            if ($problems != '') {
                echo "<div id=\"message\" class=\"error\"><p>$problems</p></div>";
            }
            ?>
            <?php
            echo $csyn_message;
            ?>
            <form method="post" action="<?php echo csyn_REQUEST_URI(); ?>" name="general_settings">
                <div class="section" style="display:block">
                    <table class="form-table">
                        <tr>
                            <th scope="row">RSS pull mode</th>
                            <td>
                                <select name="<?php echo CSYN_RSS_PULL_MODE; ?>" onchange="changeMode();"<?php
                                if (defined('CSYN_ENABLE_RSS_PULL_MODE') && !CSYN_ENABLE_RSS_PULL_MODE) {
                                    echo "disabled";
                                }
                                ?>><?php
                                            echo '<option ' . ((get_option(CSYN_RSS_PULL_MODE) == "auto") ? 'selected ' : '') . 'value="auto">auto</option>';
                                            echo '<option ' . ((get_option(CSYN_RSS_PULL_MODE) == "cron") ? 'selected ' : '') . 'value="cron">by cron job or manually</option>';
                                            ?>
                                </select>
                                <p id="auto" class="description">
                                    In this mode, the CyberSEO plugin uses WordPress pseudo cron, which will be executed by the WordPress every <input type="text" name="<?php echo CSYN_PSEUDO_CRON_INTERVAL; ?>" size="1" value="<?php echo get_option(CSYN_PSEUDO_CRON_INTERVAL); ?>"> minutes.<br />
                                    The pseudo cron will trigger when someone visits your WordPress site, if the scheduled time has passed.
                                    <?php
                                    if (WP_CACHE) {
                                        echo '<br /><br />It seems you are using some caching plugin. Make sure to add the following URL into the exceptions list of your caching plugin:<br /><br /><code>' . get_option('siteurl') . "/?pull-feeds=" . get_option(CSYN_CRON_MAGIC) . '</code>';
                                    }
                                    ?>
                                </p>
                                <p id="cron" class="description">
                                    In this mode, you need to manually configure <strong><a href="http://en.wikipedia.org/wiki/Cron" target="_blank">cron</a></strong> at your host. For example, if you want run a cron job once a hour, just add the following line into your crontab:<br />
                                    <strong><?php echo "0 * * * * /usr/bin/curl --silent " . get_option('siteurl') . "/?pull-feeds=" . get_option(CSYN_CRON_MAGIC); ?></strong>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Open links in a new window</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_URLS_TARGET_BLANK; ?>"
                                <?php
                                if (get_option(CSYN_URLS_TARGET_BLANK) == "on") {
                                    echo "checked";
                                }
                                ?> />
                                makes all the external links to open in a new window (use target="_blank").
                                <p class="description">This is a runtime option. It affects all existing parts at once. The effect is instantaneous and lasts while the option is enabled. When disabled, the effect disappears.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Use rel="nofollow"</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_URLS_NOFOLLOW; ?>"
                                <?php
                                if (get_option(CSYN_URLS_NOFOLLOW) == "on") {
                                    echo "checked";
                                }
                                ?> />
                                applies "nofollow" HTML attribute value to the external links in all posts.
                                <p class="description">This is a runtime option. It affects all existing parts at once. The effect is instantaneous and lasts while the option is enabled. When disabled, the effect disappears.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Use rel="noreferrer"</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_URLS_NOREFERRER; ?>"
                                <?php
                                if (get_option(CSYN_URLS_NOREFERRER) == 'on') {
                                    echo 'checked';
                                }
                                ?> />
                                applies "noreferrer" HTML attribute value to the external links in all posts.
                                <p class="description">This is a runtime option. It affects all existing parts at once. The effect is instantaneous and lasts while the option is enabled. When disabled, the effect disappears.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Encrypt links</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_URLS_ENCRYPT; ?>"
                                <?php
                                if (get_option(CSYN_URLS_ENCRYPT) == "on") {
                                    echo "checked";
                                }
                                ?> />
                                when enabled, all the external links will be encrypted.
                                <p class="description">This is a runtime option. It affects all existing parts at once. The effect is instantaneous and lasts while the option is enabled. When disabled, the effect disappears.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Post images</th>
                            <td>
                                <select name="<?php echo CSYN_POST_IMAGES; ?>" size="1">
                                    <?php
                                    echo '<option ' . ((get_option(CSYN_POST_IMAGES) == "keep") ? 'selected ' : '') . 'value="keep">show all images</option>';
                                    echo '<option ' . ((get_option(CSYN_POST_IMAGES) == "hide_first") ? 'selected ' : '') . 'value="hide_first">hide first image</option>';
                                    echo '<option ' . ((get_option(CSYN_POST_IMAGES) == "hide_featured_in_single") ? 'selected ' : '') . 'value="hide_featured_in_single">hide post thumbnail</option>';
                                    echo '<option ' . ((get_option(CSYN_POST_IMAGES) == "hide_all") ? 'selected ' : '') . 'value="hide_all">hide all images but post thumbnail</option>';
                                    ?>
                                </select>
                                <p class="description">Enable this option to dynamically show or hide images when post is displayed.</p>
                                <p class="description">This is a runtime option. It affects all existing parts at once. The effect is instantaneous and lasts while the option is enabled. When disabled, the effect disappears.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Canonical link</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_CANONICAL_LINK; ?>"
                                <?php
                                if (get_option(CSYN_CANONICAL_LINK) == "on") {
                                    echo "checked";
                                }
                                ?> /> when enabled the canonical link to source will be added to the post head metadata. Use this option to give a credit to the original content owner.
                                <p class="description">This is a runtime option. It affects all existing parts at once. The effect is instantaneous and lasts while the option is enabled. When disabled, the effect disappears.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Keep downloaded images</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_KEEP_IMAGES; ?>"
                                <?php
                                if (get_option(CSYN_KEEP_IMAGES) == "on") {
                                    echo "checked";
                                }
                                ?> /> keeps all the downloaded images and videos when a post is permanently deleted on "Empty Trash" or when the <a href="https://developer.wordpress.org/reference/hooks/before_delete_post/" target="_blank">before_delete_post</a> WordPress hook is triggered.
                                <p class="description">This is a runtime option. It affects all existing parts at once. The effect is instantaneous and lasts while the option is enabled. When disabled, the effect disappears.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Link to source</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_LINK_TO_SOURCE; ?>"
                                <?php
                                if (get_option(CSYN_LINK_TO_SOURCE) == "on") {
                                    echo "checked";
                                }
                                ?> />
                                when enabled the post titles will be linked to their source pages.
                                <p class="description">This is a runtime option. It affects all existing parts at once. The effect is instantaneous and lasts while the option is enabled. When disabled, the effect disappears.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Full text extractor URL</th>
                            <td>
                                <input type="text" name="<?php echo CSYN_FULL_TEXT_EXTRACTOR; ?>" size="80" value="<?php echo stripslashes(get_option(CSYN_FULL_TEXT_EXTRACTOR)); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Amazon associate tag</th>
                            <td>
                                <input type="text" name="<?php echo CSYN_AMAZON_TAG; ?>" size="80" value="<?php echo stripslashes(get_option(CSYN_AMAZON_TAG)); ?>">
                                <p class="description">Enter your Amazon associate tag here. Associates earn commissions by using their own websites to refer sales to Amazon.com.
                                    To get a commission, an Associate must have an Associate tag. The Associate tag is an automatically generated unique identifier that you will need to get paid for sales.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Disable feed duplication control</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_DISABLE_DUPLICATION_CONTROL; ?>"
                                <?php
                                if (get_option(CSYN_DISABLE_DUPLICATION_CONTROL) == "on") {
                                    echo "checked";
                                }
                                ?> />
                                allows the CyberSEO plugin to add more than one copy of the same feed / content source. Don't confuse it with duplicate post check, which is a different option.
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Sort feed sources by</th>
                            <td>
                                <select name="<?php echo CSYN_SORT_FEED_SOURCES; ?>" onchange="changeMode();">
                                    <?php
                                    echo '<option ' . ((get_option(CSYN_SORT_FEED_SOURCES) == "name") ? 'selected ' : '') . 'value="name">name</option>';
                                    echo '<option ' . ((get_option(CSYN_SORT_FEED_SOURCES) == "date") ? 'selected ' : '') . 'value="date">date</option>';
                                    ?>
                                </select>
                                choose source feed sorting order in the CyberSEO Lite Syndicator.
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Enable debug mode</th>
                            <td>
                                <input type="checkbox" name="<?php echo CSYN_ENABLE_DEBUG_MODE; ?>"
                                <?php
                                if (get_option(CSYN_ENABLE_DEBUG_MODE) == "on") {
                                    echo "checked";
                                }
                                ?> />
                                enables PHP debug mode.
                            </td>
                        </tr>
                    </table>
                    <br />
                    <div style="text-align:left;">
                        <input type="submit" name="submit_options" class="button-primary" value="Update options" />&nbsp;&nbsp;<input type="button" name="cancel" value="Cancel" class="button" onclick="javascript:history.go(-1)" />
                    </div>
                    <?php wp_nonce_field('general_settings'); ?>
                </div>
            </form>
        </div>
    </div>
    <script type='text/javascript'>
        changeMode();
    </script>
    <?php
}

function csyn_set_feed_options($options) {
    $result = [];
    foreach ($options as $option => $value) {
        if (isset($_POST[$option])) {
            if (is_integer($value)) {
                if ($option == 'date_min' || $option == 'date_max') {
                    $result[$option] = intval($_POST[$option]);
                } else {
                    $result[$option] = abs(intval($_POST[$option]));
                }
            } else {
                $result[$option] = $_POST[$option];
            }
        } else {
            if (is_array($value)) {
                $result[$option] = [];
            } if (is_integer($value)) {
                $result[$option] = 0;
            } else {
                $result[$option] = '';
            }
        }
    }
    if ($result['date_min'] > $result['date_max']) {
        $min = $result['date_min'];
        $result['date_min'] = $result['date_max'];
        $result['date_max'] = $min;
    }
    return $result;
}

function csyn_xml_syndicator_menu() {
    global $csyn_syndicator, $wpdb;
    ?>
    <div class="wrap">
        <h2>
            CyberSEO Lite Syndicator
        </h2>
        <br />
        <?php
        if (is_admin()) {
            if (isset($_POST['import_feeds']) && check_admin_referer('xml_syndicator')) {
                if ($_FILES['file']['error'] === UPLOAD_ERR_OK) {
                    $file = file_get_contents($_FILES['file']['tmp_name']);
                    unlink($_FILES['file']['tmp_name']);
                    $csyn_syndicator->unserializeFeeds($file);
                }
            }
        }
        $min_update_time = 0;
        if (isset($_GET['edit-feed-id'])) {
            $csyn_syndicator->global_options = $csyn_syndicator->feeds[(int) $_GET['edit-feed-id']]['options'];
            $source = $csyn_syndicator->feeds[(int) $_GET['edit-feed-id']]['url'];
            $source = $csyn_syndicator->fixURL($source);
            $csyn_syndicator->feedPreview($source, true);
            $csyn_syndicator->showSettings(true, $csyn_syndicator->feeds[(int) $_GET['edit-feed-id']]['options']);
        } elseif (isset($_POST['update_feed_settings']) && check_admin_referer('xml_syndicator')) {
            if (mb_strlen(trim(stripslashes(htmlspecialchars($_POST['feed_title'], ENT_NOQUOTES)))) == 0) {
                $_POST['feed_title'] = 'no name';
            }
            $csyn_syndicator->feeds[(int) $_POST['feed_id']]['title'] = trim(stripslashes(htmlspecialchars($_POST['feed_title'], ENT_NOQUOTES)));
            if (isset($_POST['url'])) {
                $new_url = trim($_POST['url']);
                $old_url = $csyn_syndicator->feeds[(int) $_POST['feed_id']]['url'];
                if (stripos($new_url, 'http') === 0 && $new_url != $old_url) {
                    $query = "UPDATE {$wpdb->prefix}postmeta SET meta_value = '" . addslashes($new_url) . "' WHERE meta_key = 'cyberseo_rss_source' AND meta_value = '" . addslashes($old_url) . "'";
                    $wpdb->get_results($query);
                    $csyn_syndicator->feeds[(int) $_POST['feed_id']]['url'] = $new_url;
                }
            }
            if ((int) $_POST['interval'] == 0) {
                $csyn_syndicator->feeds[(int) $_POST['feed_id']]['options']['interval'] = 0;
            } else {
                $csyn_syndicator->feeds[(int) $_POST['feed_id']]['options']['interval'] = max($min_update_time, abs((int) $_POST['interval']));
            }
            $csyn_syndicator->feeds[(int) $_POST['feed_id']]['options'] = csyn_set_feed_options($csyn_syndicator->feeds[(int) $_POST['feed_id']]['options']);
            update_option(CSYN_SYNDICATED_FEEDS, $csyn_syndicator->feeds);
            $csyn_syndicator->showMainPage(false);
        } elseif (isset($_POST['check_for_updates']) && check_admin_referer('xml_syndicator')) {
            $csyn_syndicator->show_report = true;
            if (isset($_POST['feed_ids'])) {
                $csyn_syndicator->syndicateFeeds($_POST['feed_ids'], false);
            } else {
                echo '<div id="message" class="notice updated"><p><strong>No feeds selected.</strong></p></div>';
            }
            $csyn_syndicator->showMainPage(false);
        } elseif (isset($_POST['delete_feeds']) && isset($_POST['feed_ids']) && check_admin_referer('xml_syndicator')) {
            $csyn_syndicator->deleteFeeds($_POST['feed_ids'], false, true);
            $csyn_syndicator->showMainPage(false);
        } elseif (isset($_POST['delete_posts']) && isset($_POST['feed_ids']) && check_admin_referer('xml_syndicator')) {
            $csyn_syndicator->deleteFeeds($_POST['feed_ids'], true, false);
            $csyn_syndicator->showMainPage(false);
        } elseif (isset($_POST['delete_feeds_and_posts']) && isset($_POST['feed_ids']) && check_admin_referer('xml_syndicator')) {
            $csyn_syndicator->deleteFeeds($_POST['feed_ids'], true, true);
            $csyn_syndicator->showMainPage(false);
        } elseif (isset($_POST['new_feed']) && check_admin_referer('xml_syndicator')) {
            $source = $_POST['feed_url'];
            if (isset($_POST['user_agent']) && strlen(trim($_POST['user_agent']))) {
                $csyn_syndicator->global_options['user_agent'] = $_POST['user_agent'];
            }
            $options = $csyn_syndicator->global_options;
            $source = $csyn_syndicator->fixURL($source);
            if ($csyn_syndicator->feedPreview($source, false)) {
                $options['undefined_category'] = 'use_global';
                $csyn_syndicator->showSettings(true, $options);
            } else {
                $csyn_syndicator->showMainPage(false);
            }
        } elseif (isset($_POST['syndicate_feed']) && check_admin_referer('xml_syndicator')) {
            $date_min = (int) $_POST['date_min'];
            $date_max = (int) $_POST['date_max'];
            if ($date_min > $date_max) {
                $date_min = $date_max;
            }
            if (mb_strlen(trim(stripslashes(htmlspecialchars($_POST['feed_title'], ENT_NOQUOTES)))) == 0) {
                $_POST['feed_title'] = 'no name';
            }
            if ((int) $_POST['interval'] == 0) {
                $interval = 0;
            } else {
                $interval = max($min_update_time, abs((int) $_POST['interval']));
            }
            $feed = [];
            $source = @unserialize(@gzuncompress(@base64_decode($_POST['feed_url'])));
            if (is_object($source)) {
                $feed['url'] = $source;
            } else {
                $feed['url'] = $_POST['feed_url'];
            }
            $feed['title'] = trim(stripslashes(htmlspecialchars($_POST['feed_title'], ENT_NOQUOTES)));
            $feed['updated'] = 0;
            $feed['options']['interval'] = $interval;
            $feed['options'] = csyn_set_feed_options($csyn_syndicator->global_options);
            $id = array_push($csyn_syndicator->feeds, $feed);
            $csyn_syndicator->feeds_updated[$id - 1] = 0;
            if ((intval($interval)) != 0) {
                $csyn_syndicator->show_report = false;
                $csyn_syndicator->syndicateFeeds(array($id), false);
            }
            update_option(CSYN_SYNDICATED_FEEDS, $csyn_syndicator->feeds);
            $csyn_syndicator->showMainPage(false);
        } elseif (isset($_POST["update_default_settings"]) && check_admin_referer('xml_syndicator')) {
            $date_min = (int) $_POST['date_min'];
            $date_max = (int) $_POST['date_max'];
            if ($date_min > $date_max) {
                $date_min = $date_max;
            }
            $csyn_syndicator->global_options['interval'] = max($min_update_time, abs((int) $_POST['interval']));
            $csyn_syndicator->global_options = csyn_set_feed_options($csyn_syndicator->global_options);
            update_option(CSYN_FEED_OPTIONS, $csyn_syndicator->global_options);
            $csyn_syndicator->showMainPage(false);
        } elseif (isset($_POST["alter_default_settings"]) && check_admin_referer('xml_syndicator')) {
            $csyn_syndicator->showSettings(false, $csyn_syndicator->global_options);
        } else {
            $csyn_syndicator->showMainPage(false);
        }
        ?>
    </div>
    <?php
}

function csyn_synonymizer_menu() {
    $csyn_sc_options = get_option(CSYN_SPINNERCHIEF_OPTIONS);
    $csyn_sr_options = get_option(CSYN_SPINREWRITER_OPTIONS);
    $csyn_sp_options = get_option(CSYN_CHIMPREWRITER_OPTIONS);
    $csyn_xs_options = get_option(CSYN_XSPINNER_OPTIONS);
    $csyn_wa_options = get_option(CSYN_WORDAI_OPTIONS);
    if (isset($_POST['submit_synonymizer_settings']) && check_admin_referer('synonymizer_settings')) {
        $csyn_sc_options['spintype'] = $_POST['sc_spintype'];
        $csyn_sc_options['username'] = $_POST['sc_username'];
        $csyn_sc_options['password'] = $_POST['sc_password'];
        $csyn_sc_options['thesaurus'] = $_POST['sc_thesaurus'];
        $csyn_sc_options['spinfreq'] = $_POST['sc_spinfreq'];
        $csyn_sc_options['wordquality'] = $_POST['sc_wordquality'];
        $csyn_sc_options['original'] = $_POST['sc_original'];
        $csyn_sc_options['orderly'] = isset($_POST['sc_orderly']) ? '1' : '0';
        $csyn_sc_options['protectwords'] = $_POST['sc_protectwords'];
        $csyn_sc_options['rule'] = $_POST['sc_rule'];
        $csyn_sc_options['replacetype'] = $_POST['sc_replacetype'];
        $csyn_sc_options['UseGrammarAI'] = isset($_POST['sc_UseGrammarAI']) ? '1' : '0';
        $csyn_sc_options['pos'] = isset($_POST['sc_pos']) ? '1' : '0';
        $csyn_sc_options['protecthtml'] = isset($_POST['sc_protecthtml']) ? '1' : '0';
        $csyn_sc_options['tagprotect'] = $_POST['sc_tagprotect'];
        update_option(CSYN_SPINNERCHIEF_OPTIONS, $csyn_sc_options);
        $csyn_sr_options['email_address'] = $_POST['sr_email_address'];
        $csyn_sr_options['api_key'] = $_POST['sr_api_key'];
        $csyn_sr_options['protected_terms'] = $_POST['sr_protected_terms'];
        $csyn_sr_options['auto_protected_terms'] = isset($_POST['sr_auto_protected_terms']) ? 'true' : 'false';
        $csyn_sr_options['confidence_level'] = $_POST['sr_confidence_level'];
        $csyn_sr_options['auto_sentences'] = isset($_POST['sr_auto_sentences']) ? 'true' : 'false';
        $csyn_sr_options['auto_paragraphs'] = isset($_POST['sr_auto_paragraphs']) ? 'true' : 'false';
        $csyn_sr_options['auto_new_paragraphs'] = isset($_POST['sr_auto_new_paragraphs']) ? 'true' : 'false';
        $csyn_sr_options['auto_sentence_trees'] = isset($_POST['sr_auto_sentence_trees']) ? 'true' : 'false';
        $csyn_sr_options['use_only_synonyms'] = isset($_POST['sr_use_only_synonyms']) ? 'true' : 'false';
        $csyn_sr_options['text_with_spintax'] = isset($_POST['sr_text_with_spintax']) ? 'true' : 'false';
        $csyn_sr_options['nested_spintax'] = isset($_POST['sr_nested_spintax']) ? 'true' : 'false';
        update_option(CSYN_SPINREWRITER_OPTIONS, $csyn_sr_options);
        $csyn_wa_options['email'] = $_POST['wa_email'];
        $csyn_wa_options['key'] = $_POST['wa_key'];
        $csyn_wa_options['uniqueness'] = $_POST['wa_uniqueness'];
        $csyn_wa_options['return_rewrites'] = isset($_POST['wa_return_rewrites']) ? 'true' : 'false';
        $csyn_wa_options['protect_words'] = isset($_POST['wa_protect_words']) ? 'true' : 'false';
        $csyn_wa_options['use_custom_synonyms'] = isset($_POST['wa_use_custom_synonyms']) ? 'true' : 'false';
        update_option(CSYN_WORDAI_OPTIONS, $csyn_wa_options);
        $csyn_sp_options['email'] = $_POST['sp_email'];
        $csyn_sp_options['apikey'] = $_POST['sp_apikey'];
        $csyn_sp_options['quality'] = $_POST['sp_quality'];
        $csyn_sp_options['posmatch'] = $_POST['sp_posmatch'];
        $csyn_sp_options['protectedterms'] = $_POST['sp_protectedterms'];
        $csyn_sp_options['rewrite'] = isset($_POST['sp_rewrite']) ? '1' : '0';
        $csyn_sp_options['phraseignorequality'] = isset($_POST['sp_phraseignorequality']) ? '1' : '0';
        $csyn_sp_options['spinwithinspin'] = isset($_POST['sp_spinwithinspin']) ? '1' : '0';
        $csyn_sp_options['spinwithinhtml'] = isset($_POST['sp_spinwithinhtml']) ? '1' : '0';
        $csyn_sp_options['applyinstantunique'] = isset($_POST['sp_applyinstantunique']) ? '1' : '0';
        $csyn_sp_options['fullcharset'] = isset($_POST['sp_fullcharset']) ? '1' : '0';
        $csyn_sp_options['sp_spintidy'] = isset($_POST['sp_spintidy']) ? '1' : '0';
        $csyn_sp_options['maxspindepth'] = isset($_POST['sp_maxspindepth']) ? '1' : '0';
        $csyn_sp_options['tagprotect'] = $_POST['sp_tagprotect'];
        update_option(CSYN_CHIMPREWRITER_OPTIONS, $csyn_sp_options);
        $csyn_xs_options['post_url'] = $_POST['xs_post_url'];
        $csyn_xs_options['spintype'] = $_POST['xs_spintype'];
        $csyn_xs_options['removeold'] = $_POST['xs_removeold'];
        $csyn_xs_options['protectw'] = $_POST['xs_protectw'];
        $csyn_xs_options['spinway'] = $_POST['xs_spinway'];
        $csyn_xs_options['thesaurus'] = $_POST['xs_thesaurus'];
        $csyn_xs_options['post_url'] = $_POST['xs_post_url'];
        update_option(CSYN_XSPINNER_OPTIONS, $csyn_xs_options);
        echo '<div id="message" class="notice updated"><p><strong>Settings saved.</strong></p></div>';
    }
    ?>
    <div class="wrap">
        <h2>Content Spinners</h2>
        <form method="post" name="synonymizer">
            <div class="metabox-holder postbox-container" style="width:100%;">
                <ul class="tabs">
                    <li class="active" rel="wordai">WordAi</li>
                    <li rel="spinnerchief">SpinnerChief</li>
                    <li rel="spinrewriter">SpinRewriter</li>
                    <li rel="spinchimp">ChimpRewriter</li>
                    <li rel="xspinner">X-Spinner</li>
                </ul>
                <div class="tab_container">
                    <div id="wordai" class="tab_content">
                        <table class="form-table">
                            <th scope="row">Account info</th>
                            <td>
                                <?php
                                echo 'Please enter your email and password below or apply for your <a href="https://www.cyberseo.net/partners/wordai.php" target="_blank"><strong>WordAi</strong></a> account.';
                                ?>
                            </td>
                            <tr>
                                <th scope="row">Email</th>
                                <td>
                                    <input type="text" name="wa_email" size="60" value="<?php echo $csyn_wa_options['email'];
                                ?>">
                                    <p class="description">your WordAi login email.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Key</th>
                                <td>
                                    <input <?php echo ((CSYN_HIDE_PASSWORDS) ? 'type="password"' : 'type="text"'); ?> name="wa_key" size="60" value="<?php echo $csyn_wa_options['key']; ?>">
                                    <p class="description">your WordAi API key.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Uniqueness</th>
                                <td>
                                    <select name="wa_uniqueness" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_wa_options['uniqueness'] == "1") ? 'selected ' : '') . 'value="1">more conservative</option>';
                                        echo '<option ' . (($csyn_wa_options['uniqueness'] == "2") ? 'selected ' : '') . 'value="2">regular</option>';
                                        echo '<option ' . (($csyn_wa_options['uniqueness'] == "3") ? 'selected ' : '') . 'value="3">more adventurous</option>';
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Return rewrites</th>
                                <td>
                                    <input type="checkbox" name="wa_return_rewrites"
                                    <?php
                                    if ($csyn_wa_options['return_rewrites'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    enable it if you want to receive a rewritten article. Otherwise, the output returned will be the <a href="https://www.cyberseo.net/blog/what-is-spintax-and-how-to-use-it/" target=_blank">Spintax</a> of your text.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Protect words</th>
                                <td>
                                    <input type="checkbox" name="wa_protect_words"
                                    <?php
                                    if ($csyn_wa_options['protect_words'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    enable it to use the protect words master settings in your account, which can be viewed and updated <a href="https://wai.wordai.com/rewrite_settings" target="_blank">here</a>.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Use custom synonyms</th>
                                <td>
                                    <input type="checkbox" name="wa_use_custom_synonyms"
                                    <?php
                                    if ($csyn_wa_options['use_custom_synonyms'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    enable it to use the custom synonyms master settings in your account, which can be viewed and updated <a href="https://wai.wordai.com/rewrite_settings" target="_blank">here</a>.
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div id="spinnerchief" class="tab_content">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Account info</th>
                                <td>
                                    <?php
                                    if ($csyn_sc_options['username'] != '' && $csyn_sc_options['password'] != '') {
                                        $data = $result = [];
                                        for ($i = 1; $i < 3; $i++) {
                                            $url = 'http://api.spinnerchief.com:443/apikey=' . urlencode($csyn_sc_options['apikey']) . '&username=' . urlencode($csyn_sc_options['username']) . '&password=' . urlencode($csyn_sc_options['password']) . '&querytimes=2';
                                            $result[] = base64_decode(trim(csyn_curl_post($url, $data, $info, 10)));
                                        }
                                        echo 'Daily Limit: ' . $result[0] . '. Requests available: ' . $result[1] . '.';
                                    } else {
                                        echo 'Please enter your email and API key below or apply for your free <a href="https://www.cyberseo.net/partners/spinnerchief.php" target="_blank"><strong>SpinnerChief</strong></a> account.';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Username</th>
                                <td>
                                    <input type="text" name="sc_username" size="60" value="<?php echo $csyn_sc_options['username']; ?>">
                                    <p class="description">your <strong>SpinnerChief</strong> username.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Password</th>
                                <td>
                                    <input <?php echo ((CSYN_HIDE_PASSWORDS) ? 'type="password"' : 'type="text"'); ?> name="sc_password" size="60" value="<?php echo $csyn_sc_options['password']; ?>">
                                    <p class="description">your <strong>SpinnerChief</strong> password.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Spin type</th>
                                <td>
                                    <select name="sc_spintype" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_sc_options['spintype'] == "0") ? 'selected ' : '') . 'value="0">0</option>';
                                        echo '<option ' . (($csyn_sc_options['spintype'] == "1") ? 'selected ' : '') . 'value="1">1</option>';
                                        ?>
                                    </select>
                                    when spin type = 0, SpinnerChief will return the spun article in Spintax format. When spin type = 1, SpinnerChief will return the spun article directly.
                                    <p class="description">This option can be useful for generation of unique feeds in <a href="https://www.cyberseo.net/morphing-rss-host-mode-content-spinner/" target="_blank">Morphing RSS host mode</a>. (PRO)</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Thesaurus</th>
                                <td>
                                    <input type="text" name="sc_thesaurus" size="60" value="<?php echo $csyn_sc_options['thesaurus']; ?>">
                                    <p class="description">the following rules are allowed: Arabic, Belarusian, Bulgarian, Croatian, Danish, Dutch, English, Filipino, Finnish, French, German,
                                        Greek, Hebrew,Indonesian, Italian, Lithuanian, Norwegian, Polish, Portuguese, Romanian, Slovak,
                                        Slovenian, Spanish, Swedish, Turkish, Vietnamese, users-defined thesaurus ID..</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Spin freq</th>
                                <td>
                                    <input type="text" name="sc_spinfreq" size="5" value="<?php echo $csyn_sc_options['spinfreq']; ?>">
                                    the Spin Freq means word spin frequency, for example if Spin Freq = 1, every word will be spun, if Spin Freq = 3, 1/3 of all words will be spun, etc.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Synonyms quality</th>
                                <td>
                                    <select name="sc_wordquality" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_sc_options['wordquality'] == "0") ? 'selected ' : '') . 'value="0">Best Thesaurus to spin</option>';
                                        echo '<option ' . (($csyn_sc_options['wordquality'] == "1") ? 'selected ' : '') . 'value="1">Better Thesaurus to spin</option>';
                                        echo '<option ' . (($csyn_sc_options['wordquality'] == "2") ? 'selected ' : '') . 'value="2">Good Thesaurus to spin</option>';
                                        echo '<option ' . (($csyn_sc_options['wordquality'] == "3") ? 'selected ' : '') . 'value="3">All Thesaurus to spin</option>';
                                        echo '<option ' . (($csyn_sc_options['wordquality'] == "9") ? 'selected ' : '') . 'value="9">Everyone\'s favorite to spin</option>';
                                        ?>
                                    </select>
                                    <p class="description">define the synonym table quality.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Don't use original word</th>
                                <td>
                                    <select name="sc_original" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_sc_options['original'] == "0") ? 'selected ' : '') . 'value="0">No</option>';
                                        echo '<option ' . (($csyn_sc_options['original'] == "1") ? 'selected ' : '') . 'value="1">Yes</option>';
                                        ?>
                                    </select>
                                    <p class="description">if "No", SpinnerChief will delete the original word in the return result.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Use synonyms orderly</th>
                                <td>
                                    <input type="checkbox" name="sc_orderly"
                                    <?php
                                    if ($csyn_sc_options['orderly'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if checked, SpinnerChief uses the thesaurus randomly to spin. Otherwise the thesaurus will be used in it's listed order.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Protect words</th>
                                <td>
                                    <input type="text" name="sc_protectwords" size="60" value="<?php echo $csyn_sc_options['protectwords']; ?>">
                                    <p class="description">when you set protectwords, the server will not spin words in the the protect words list, the format is word1,word2,word3,phrase1,phrase2.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Rule</th>
                                <td>
                                    <input type="text" name="sc_rule" size="60" value="<?php echo $csyn_sc_options['rule']; ?>">
                                    <p class="description">the following rules are allowed: arabic, belarusian, bulgarian,
                                        croatian, danish, dutch, english, filipino, finnish, french, german, greek, hebrew, indonesian, italian, lithuanian, norwegian, polish,  portuguese,romanian, slovak,
                                        slovenian, spanish, swedish, turkish, vietnamese, user-defined rule ID.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Replace type</th>
                                <td>
                                    <select name="sc_replacetype" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_sc_options['replacetype'] == "0") ? 'selected ' : '') . 'value="0">Replace phrase and word</option>';
                                        echo '<option ' . (($csyn_sc_options['replacetype'] == "1") ? 'selected ' : '') . 'value="1">Only replace phrase</option>';
                                        echo '<option ' . (($csyn_sc_options['replacetype'] == "2") ? 'selected ' : '') . 'value="2">Only replace word</option>';
                                        echo '<option ' . (($csyn_sc_options['replacetype'] == "3") ? 'selected ' : '') . 'value="3">Replace phrase first, then replace word till the article passes copyscape';
                                        echo '<option ' . (($csyn_sc_options['replacetype'] == "4") ? 'selected ' : '') . 'value="4">Spin the article to most unique</option>';
                                        echo '<option ' . (($csyn_sc_options['replacetype'] == "5") ? 'selected ' : '') . 'value="5">Spin the article to most readable</option>';
                                        ?>
                                    </select>
                                    <p class="description">define the replace type.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Enable grammar AI</th>
                                <td>
                                    <input type="checkbox" name="sc_UseGrammarAI"
                                    <?php
                                    if ($csyn_sc_options['UseGrammarAI'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if checked, the grammar correction will be performed.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Enable POS</th>
                                <td>
                                    <input type="checkbox" name="sc_pos"
                                    <?php
                                    if ($csyn_sc_options['pos'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if checked, the "part of speech" analysis will be performed.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Do not protect HTML</th>
                                <td>
                                    <input type="checkbox" name="sc_protecthtml"
                                    <?php
                                    if ($csyn_sc_options['protecthtml'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if checked, the SpinnerChief will not protect words in HTML tags in your article.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Tag protect</th>
                                <td>
                                    <input type="text" name="sc_tagprotect" size="60" value="<?php echo $csyn_sc_options['tagprotect']; ?>">
                                    <p class="description">this will protect the text between tags. For example if you want to protect the text between[ and ], ( and ), <- and ->, use the following string: "[],(),<- ->".</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div id="spinrewriter" class="tab_content">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Account info</th>
                                <td>
                                    <?php
                                    if ($csyn_sr_options['email_address'] == '' || $csyn_sr_options['api_key'] == '') {
                                        echo 'Please enter your email and API key below or apply for your <a href="https://www.cyberseo.net/partners/spinrewriter.php" target="_blank"><strong>SpinRewriter</strong></a> account.';
                                    } else {
                                        $url = 'http://www.spinrewriter.com/action/api';
                                        $data = [];
                                        $data['action'] = 'api_quota';
                                        $data['email_address'] = $csyn_sr_options['email_address'];
                                        $data['api_key'] = $csyn_sr_options['api_key'];
                                        $result = json_decode(csyn_curl_post($url, $data, $info, 10), true);
                                        echo $result['response'];
                                    }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Email address</th>
                                <td>
                                    <input type="text" name="sr_email_address" size="60" value="<?php echo $csyn_sr_options['email_address']; ?>">
                                    <p class="description">your <strong>SpinRewriter</strong> email address.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">API key</th>
                                <td>
                                    <input <?php echo ((CSYN_HIDE_PASSWORDS) ? 'type="password"' : 'type="text"'); ?> name="sr_api_key" size="60" value="<?php echo $csyn_sr_options['api_key']; ?>">
                                    <p class="description">your <strong>SpinRewriter</strong> API key.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Protected terms</th>
                                <td>
                                    <textarea cols="90" rows="5" wrap="off" name="sr_protected_terms" style="margin:0;height:10em;width:100%;"><?php echo $csyn_sr_options['protected_terms']; ?></textarea><br />
                                    <p class="description">a list of keywords and key phrases that you do NOT want to spin. One term per line.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Auto protected terms</th>
                                <td>
                                    <input type="checkbox" name="sr_auto_protected_terms"
                                    <?php
                                    if ($csyn_sr_options['auto_protected_terms'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    should SpinRewriter automatically protect all Capitalized Words except for those in the title of your original text?
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Confidence level</th>
                                <td>
                                    <select name="sr_confidence_level" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_sr_options['confidence_level'] == "low") ? 'selected ' : '') . 'value="low">low </option>';
                                        echo '<option ' . (($csyn_sr_options['confidence_level'] == "medium") ? 'selected ' : '') . 'value="medium">medium </option>';
                                        echo '<option ' . (($csyn_sr_options['confidence_level'] == "high") ? 'selected ' : '') . 'value="high">high </option>';
                                        ?>
                                    </select>
                                    the confidence level of the rewrite process.
                                    <p class="description"><strong>low</strong>: largest number of synonyms for various words and phrases, least readable unique variations of text;<br />
                                        <strong>medium</strong>: relatively reliable synonyms, usually well readable unique variations of text (default setting);<br />
                                        <strong>high</strong>: only the most reliable synonyms, perfectly readable unique variations of text.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Auto sentences</th>
                                <td>
                                    <input type="checkbox" name="sr_auto_sentences"
                                    <?php
                                    if ($csyn_sr_options['auto_sentences'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    should SpinRewriter spin complete sentences? If enabled, some sentences will be replaced with a (shorter) spun variation.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Auto new paragraphs</th>
                                <td>
                                    <input type="checkbox" name="sr_auto_new_paragraphs"
                                    <?php
                                    if ($csyn_sr_options['auto_new_paragraphs'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    should SpinRewriter automatically write additional paragraphs on its own? If enabled, the returned spun text will contain additional paragraphs.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Auto sentence trees</th>
                                <td>
                                    <input type="checkbox" name="sr_auto_sentence_trees"
                                    <?php
                                    if ($csyn_sr_options['auto_sentence_trees'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if enabled, SpinRewriter will change "If he is hungry, John eats." to "John eats if he is hungry." and "John eats and drinks." to "John drinks and eats."
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Use only synonyms</th>
                                <td>
                                    <input type="checkbox" name="sr_use_only_synonyms"
                                    <?php
                                    if ($csyn_sr_options['use_only_synonyms'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if enabled, SpinRewriter will never use any of the original words of phrases if there is a synonym available. This significantly improves the uniqueness of generated spun content.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Text with Spintax</th>
                                <td>
                                    <input type="checkbox" name="sr_text_with_spintax"
                                    <?php
                                    if ($csyn_sr_options['text_with_spintax'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if enabled, returns the processed spun text with Spintax. This option can be useful for generation of unique feeds in <a href="https://www.cyberseo.net/morphing-rss-host-mode-content-spinner/" target="_blank">Morphing RSS host mode</a>. (PRO)
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Nested Spintax</th>
                                <td>
                                    <input type="checkbox" name="sr_nested_spintax"
                                    <?php
                                    if ($csyn_sr_options['nested_spintax'] == 'true') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if enabled, the returned spun text might contain 2 levels of nested spinning syntax.
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div id="spinchimp" class="tab_content">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Account info</th>
                                <td>
                                    <?php
                                    if ($csyn_sp_options['email'] == '' || $csyn_sp_options['apikey'] == '') {
                                        echo 'Please enter your email and API key below or apply for your <a href="https://www.cyberseo.net/partners/spinchimp.php" target="_blank"><strong>ChimpRewriter</strong></a> account.';
                                    } else {
                                        $url = 'http://api.chimprewriter.com/QueryStats?simple=0&email=' . urlencode($csyn_sp_options['email']) . '&apikey=' . urlencode($csyn_sp_options['apikey']) . '&aid=' . urlencode($csyn_sp_options['aid']);
                                        $data = [];
                                        $data['account info'] = '';
                                        $result = trim(csyn_curl_post($url, $data, $info, 10));
                                        echo str_replace('|', '. ', str_replace(',', ': ', $result)) . '.';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Email address</th>
                                <td>
                                    <input type="text" name="sp_email" size="60" value="<?php echo $csyn_sp_options['email']; ?>">
                                    <p class="description">your <strong>ChimpSpinner</strong> email address.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">API key</th>
                                <td>
                                    <input <?php echo ((CSYN_HIDE_PASSWORDS) ? 'type="password"' : 'type="text"'); ?> name="sp_apikey" size="60" value="<?php echo $csyn_sp_options['apikey']; ?>">
                                    <p class="description">your <strong>ChimpSpinner</strong> API key.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Quality</th>
                                <td>
                                    <select name="sp_quality" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_sp_options['quality'] == "1") ? 'selected ' : '') . 'value="1">1</option>';
                                        echo '<option ' . (($csyn_sp_options['quality'] == "2") ? 'selected ' : '') . 'value="2">2</option>';
                                        echo '<option ' . (($csyn_sp_options['quality'] == "3") ? 'selected ' : '') . 'value="3">3</option>';
                                        echo '<option ' . (($csyn_sp_options['quality'] == "4") ? 'selected ' : '') . 'value="4">4</option>';
                                        echo '<option ' . (($csyn_sp_options['quality'] == "5") ? 'selected ' : '') . 'value="5">5</option>';
                                        ?>
                                    </select>
                                    <p class="description">spin quality: 5 - Best, 4 - Better, 3 - Good, 2 - Average, 1 - All.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">POS match</th>
                                <td>
                                    <select name="sp_posmatch" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_sp_options['posmatch'] == "0") ? 'selected ' : '') . 'value="0">0</option>';
                                        echo '<option ' . (($csyn_sp_options['posmatch'] == "1") ? 'selected ' : '') . 'value="1">1</option>';
                                        echo '<option ' . (($csyn_sp_options['posmatch'] == "2") ? 'selected ' : '') . 'value="2">2</option>';
                                        echo '<option ' . (($csyn_sp_options['posmatch'] == "3") ? 'selected ' : '') . 'value="3">3</option>';
                                        echo '<option ' . (($csyn_sp_options['posmatch'] == "4") ? 'selected ' : '') . 'value="4">4</option>';
                                        ?>
                                    </select>
                                    <p class="description">required Part of Speech (POS) match for a spin: 4 - FullSpin, 3 - Full, 2 - Loose, 1 - Extremely Loose, 0 - None. "FullSpin" removes some common POS replacements that tend to reduce quality of spin.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Protected terms</th>
                                <td>
                                    <input type="text" name="sp_protectedterms" size="60" value="<?php echo $csyn_sp_options['protectedterms']; ?>">
                                    <p class="description">comma separated list of words or phrases to protect from spin, i.e. "my main keyword,my second keyword".</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Rewrite</th>
                                <td>
                                    <input type="checkbox" name="sp_rewrite"
                                    <?php
                                    if ($csyn_sp_options['rewrite'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if enabled, results are returned as a rewritten article with no Spintax. Otherwise, an article with Spintax is returned. Note that with rewrite enabled, the original word will always be removed.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Phrase ignore quality</th>
                                <td>
                                    <input type="checkbox" name="sp_phraseignorequality"
                                    <?php
                                    if ($csyn_sp_options['phraseignorequality'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if enabled, quality is ignored when finding phrase replacements for phrases. This results in a huge amount of spin, but quality can vary.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Spin within spin</th>
                                <td>
                                    <input type="checkbox" name="sp_spinwithinspin"
                                    <?php
                                    if ($csyn_sp_options['spinwithinspin'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    if enabled and if there is existing spin syntax in the content you send up, the ChimpRewriter will spin any relevant content inside this syntax. If disabled, the API will skip over this content and only spin outside of existing syntax.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Spin within HTML</th>
                                <td>
                                    <input type="checkbox" name="sp_spinwithinhtml"
                                    <?php
                                    if ($csyn_sp_options['spinwithinhtml'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    spin inside HTML tags. This includes &lt;p&gt; tags, for example if you send up "&lt;p&gt;Here is a paragraph&lt;\p&gt;", nothing would be spun unless "Spin within HTML" is enabled.
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Apply instant unique</th>
                                <td>
                                    <input type="checkbox" name="sp_applyinstantunique"
                                    <?php
                                    if ($csyn_sp_options['applyinstantunique'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    runs a spin tidy pass over the result article. This fixes any common a/an type grammar mistakes and repeated words due to phrase spinning. Generally increases the quality of the article. <strong>Costs one extra query.</strong>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Tag protect</th>
                                <td>
                                    <input type="text" name="sp_tagprotect" size="60" value="<?php echo $csyn_sp_options['tagprotect']; ?>">
                                    <p class="description">protects anything between any syntax you define. Separate start and end syntax with a pipe "|" and separate multiple tags with a comma ",". For example, you could protect anything in square brackets by assigning "[|]". You could also protect anything between "begin" and "end" by assigning "[|],begin|end".</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Max spin depth</th>
                                <td>
                                    <input type="checkbox" name="sp_maxspindepth"
                                    <?php
                                    if ($csyn_sp_options['maxspindepth'] == '1') {
                                        echo "checked";
                                    }
                                    ?> />
                                    sets a maximum spin level depth in returned article. If enabled, no nested spin will appear in the spun result. This parameter only matters if "Rewrite" is disabled. Disable it for no limit on spin depth.
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div id="xspinner" class="tab_content">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Post URL</th>
                                <td>
                                    <input type="text" name="xs_post_url" size="60" value="<?php echo $csyn_xs_options['post_url']; ?>">
                                    <p class="description">The HTTP POST URL is up to which IP and Port does <a href="https://www.cyberseo.net/partners/x-spinner.php" target="_blank"><strong>X-Spinner</strong></a> listen at.
                                        The default listen IP and port of X-Spinner is 127.0.0.1 and 80 port, so the default post URL is <strong>http://127.0.0.1:80/</strong>. But X-Spinner user may change the listen IP and port,
                                        so you'd better let your users input the X-Spinner listen IP and port in your software and get the right post url.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Spin type</th>
                                <td>
                                    <select name="xs_spintype" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_xs_options['spintype'] == "0") ? 'selected ' : '') . 'value="0">Spin to new article</option>';
                                        echo '<option ' . (($csyn_xs_options['spintype'] == "1") ? 'selected ' : '') . 'value="1">Text with Spintax</option>';
                                        ?>
                                    </select>
                                    <p class="description">"Text with Spintax" can be useful for generation of unique feeds in <a href="https://www.cyberseo.net/morphing-rss-host-mode-content-spinner/" target="_blank">Morphing RSS</a> host mode.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Remove old</th>
                                <td>
                                    <select name="xs_removeold" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_xs_options['removeold'] == "0") ? 'selected ' : '') . 'value="0">No</option>';
                                        echo '<option ' . (($csyn_xs_options['removeold'] == "1") ? 'selected ' : '') . 'value="1">Yes</option>';
                                        ?>
                                    </select>
                                    <p class="description">Should the word be removed from the spin result.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Protect words</th>
                                <td>
                                    <input type="text" name="xs_protectw" size="60" value="<?php echo $csyn_xs_options['protectw']; ?>">
                                    <p class="description">If you want to protect some words, set it like "word1,word2,word3", then X-Spinner will not spin these words.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Spin way</th>
                                <td>
                                    <select name="xs_spinway" size="1">
                                        <?php
                                        echo '<option ' . (($csyn_xs_options['spinway'] == "0") ? 'selected ' : '') . 'value="0">Free spin</option>';
                                        echo '<option ' . (($csyn_xs_options['spinway'] == "1") ? 'selected ' : '') . 'value="1">Normal spin</option>';
                                        echo '<option ' . (($csyn_xs_options['spinway'] == "2") ? 'selected ' : '') . 'value="2">Super spin</option>';
                                        ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Thesaurus</th>
                                <td>
                                    <input type="text" name="xs_thesaurus" size="60" value="<?php echo $csyn_xs_options['thesaurus']; ?>">
                                    <p class="description"> Arabic, Belarusian, Bulgarian, Croatian, Danish, Dutch, English, Filipino, Finnish, French, German, Greek, Hebrew,
                                        Indonesian, Italian, Lithuanian, Norwegian, Polish, Portuguese, Romanian, Slovak, Slovenian, Spanish, Swedish, Turkish,
                                        Vietnamese and yourself thesaurus name in X-Spinner. This parameter only be valid in X-Spinner  Developer Version.</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                &nbsp;
                <div style="text-align:left;">
                    <input type="submit" name="submit_synonymizer_settings" class="button-primary" value="Update options" />&nbsp;&nbsp;<input type="button"  name="cancel" value="Cancel" class="button" onclick="javascript:history.go(-1)" />
                </div>
            </div>
            <?php wp_nonce_field('synonymizer_settings'); ?>
        </form>
    </div>
    <?php
}

function csyn_update_feeds() {
    global $csyn_syndicator;
    $feed_cnt = count($csyn_syndicator->feeds);
    if ($feed_cnt > 0) {
        $feed_ids = range(0, $feed_cnt - 1);
        $csyn_syndicator->show_report = false;
        $csyn_syndicator->syndicateFeeds($feed_ids, true);
    }
}

function csyn_fake_guid($guid) {
    global $wpdb;
    if (is_feed()) {
        $title = $wpdb->get_var("SELECT post_name FROM {$wpdb->prefix}posts WHERE guid = \"" . addslashes($guid) . "\"");
        return get_option('home') . "/" . $title;
    } else {
        return $guid;
    }
}

function csyn_rss2_item() {
    global $post;
    $custom_tags = explode(',', $_GET['custom_tags']);
    foreach ($custom_tags as $field) {
        $tag = trim($field);
        $value = get_post_meta($post->ID, $tag, true);
        if (($value != '')) {
            echo "<$tag><![CDATA[$value]]></$tag>";
        } elseif ($field == 'cm_value') {
            echo '<cm_value>%%MAGIC%%</cm_value>';
        }
    }
    echo PHP_EOL;
}

function csyn_deactivation() {
    wp_clear_scheduled_hook('update_by_wp_cron');
}

function csyn_get_cuctom_cron_interval_name() {
    return 'every ' . get_option(CSYN_PSEUDO_CRON_INTERVAL) . ' minutes';
}

function csyn_add_cuctom_cron_interval($schedules) {
    $name = csyn_get_cuctom_cron_interval_name();
    $schedules[$name] = array(
        'interval' => intval(get_option(CSYN_PSEUDO_CRON_INTERVAL)) * 60,
        'display' => __($name)
    );
    return $schedules;
}

function csyn_rel_canonical() {
    global $post;
    if (isset($post->ID)) {
        $link = get_post_meta($post->ID, 'cyberseo_post_link', true);
        if (is_singular()) {
            if (strlen($link)) {
                echo apply_filters('csyn_rel_canonical', '<link rel="canonical" href="' . $link . '"/>' . PHP_EOL);
            } else {
                echo apply_filters('csyn_rel_canonical', '<link rel="canonical" href="' . get_permalink($post->ID) . '"/>' . PHP_EOL);
            }
        }
    }
}

function csyn_permalink($permalink) {
    global $post;
    $link = get_post_meta($post->ID, 'cyberseo_post_link', true);
    if (strlen($link)) {
        if (filter_var($link, FILTER_VALIDATE_URL)) {
            $permalink = $link;
        } elseif (filter_var($post->guid, FILTER_VALIDATE_URL)) {
            $permalink = $post->guid;
        }
    }
    return $permalink;
}

function csyn_plugins_action_link($links) {
    $links[] = '<a href="' . esc_url(get_admin_url(null, 'admin.php?page=cybersyn')) . '">Syndicator</a>';
    $links[] = '<a href="?csyn_update">Update</a>';
    return $links;
}

function csyn_add_admin_menu_item($admin_bar) {
    $args = array(
        'id' => 'new-cybsrseo-feed-admin-menu-item',
        'title' => 'CyberSEO Feed',
        'href' => esc_url(get_admin_url(null, 'admin.php?page=cybersyn')),
        'parent' => 'new-content',
    );
    $admin_bar->add_menu($args);
}

class CyberSyn_Amazon_Product_Parser {

    public $do_duplicate_check;
    private $link;
    private $base_domain;
    private $tag;

    public function __construct($link, $tag) {
        preg_match('/[\?&](tag=[\w-]+&?)/i', $link, $matches);
        if (isset($matches[1])) {
            $link = str_replace($matches[1], '', $link) . '&' . $tag;
        }
        preg_match('/[\?&](page=[\d]+&?)/i', $link, $matches);
        if (isset($matches[1])) {
            $link = str_replace($matches[1], '', $link) . '&' . $tag;
        }
        $this->link = $link;
        $this->base_domain = 'https://' . parse_url($link, PHP_URL_HOST);
        $this->tag = $tag;
        $this->do_duplicate_check = false;
    }

    public function amazon_parse_product_page($link) {
        global $wpdb;
        preg_match('/\/dp\/(\w+)\//i', $link, $matches);
        if (isset($matches[1])) {
            $asin = $matches[1];
            $buy_link = $this->base_domain . '/dp/' . $asin . '/?tag=' . $this->tag;
            if ($this->do_duplicate_check) {
                if ($wpdb->get_var("SELECT ID FROM {$wpdb->prefix}posts WHERE guid = '" . htmlentities($buy_link) . "' AND post_status NOT IN ('trash') AND post_type NOT IN ('attachment', 'revision', 'nav_menu_item')")) {
                    return false;
                }
            }
            $content = csyn_file_get_contents($link);
            preg_match('/<div id="productDescription".*?>(.*?)<\/div>/s', $content, $matches);
            if (isset($matches[1])) {
                $cont = $matches[1];
                $desc = trim(strip_tags($cont));
                preg_match('/<div id="feature-bullets".*?(<ul.*?<\/ul>)/s', $content, $matches);
                if (isset($matches[1])) {
                    $cont .= $matches[1];
                    if (preg_match('/<ul.*?>(.*?)<li>/is', $cont, $matches)) {
                        $cont = str_replace($matches[1], '', $cont);
                    }
                }
                preg_match('/<div id="detailBulletsWrapper_feature_div".*?>(.*?)<\/div>/s', $content, $matches);
                if (isset($matches[1])) {
                    $cont .= $matches[1];
                }
                preg_match('/<div id="renewedProgramDescriptionAtf".*?>(.*?)<\/div>/s', $content, $matches);
                if (isset($matches[1])) {
                    $cont .= $matches[1];
                }
                $cont = preg_replace('/<h\d>/i', '<h3>', $cont);
                $cont = preg_replace('/<\/h\d>/i', '</h3>', $cont);
                $cont = strip_tags($cont, '<p><br><ul><li><h3><i><u><b>');
                $cont = str_replace('  ', ' ', str_replace("\n", ' ', trim($cont)));
                if (preg_match('/ href="(.*?)"/s', $desc, $matches) && stripos('amazon.', $matches[1]) === false) {
                    $desc = str_replace($matches[1], $buy_link, $desc);
                }
                preg_match('/Brand<\/span>.*?<span.*?>(.*?)<\/span>/s', $content, $matches);
                if (count($matches) == 2) {
                    $brand = $matches[1];
                } else {
                    $brand = '';
                }
                preg_match('/<span class=".*?-price .*?">(\W+?[0-9\.]+\S+?)<\/span>/s', $content, $matches);
                if (isset($matches[1])) {
                    $price = $matches[1];
                } else {
                    $price = '';
                }
                preg_match('/jQuery.parseJSON\(\'(.*?)\'\)/s', $content, $matches);
                $obj = json_decode(stripslashes($matches[1]));
                if (is_object($obj) && strlen($price) && isset($obj->title)) {
                    $images = [];
                    foreach ($obj->colorImages as $color) {
                        foreach ($color as $img) {
                            if (isset($img->hiRes)) {
                                $images[$img->variant] = preg_replace('._AC_\S+_.', '_AC_SL1500_', $img->hiRes);
                            } elseif (isset($img->large)) {
                                $images[$img->variant] = $img->large;
                            }
                        }
                    }
                    if (!count($images)) {
                        preg_match('/"hiRes":"(.*?)"/s', $content, $matches);
                        if (isset($matches[1])) {
                            $images[] = $matches[1];
                        }
                    }
                    $images = array_unique($images);
                    $result = [];
                    $result['asin'] = $asin;
                    $result['buy_link'] = $buy_link;
                    $result['title'] = $obj->title;
                    $result['brand'] = $brand;
                    $result['price'] = $price;
                    $result['content'] = $cont;
                    $result['description'] = $desc;
                    $result['images'] = $images;
                    return $result;
                }
            }
        }
        return false;
    }

    public function amazon_parse_search_page($max_items) {
        $page = 1;
        $items = 0;
        $feed = '<?xml version="1.0" encoding="UTF-8" ?>' . PHP_EOL . '<channel>
        <title>Amazon products</title>
        <description>Generated for ' . $this->tag . '</description>
        <link>' . htmlentities($this->link, ENT_QUOTES) . '/</link>';
        do {
            $content = csyn_file_get_contents($this->link . '&page=' . $page++);
            preg_match_all('/<a class="a-link-normal s-no-outline".*?href="(.*?)">.*?alt="(.*?)"/s', $content, $matches);
            if (!($cnt = count($matches[1]))) {
                break;
            }
            for ($i = 0; $i < $cnt; $i++) {
                if (strpos($matches[1][$i], '/gp/slredirect/') === false) {
                    $product = $this->amazon_parse_product_page($this->base_domain . urldecode(html_entity_decode($matches[1][$i])));
                    if (is_array($product)) {
                        $post_content = '';
                        if (count($product['images'])) {
                            $post_content .= '<div id="cseo-product-gallery"><ul id="cseo-product-galley-fullimage">';
                            $imgno = 0;
                            foreach ($product['images'] as $image_alt => $image_url) {
                                $post_content .= '<li id="cseo-product-thumb' . $imgno . '" /><img src="' . $image_url . '" alt="' . $image_alt . '">';
                                $imgno++;
                            }
                            $post_content .= '</ul><ul id="cseo-product-galley-thumbimage">';
                            $imgno = 0;
                            foreach ($product['images'] as $image_alt => $image_url) {
                                $post_content .= '<li><a href="#cseo-product-thumb' . $imgno . '"><img src="' . $image_url . '" alt="' . $image_alt . '"></a></li>';
                                $imgno++;
                            }
                            $post_content .= '</ul><br style="clear:both;"/></div>';
                        }
                        $post_content .= $product['content'];
                        $post_content .= '<div style="padding: 20pt 0 40pt 0; text-align:center;">';
                        $post_content .= '<span style="font-size:32pt;">Price: <span style="color:#b12704;">' . $product['price'] . '</span></span><br />
                          <i><small>(as of ' . date('F j, Y, g:i', time()) . ' - <span style="cursor:pointer;text-decoration:underline;" title="Product prices and availability are accurate as of the date/time indicated and are subject to change. Any price and availability information displayed on [relevant Amazon Site(s), as applicable] at the time of purchase will apply to the purchase of this product.">Details</span>)</small></i>
                          </div><div style="text-align:center;">
                          <a class="cseo-product-galley-button" href="' . htmlspecialchars($product['buy_link']) . '">BUY NOW</a>
                          </div>';
                        $feed .= '
                            <item>
                                <guid isPermaLink="false">' . $product['buy_link'] . '</guid>
                                <link>' . htmlspecialchars($product['buy_link']) . '</link>
                                <title><![CDATA[' . $product['title'] . '...]]></title>
                                <description><![CDATA[' . $product['description'] . ']]></description>
                                <content><![CDATA[' . $post_content . ']]></content>
                                <asin>' . $product['asin'] . '</asin>
                                <brand><![CDATA[' . $product['brand'] . ']]></brand>
                                <price><![CDATA[' . $product['price'] . ']]></price>';
                        if (count($product['images'])) {
                            $feed .= '
                                <thumb>' . htmlspecialchars($product['images'][array_rand($product['images'])]) . '</thumb>
                                <media:group>';
                            foreach ($product['images'] as $image_alt => $image_url) {
                                $feed .= '
                                    <media:content medium="image" url="' . htmlspecialchars($image_url) . '" type="image/jpeg" alt="' . htmlentities($image_alt, ENT_QUOTES) . '" />';
                            }
                            $feed .= '
                                </media:group>';
                        }
                        $feed .= '
                            </item>';
                        if (++$items > $max_items) {
                            break;
                        }
                    }
                }
            }
        } while (preg_match('/class=".*?s-pagination-next.*?"/', $content) && $items <= $max_items);
        $feed .= PHP_EOL . '</channel>';
        return str_replace('  ', ' ', $feed);
    }

}

class CyberSyn_Syndicator {

    var $post = [];
    var $insideitem;
    var $new_tag = false;
    var $element_tag;
    var $tag;
    var $count;
    var $failure;
    var $xml_tags;
    var $posts_found;
    var $max;
    var $current_feed = [];
    var $current_feed_url = '';
    var $feeds = [];
    var $feeds_updated = [];
    var $update_period;
    var $feed_title;
    var $blog_charset;
    var $feed_charset;
    var $feed_charset_convert;
    var $preview;
    var $global_options = [];
    var $edit_existing;
    var $current_category;
    var $current_custom_field;
    var $current_custom_field_attr = [];
    var $generator;
    var $xml_parse_error;
    var $show_report = false;
    var $document_type;

    function fixURL($url) {
        if (!is_object($url)) {
            $url = trim($url);
            if (!strlen($url)) {
                $url = '#' . str_replace('.', '', str_replace(' ', '', microtime()));
            } if (!preg_match('!^https?://.+!i', $url) && !preg_match(CSYN_DUMMY_FEED_PATTERN, $url)) {
                $url = "http://" . $url;
            }
        }
        return $url;
    }

    function resetPost() {
        global $csyn_images_to_save, $csyn_images_to_attach, $csyn_urls_to_check;
        $this->post['post_title'] = '';
        $this->post['post_name'] = '';
        $this->post['post_author'] = '';
        $this->post['post_content'] = '';
        $this->post['post_excerpt'] = '';
        $this->post['guid'] = '';
        $this->post['post_date'] = time();
        $this->post['post_date_gmt'] = time();
        $this->post['categories'] = [];
        $this->post['tags_input'] = [];
        $this->post['comments'] = [];
        $this->post['media_content'] = [];
        $this->post['media_thumbnail'] = [];
        $this->post['media_description'] = '';
        $this->post['enclosure_url'] = '';
        $this->post['enclosure_type'] = '';
        $this->post['link'] = '';
        $this->post['options'] = [];
        $this->xml_tags = [];
        $csyn_images_to_save = [];
        $csyn_images_to_attach = [];
        $csyn_urls_to_check = [];
    }

    function init_feed_options($options) {
        $default_options = array(
            'interval' => 1440,
            'max_items' => 1,
            'post_status' => 'publish',
            'comment_status' => 'open',
            'ping_status' => 'closed',
            'post_type' => 'post',
            'post_format' => 'default',
            'post_author' => 1,
            'base_date' => 'post',
            'duplicate_check_method' => 'guid_and_title',
            'undefined_category' => 'use_default',
            'user_agent' => '',
            'spinner' => CSYN_DISABLE_SPINNER,
            'create_tags' => '',
            'extract_full_articles' => '',
            'article_forge' => '',
            'article_forge_api_key' => '',
            'article_forge_keyword' => '',
            'article_forge_sub_keywords' => '',
            'article_forge_tags_as_subkeywords' => '',
            'article_forge_spintax_view' => '',
            'article_forge_position' => 'below',
            'article_forge_length' => 'short',
            'article_forge_quality' => '4',
            'article_forge_turing_spinner' => '0',
            'article_forge_rewrite_sentence' => '0',
            'article_forge_rearrange_sentence' => '0',
            'article_forge_shuffle_paragraphs' => '0',
            'article_forge_image' => '0',
            'article_forge_video' => '0',
            'article_forge_title' => 'original',
            'wpml_language' => '',
            'post_tags' => '',
            'post_category' => [],
            'date_min' => 0,
            'date_max' => 0,
            'xml_section_tags' => '',
            'preserve_titles' => '',
            'insert_media_attachments' => '',
            'set_thumbnail' => 'no_thumb',
            'sanitize' => '',
            'convert_encoding' => '',
            'require_thumbnail' => 'on',
            'use_fifu' => '',
            'store_images' => '',
            'store_videos' => '',
            'push_up' => '',
            'shorten_excerpts' => '',
            'embed_videos' => '',
            'include_post_footers' => '',
            'utf8_encoding' => '',
            'post_footer' => '',
            'translator' => 'none',
            'yandex_translation_dir' => '',
            'yandex_api_key' => '',
            'google_translation_source' => '',
            'google_translation_target' => '',
            'google_api_key' => '',
        );
        foreach ($default_options as $key => $value) {
            if (!isset($options[$key])) {
                $options[$key] = $default_options[$key];
            }
        }
        return $options;
    }

    function __construct() {
        $this->blog_charset = strtoupper(get_option('blog_charset'));
        $this->global_options = $this->init_feed_options(get_option(CSYN_FEED_OPTIONS));
        update_option(CSYN_FEED_OPTIONS, $this->global_options);
        $this->feeds_updated = get_option(CSYN_FEEDS_UPDATED);
        $this->feeds = get_option(CSYN_SYNDICATED_FEEDS);
        if (count($this->feeds)) {
            for ($i = 0; $i < count($this->feeds); $i++) {
                $this->feeds[$i]['options'] = $this->init_feed_options($this->feeds[$i]['options']);
            }
            update_option(CSYN_SYNDICATED_FEEDS, $this->feeds);
        }
    }

    function parse_w3cdtf($w3cdate) {
        if (preg_match("/^\s*(\d{4})(-(\d{2})(-(\d{2})(T(\d{2}):(\d{2})(:(\d{2})(\.\d+)?)?(?:([-+])(\d{2}):?(\d{2})|(Z))?)?)?)?\s*\$/", $w3cdate, $match)) {
            list($year, $month, $day, $hours, $minutes, $seconds) = array($match[1], $match[3], $match[5], $match[7], $match[8], $match[10]);
            if (is_null($month)) {
                $month = (int) gmdate('m');
            }
            if (is_null($day)) {
                $day = (int) gmdate('d');
            }
            if (is_null($hours)) {
                $hours = (int) gmdate('H');
                $seconds = $minutes = 0;
            }
            $epoch = gmmktime($hours, $minutes, $seconds, $month, $day, $year);
            if ($match[14] != 'Z') {
                list($tz_mod, $tz_hour, $tz_min) = array($match[12], $match[13], $match[14]);
                $tz_hour = (int) $tz_hour;
                $tz_min = (int) $tz_min;
                $offset_secs = (($tz_hour * 60) + $tz_min) * 60;
                if ($tz_mod == "+") {
                    $offset_secs *= - 1;
                }
                $offset = $offset_secs;
            }
            $epoch = $epoch + $offset;
            return $epoch;
        } else {
            return -1;
        }
    }

    function parseFeed($feed_url) {
        global $csyn_xml_key;
        $this->tag = '';
        $this->insideitem = 0;
        $this->element_tag = '';
        $this->feed_title = '';
        $this->generator = '';
        $this->current_feed_url = $feed_url;
        $this->feed_charset_convert = '';
        $this->posts_found = 0;
        $this->failure = false;
        $this->document_type = 'XML';
        $csyn_xml_key = '';
        if ($this->preview) {
            $options = $this->global_options;
        } else {
            $options = $this->current_feed['options'];
        }
        if (is_string($feed_url)) {
            if (!strlen(trim($feed_url))) {
                $feed_url = $this->fixURL($feed_url);
            }
            if (preg_match('/https?:\/\/(www\.)?amazon\.\S+\//', $feed_url . '/')) {
                $csyn_amazon = new CyberSyn_Amazon_Product_Parser($feed_url, get_option(CSYN_AMAZON_TAG));
                if ($this->preview) {
                    $csyn_amazon->do_duplicate_check = false;
                    $content = $csyn_amazon->amazon_parse_search_page(1);
                } else {
                    $csyn_amazon->do_duplicate_check = true;
                    $content = $csyn_amazon->amazon_parse_search_page($this->max);
                }
                $this->document_type = 'Amazon';
            } else {
                $content = csyn_file_get_contents($feed_url, false);
                $this->document_type = 'RSS';
            }
            if (strpos($content, 'PK') === 0) {
                $content = csyn_unzip($content);
            } elseif (strpos($content, "\x1f\x8b\x08") === 0 || (strpos($content, "\x78\x01") === 0 || strpos($content, "\x78\x9c") === 0 || strpos($content, "\x78\xda") === 0)) {
                $content = @gzuncompress($content);
            } elseif (strpos($content, "\x45\x5a\x68") === 0) {
                $content = @bzdecompress($content);
            }
            preg_match('/^(.*?)<\?xml/is', $content, $matches);
            if (isset($matches[1])) {
                $content = str_replace($matches[1], '', $content);
            }
            $this->current_feed['options']['xml_section_tags'] = $this->global_options['xml_section_tags'] = $options['xml_section_tags'] = 'ENTRY,ITEM';
            $content = str_replace('&rsquo;', '\'', $content);
            $content = str_replace('a?', 'a', $content);
        }
        if (preg_match('/body.*?(\{direction:rtl.*?\})/is', $content, $matches)) {
            $content = str_replace($matches[1], '', $content);
        }
        if (preg_match('/body.*?(\{direction:ltr.*?\})/is', $content, $matches)) {
            $content = str_replace($matches[1], '', $content);
        }
        if (!$content) {
            if ($this->preview) {
                echo '<div id="message" class="error"><p>Unable to acquire <a href="' . $feed_url . '" target="_blank">' . htmlentities(urldecode($feed_url)) . '</a>.</p></div>';
            }
            return;
        }
        $rss_lines = @explode(PHP_EOL, trim($content));
        if (is_array($rss_lines) && count($rss_lines) > 0) {
            preg_match("/encoding[. ]?=[. ]?[\"'](.*?)[\"']/i", $rss_lines[0], $matches);
            if (isset($matches[1]) && $matches[1] != '') {
                $this->feed_charset = trim($matches[1]);
            } else {
                $this->feed_charset = "not defined";
            }
            $xml_parser = xml_parser_create();
            xml_parser_set_option($xml_parser, XML_OPTION_TARGET_ENCODING, $this->blog_charset);
            xml_set_object($xml_parser, $this);
            xml_set_element_handler($xml_parser, "startElement", "endElement");
            xml_set_character_data_handler($xml_parser, "charData");
            $do_mb_convert_encoding = ($options['convert_encoding'] == 'on' && $this->feed_charset != "not defined" && $this->blog_charset != strtoupper($this->feed_charset));
            $do_uft8_encoding = ($options['utf8_encoding'] == 'on' && $this->blog_charset == "UTF-8");
            $is_flvembed = false;
            $this->xml_parse_error = 0;
            foreach ($rss_lines as $line) {
                if ($this->count >= $this->max || $this->failure) {
                    break;
                }
                if ($do_uft8_encoding) {
                    $line = utf8_encode($line);
                }
                if ($do_mb_convert_encoding && function_exists("mb_convert_encoding")) {
                    $line = mb_convert_encoding($line, $this->blog_charset, $this->feed_charset);
                }
                if (mb_strtolower(trim($line)) == '<flv_embed>') {
                    $is_flvembed = true;
                } elseif ($is_flvembed) {
                    if (mb_strtolower(trim($line)) == '</flv_embed>') {
                        $is_flvembed = false;
                    } elseif (stripos(trim($line), '<![CDATA[') === false && stripos(trim($line), ']]>') === false) {
                        $line = '<![CDATA[' . trim($line) . ']]>';
                    }
                }
                xml_parse($xml_parser, $line . PHP_EOL);
                $this->xml_parse_error = xml_get_error_code($xml_parser);
                if ($this->xml_parse_error) {
                    xml_parser_free($xml_parser);
                    return false;
                }
            }
            xml_parser_free($xml_parser);
            return $this->count;
        } else {
            return false;
        }
    }

    function syndicateFeeds($feed_ids, $check_time) {
        $this->preview = false;
        $feeds_cnt = count($this->feeds);
        if (is_array($feed_ids) && count($feed_ids) > 0) {
            if ($this->show_report) {
                @ob_end_flush();
                @ob_implicit_flush();
                echo '<div id="message" class="notice updated"><p>';
                flush();
            }
            for ($i = 0; $i < $feeds_cnt; $i++) {
                if (in_array($i, $feed_ids)) {
                    if (!$check_time || $this->getUpdateTime($i) == "asap") {
                        $this->feeds_updated[$i] = time();
                        update_option(CSYN_FEEDS_UPDATED, $this->feeds_updated);
                        $this->current_feed = $this->feeds[$i];
                        $this->resetPost();
                        $this->max = (int) $this->current_feed['options']['max_items'];
                        if ($this->show_report) {
                            if (!is_object($this->current_feed['url'])) {
                                echo 'Syndicating <a href="' . htmlspecialchars($this->current_feed['url']) . '" target="_blank"><strong>' . $this->current_feed['title'] . '</strong></a>...';
                            } else {
                                echo 'Syndicating <strong>' . $this->current_feed['url']->get_id() . '</strong>...';
                            }
                            flush();
                        }
                        if ($this->current_feed['options']['undefined_category'] == 'use_global') {
                            $this->current_feed['options']['undefined_category'] = $this->global_options['undefined_category'];
                        }
                        $this->count = 0;
                        $result = $this->parseFeed($this->current_feed['url']);
                        if ($this->show_report) {
                            if ($this->count == 1) {
                                echo $this->count . ' ' . $this->current_feed['options']['post_type'] . ' was added';
                            } else {
                                echo $this->count . ' ' . $this->current_feed['options']['post_type'] . 's were added';
                            }
                            if ($result === false) {
                                echo '[!]';
                            }
                            echo '<br />';
                            flush();
                        }
                    }
                }
            }
            if ($this->show_report) {
                echo '</p></div>';
            }
        }
    }

    function displayPost() {
        if (!mb_strlen($this->feed_title)) {
            $host = parse_url($this->current_feed_url, PHP_URL_HOST);
            if (strlen($host)) {
                $this->feed_title = ucfirst(str_ireplace('www.', '', $host));
            } else {
                $this->feed_title = 'no name';
            }
        }
        if (!mb_strlen(trim($this->post['post_excerpt'])) && mb_strlen(trim($this->post['media_description']))) {
            $this->post['post_excerpt'] = $this->post['media_description'];
        }
        if (!mb_strlen(trim($this->post['post_content']))) {
            $this->post['post_content'] = $this->post['post_excerpt'];
        }
        $attachment = '';
        $video_extensions = wp_get_video_extensions();
        if ($this->post['enclosure_url'] != '') {
            $ext = mb_strtolower(pathinfo($this->post['enclosure_url'], PATHINFO_EXTENSION));
            if (in_array($ext, $video_extensions)) {
                $video = array('src' => $this->post['enclosure_url']);
                if (isset($this->post['media_thumbnail'][0])) {
                    $video['poster'] = $this->post['media_thumbnail'][0];
                }
                $attachment .= wp_video_shortcode($video);
            } else {
                if ($this->post['enclosure_type'] == 'audio/mpeg') {
                    $audio = array('src' => $this->post['enclosure_url']);
                    $attachment .= wp_audio_shortcode($audio);
                } elseif (stripos($this->post['enclosure_type'], 'image/') !== false || $this->post['enclosure_type'] == '') {
                    $attachment .= '<img style="max-width:100%" src="' . $this->post['enclosure_url'] . '">';
                }
            }
        } else {
            if (count($this->post['media_content'])) {
                $attachment .= '<div class="media_block">';
                for ($i = 0; $i < sizeof($this->post['media_content']); $i++) {
                    $ext = mb_strtolower(pathinfo($this->post['media_content'][$i], PATHINFO_EXTENSION));
                    if (in_array($ext, $video_extensions)) {
                        $video = array('src' => $this->post['media_content'][$i]);
                        if (isset($this->post['media_thumbnail'][$i])) {
                            $video['poster'] = $this->post['media_thumbnail'][$i];
                        }
                        $attachment .= wp_video_shortcode($video);
                    } elseif (isset($this->post['media_thumbnail'][$i])) {
                        $attachment .= '<a href="' . $this->post['media_content'][$i] . '"><img style="max-width:100%" src="' . $this->post['media_thumbnail'][$i] . '" class="media_thumbnail"></a>';
                    } else {
                        $attachment .= '<img style="max-width:100%" src="' . $this->post['media_content'][$i] . '">';
                    }
                }
                $attachment .= '</div>';
            }
            if (count($this->post['media_thumbnail'])) {
                $attachment .= '<div class="media_block">';
                for ($i = 0; $i < sizeof($this->post['media_thumbnail']); $i++) {
                    $attachment .= '<img style="max-width:100%" src="' . $this->post['media_thumbnail'][$i] . '" class="media_thumbnail">';
                }
                $attachment .= '</div>';
            }
        }
        ?>
        <strong>Preview mode</strong>
        <select id="preview_mode_switch" onchange="changePreviewMode();">
            <?php
            $anything_to_display = false;
            $post_content = csyn_fix_white_spaces(trim($this->post['post_content']));
            if (strlen($post_content)) {
                echo '<option value="post_view">Post content</option>';
                $anything_to_display = true;
            }
            if (strlen($attachment)) {
                echo '<option value="attachment_view">Attachment</option>';
                $anything_to_display = true;
            }
            ?>
        </select>
        <?php
        echo '<div id="post_view" style="display:none; overflow:auto; max-height:250pt; border:1px #ccc solid; background-color:white; padding:12px; margin:8px 0 8px; 0;">';
        if (strlen($post_content)) {
            echo '<p><strong>Title:</strong> ' . csyn_fix_white_spaces(trim($this->post['post_title'])) . '</p>';
            echo '<p><strong>Date:</strong> ' . gmdate('Y-m-d H:i:s', (int) $this->post['post_date']) . '</p>';
            echo '<p><strong>Content:</strong></p>';
            echo $post_content;
        }
        echo '</div>';
        echo '<div id="attachment_view" style="display:none; overflow:auto; max-height:350pt; border:1px #ccc solid; background-color:white; padding:12px; margin:8px 0 8px; 0;">';
        if (strlen($attachment)) {
            echo $attachment . '<p>Adjust the <a href="#media-attachments">Media Attachments</a> settings to handle attachments.</p>';
        }
        echo '</div>';
        if ($anything_to_display) {
            echo '<script type="text/javascript">changePreviewMode();</script>';
        }
    }

    function feedPreview($feed_url, $edit_existing = false) {
        echo "<br />";
        $this->edit_existing = $edit_existing;
        $no_feed_dupes = get_option(CSYN_DISABLE_DUPLICATION_CONTROL) != "on";
        if (!$this->edit_existing && !is_object($feed_url)) {
            for ($i = 0; $i < count($this->feeds); $i++) {
                if ($no_feed_dupes && isset($this->feeds[$i]['url']) && $this->feeds[$i]['url'] == $feed_url) {
                    echo '<div id="message" class="error"><p><strong>This feed is already in use.</strong></p></div>';
                    return false;
                }
            }
        }
        $this->max = 1;
        $this->preview = true;
        ?>
        <?php
        $this->resetPost();
        $this->count = 0;
        $result = $this->parseFeed($feed_url);
        if (!$result) {
            if (!is_object($feed_url)) {
                if ($this->xml_parse_error) {
                    echo '<div id="message" class="notice is-dismissible notice-error">';
                    echo '<p><strong>CyberSEO parser error:</strong> ' . $this->xml_parse_error . ' (' . xml_error_string($this->xml_parse_error) . '). Perhaps the feed is unreachable, broken or empty. ';
                    echo '</p></div>';
                }
            } else {
                echo '<div id="message" class="notice is-dismissible notice-error"><p><strong><strong>CyberSEO parse error:</strong> Unknown.</p></div>';
            }
        }
        return ($result);
    }

    function startElement($parser, $name, $attribs) {
        $this->tag = $name;
        $this->current_custom_field_attr[$name] = $attribs;
        if ($this->preview) {
            $xml_section_tags = explode(",", trim($this->global_options['xml_section_tags']));
        } else {
            $xml_section_tags = explode(",", trim($this->current_feed['options']['xml_section_tags']));
        }
        if (in_array($name, $xml_section_tags)) {
            $this->insideitem++;
            $this->element_tag = $name;
            $this->resetPost();
        } elseif (($this->insideitem <= 0) && $name == "TITLE" && mb_strlen(trim($this->feed_title))) {
            $this->tag = '';
        }
        if ($this->insideitem >= 0) {
            if (isset($attribs['URL']) && $name == "MEDIA:CONTENT") {
                $this->post['media_content'][] = $attribs['URL'];
            }
            if (isset($attribs['URL']) && $name == "MEDIA:THUMBNAIL") {
                $this->post['media_thumbnail'][] = $attribs['URL'];
            }
            if ($name == "ENCLOSURE" /* && strpos ( strtolower ( $attribs["TYPE"] ), "image" ) !== false */) {
                $this->post['enclosure_url'] = $attribs['URL'];
                if (isset($attribs['TYPE'])) {
                    $this->post['enclosure_type'] = $attribs['TYPE'];
                }
            }
            if (($this->insideitem >= 0) && $name == "LINK" && isset($attribs['HREF']) && isset($attribs["REL"])) {
                if (stripos($attribs["REL"], "enclosure") !== false) {
                    $this->post['enclosure_url'] = $attribs['HREF'];
                } elseif (stripos($attribs["REL"], "alternate") !== false && $this->post['link'] == '') {
                    $this->post['link'] = $attribs['HREF'];
                }
            } elseif (($this->insideitem >= 0) && $name == "LINK" && $this->post['link'] == '' && isset($attribs['HREF'])) {
                $this->post['link'] = $attribs['HREF'];
            }
        }
    }

    function endElement($parser, $name) {
        $this->new_tag = true;
        if ($name == "CATEGORY") {
            $category = trim(csyn_fix_white_spaces($this->current_category));
            if (mb_strlen($category) > 0) {
                $this->post['categories'][] = $category;
            }
            $this->current_category = '';
        }
        if (($name == $this->element_tag)) {
            $this->insideitem--;
            if ($this->insideitem <= 0) {
                $this->posts_found++;
                if (($this->count < $this->max)) {
                    if ($this->preview) {
                        $this->displayPost();
                        $this->count++;
                    } else {
                        $this->insertPost();
                        if ($this->show_report) {
                            echo(str_repeat(' ', 1024));
                            flush();
                        }
                    }
                }
            }
        } elseif ($this->count >= $this->max) {
            $this->insideitem = 0;
        }
    }

    function charData($parser, $data) {
        if ($this->insideitem >= 0) {
            if ($this->preview) {
                $xml_section_tags = explode(",", trim(strtoupper($this->global_options['xml_section_tags'])));
            } else {
                $xml_section_tags = explode(",", trim(strtoupper($this->current_feed['options']['xml_section_tags'])));
            }
            if (in_array($data, array('&', '<', chr(9), chr(10), chr(11), chr(13)))) {
                $this->new_tag = false;
            }
            if (($this->tag) && !in_array($this->tag, $xml_section_tags)) {
                $tag = strtolower($this->tag);
                if (!isset($this->xml_tags[$tag]['val'])) {
                    $this->xml_tags[$tag]['val'] = $data;
                } else {
                    if ($this->new_tag && mb_strlen(trim($data))) {
                        $this->xml_tags[$tag]['val'] .= ', ' . $data;
                        $this->new_tag = false;
                    } else {
                        $this->xml_tags[$tag]['val'] .= $data;
                    }
                }
            }
            switch ($this->tag) {
                case "TITLE":
                    $this->post['post_title'] .= $data;
                    break;
                case "DESCRIPTION":
                    $this->post['post_excerpt'] .= $data;
                    break;
                case "MEDIA:DESCRIPTION":
                    $this->post['media_description'] .= $data;
                    break;
                case "SUMMARY":
                    $this->post['post_excerpt'] .= $data;
                    break;
                case "LINK":
                    if (trim($data) != '') {
                        $this->post['link'] .= trim($data);
                    }
                    break;
                case "CONTENT:ENCODED":
                    $this->post['post_content'] .= $data;
                    break;
                case "CONTENT":
                    $this->post['post_content'] .= $data;
                    break;
                case "TURBO:CONTENT":
                    $this->post['post_content'] .= $data;
                    break;
                case "YANDEX:FULL-TEXT":
                    if (!strlen(trim($this->post['post_content']))) {
                        $this->post['post_content'] .= $data;
                    }
                    break;
                case "CATEGORY":
                    $this->current_category .= trim($data);
                    break;
                case "TAGS":
                    $tags = explode(",", trim(csyn_fix_white_spaces($data)));
                    foreach ($tags as $tag) {
                        if (mb_strlen(trim($tag)) > 0) {
                            $this->post['categories'][] = trim($tag);
                        }
                    }
                    break;
                case "POST_TAG":
                    $this->post['tags_input'][] = trim($data);
                    break;
                case "MEDIA:KEYWORDS":
                    $this->post['tags_input'] = array_merge($this->post['tags_input'], explode(',', trim($data)));
                    break;
                case "GUID":
                    $this->post['guid'] .= trim($data);
                    break;
                case "ID":
                    $this->post['guid'] .= trim($data);
                    break;
                case "ATOM:ID":
                    $this->post['guid'] .= trim($data);
                    break;
                case "DC:IDENTIFIER":
                    $this->post['guid'] .= trim($data);
                    break;
                case "DC:DATE":
                    $this->post['post_date'] = $this->parse_w3cdtf($data);
                    if ($this->post['post_date']) {
                        $this->tag = '';
                    }
                    break;
                case "DCTERMS:ISSUED":
                    $this->post['post_date'] = $this->parse_w3cdtf($data);
                    if ($this->post['post_date']) {
                        $this->tag = '';
                    }
                    break;
                case "UPDATED":
                    $this->post['post_date'] = $this->parse_w3cdtf($data);
                    if ($this->post['post_date']) {
                        $this->tag = '';
                    }
                    break;
                case "PUBLISHED":
                    $this->post['post_date'] = $this->parse_w3cdtf($data);
                    if ($this->post['post_date']) {
                        $this->tag = '';
                    }
                    break;
                case "ISSUED":
                    $this->post['post_date'] = $this->parse_w3cdtf($data);
                    if ($this->post['post_date']) {
                        $this->tag = '';
                    }
                    break;
                case "PUBDATE":
                    $this->post['post_date'] = strtotime($data);
                    if ($this->post['post_date']) {
                        $this->tag = '';
                    }
                    break;
            }
        } elseif ($this->tag == "TITLE") {
            $this->feed_title .= csyn_fix_white_spaces($data);
        } elseif ($this->tag == "GENERATOR") {
            $this->generator .= trim($data);
        }
    }

    function deleteFeeds($feed_ids, $delete_posts = false, $delele_feeds = false) {
        global $wpdb;
        $feeds_cnt = count($feed_ids);
        if ($feeds_cnt > 0) {
            @ob_end_flush();
            @ob_implicit_flush();
            echo "<div id=\"message\" class=\"updated fade\"><p>";
            echo "Please wait...";
            flush();
            $posts_deleted = 0;
            if ($delete_posts) {
                $to_delete = "(";
                $cnt = count($feed_ids);
                for ($i = 0; $i < $cnt; $i++) {
                    if (!is_object($this->feeds[$feed_ids[$i]]['url'])) {
                        $to_delete .= "'" . $this->feeds[$feed_ids[$i]]['url'] . "', ";
                    } else {
                        $to_delete .= "'" . $this->feeds[$feed_ids[$i]]['url']->get_id() . "', ";
                    }
                }
                $to_delete .= ")";
                $to_delete = str_replace(", )", ")", $to_delete);
                $post_ids = $wpdb->get_col("SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key = 'cyberseo_rss_source' AND meta_value IN {$to_delete}");
                if (count($post_ids) > 0) {
                    foreach ($post_ids as $post_id) {
                        if (get_option(CSYN_KEEP_IMAGES) == "on") {
                            csyn_delete_post_media($post_id);
                        }
                        wp_delete_post($post_id, true);
                        $posts_deleted++;
                        echo(str_repeat(' ', 1024));
                        flush();
                    }
                }
            }
            $feeds_deleted = 0;
            if ($delele_feeds) {
                $feeds = [];
                $feeds_updated = [];
                $feeds_cnt = count($this->feeds);
                for ($i = 0; $i < $feeds_cnt; $i++) {
                    if (!in_array($i, $feed_ids)) {
                        $id = array_push($feeds, $this->feeds[$i]);
                        if (isset($this->feeds_updated[$i])) {
                            $feeds_updated[$id] = $this->feeds_updated[$i];
                        } else {
                            $feeds_updated[$id] = $this->feeds[$i]['updated'];
                        }
                    } else {
                        $feeds_deleted++;
                    }
                }
                $this->feeds = $feeds;
                $this->feeds_updated = $feeds_updated;
            }
            update_option(CSYN_SYNDICATED_FEEDS, $this->feeds);
            update_option(CSYN_FEEDS_UPDATED, $this->feeds_updated);
            echo " " . $feeds_deleted . " feeds, " . $posts_deleted . " posts deleted.</p></div>";
        }
    }

    function serializeFeeds($feed_ids) {
        $feeds_cnt = count($feed_ids);
        $feeds = [];
        $feeds_cnt = count($this->feeds);
        for ($i = 0; $i < $feeds_cnt; $i++) {
            if (in_array($i, $feed_ids)) {
                $feeds[] = $this->feeds[$i];
            }
        }
        echo serialize($feeds);
    }

    function unserializeFeeds($file) {
        $new_feeds = @unserialize($file);
        if (isset($new_feeds[0]) && is_array($new_feeds) && count($new_feeds) && stripos($new_feeds[0]['url'], 'http') !== false) {
            echo '<div id="message" class="updated fade"><p>';
            echo 'Importing feeds from file...<br />';
            foreach ($new_feeds as $feed) {
                $cnt = count($this->feeds);
                $replaced = false;
                for ($i = 0; $i < $cnt; $i++) {
                    if ($this->feeds[$i]['url'] == $feed['url']) {
                        $this->feeds[$i] = $feed;
                        if (!is_object($this->feeds[$i]['url'])) {
                            echo '<a href="' . $this->feeds[$i]['url'] . '" target="_blank"><b>' . $this->feeds[$i]['title'] . '</b></a> has been replaced.<br />';
                        } else {
                            echo '<b>' . $this->feeds[$i]['title'] . '</b> has been replaced.<br />';
                        }
                        $replaced = true;
                        break;
                    }
                }
                if (!$replaced) {
                    $this->feeds[] = $feed;
                    if (!is_object($this->feeds[$i]['url'])) {
                        echo '<a href="' . $this->feeds[$i]['url'] . '" target="_blank"><b>' . $this->feeds[$i]['title'] . '</b></a> has been added.<br />';
                    } else {
                        echo '<b>' . $this->feeds[$i]['title'] . '</b> has been added.<br />';
                    }
                }
            }
            echo "</div></p>";
            for ($i = 0; $i < count($this->feeds); $i++) {
                $this->init_feed_options($this->feeds[$i]['options']);
            }
            update_option(CSYN_SYNDICATED_FEEDS, $this->feeds);
        }
    }

    function insertPost() {
        global $csyn_images_to_attach;
        $media_urls = [];
        if (strpos($this->post['post_content'], '</p>') === 0) {
            $this->post['post_content'] = substr($this->post['post_content'], 4);
        }
        if (strpos($this->post['post_excerpt'], '</p>') === 0) {
            $this->post['post_excerpt'] = substr($this->post['post_excerpt'], 4);
        }
        if (!mb_strlen(trim($this->post['post_title']))) {
            if (mb_strlen($this->post['post_excerpt'])) {
                $text = strip_tags($this->post['post_excerpt']);
            } else {
                $text = strip_tags($this->post['post_content']);
            }
            $this->post['post_title'] = substr($text, 0, strrpos(substr($text, 0, 35), ' ')) . '...';
        }
        if ($this->show_report) {
            echo(str_repeat(' ', 1024));
            flush();
        }
        if ($this->current_feed['options']['embed_videos'] == 'on') {
            if (strpos($this->post['link'], '.youtube.com/') !== false || strpos($this->post['link'], '//youtube.com/') !== false) {
                $this->post['post_excerpt'] = htmlentities($this->post['media_description'], ENT_QUOTES, 'UTF-8');
                $this->post['post_content'] = $this->post['link'] . "\n" . $this->post['post_excerpt'];
            } elseif (strpos($this->post['link'], '.vimeo.com/') !== false || strpos($this->post['link'], '//vimeo.com/') !== false) {
                preg_match('/\/(\d+)$/', $this->post['link'], $matches);
                $this->post['guid'] = $this->post['link'] = 'https://vimeo.com/' . $matches[1];
                $content = str_replace('\n', '', html_entity_decode(csyn_file_get_contents($this->post['link'])));
                preg_match('/,"embedUrl":"(.*?)","name":"(.*?)","description":"(.*?)",/is', $content, $matches);
                $this->post['post_title'] = stripslashes($matches[2]);
                $this->post['post_excerpt'] = stripslashes($matches[3]);
                $this->post['post_content'] = '<p><iframe src="' . $matches[1] . '" width="640" height="360" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe></p>' . $this->post['post_excerpt'];
            } elseif (strpos($this->post['link'], '.flickr.com/') !== false || strpos($this->post['link'], '//flickr.com/') !== false) {
                $this->post['post_excerpt'] = $this->post['post_content'] = $this->post['link'] . "\n<br />" . strip_tags($this->post['post_content'], '<br>,<b>,<p>,<a>');
            } elseif (strpos($this->post['link'], '.ign.com/') !== false || strpos($this->post['link'], '//ign.com/') !== false) {
                $content = csyn_file_get_contents($this->post['link'], false, '', 'self', CSYN_CURL_USER_AGENT);
                preg_match('/"url":"(https:[-\/\.a-z0-9]+\.mp4)","width":1920/', $content, $matches);
                if (isset($matches[1])) {
                    $this->post['post_content'] = '<p>[video src="' . $matches[1] . '"]</p><br /><p>' . $this->post['post_excerpt'] . '</p>';
                } else {
                    return;
                }
            } elseif (strpos($this->post['link'], '.dailymotion.com/') !== false || strpos($this->post['link'], '//dailymotion.com/') !== false) {
                $this->post['post_excerpt'] = $this->post['post_content'] = $this->post['link'] . "\n<br />" . strip_tags($this->post['post_excerpt'], '<br>,<b>,<p>,<a>');
            }
        }
        if (!mb_strlen(trim($this->post['post_excerpt'])) && mb_strlen(trim($this->post['media_description']))) {
            $this->post['post_excerpt'] = $this->post['media_description'];
        }
        if (!mb_strlen(trim($this->post['post_content'])) && mb_strlen(trim($this->post['post_excerpt']))) {
            $this->post['post_content'] = $this->post['post_excerpt'];
        }
        if (!strlen($this->post['link']) && isset($this->xml_tags['url']['val'])) {
            $this->post['link'] = $this->xml_tags['url']['val'];
        }
        if ($this->current_feed['options']['extract_full_articles'] == 'on' && get_option(CSYN_FULL_TEXT_EXTRACTOR) != '' && isset($this->post['link'])) {
            $post = $this->post;
            csyn_escape_guid($post, $this->document_type);
            if (!csyn_post_exists($post)) {
                $feed = csyn_file_get_contents(get_option(CSYN_FULL_TEXT_EXTRACTOR) . '?url=' . urlencode($this->post['link']));
                preg_match_all('/<description>(.*?)<\/description>/is', $feed, $matches);
                if (isset($matches[1][1]) && strpos($matches[1][1], '[unable to retrieve full-text content]') === false) {
                    $this->post['post_content'] = str_replace('<p>[embedded content]</p>', '', $matches[1][1]);
                    $this->post['post_content'] = html_entity_decode($matches[1][1]);
                } else {
                    return;
                }
            }
        }
        if (!isset($this->post['tags_input']) || !is_array($this->post['tags_input'])) {
            $this->post['tags_input'] = [];
        }
        $cat_ids = $this->getCategoryIds($this->post['categories']);
        if (empty($cat_ids) && $this->current_feed['options']['undefined_category'] == 'drop') {
            return;
        }
        if (($this->current_feed['options']['article_forge'] == 'on') && $this->current_feed['options']['article_forge_position'] == 'replace') {
            $this->post['options'][] = "bypass_singularity_check";
            $this->post['guid'] = 'http://www.articleforge.com/' . time();
        }
        $cybersyn_post_name = sanitize_title($this->post['post_title']);
        if (isset($this->post['options']) && in_array('bypass_singularity_check', $this->post['options'])) {
            csyn_escape_guid($this->post, $this->document_type);
            $result_dup = false;
        } else {
            csyn_escape_guid($this->post, $this->document_type);
            $result_dup = csyn_post_exists($this->post);
            if ($this->current_feed['options']['push_up'] == 'on') {
                wp_delete_post($result_dup, true);
                $result_dup = false;
            }
        }
        if (!$result_dup && csyn_check_files()) {
            $post_categories = [];
            if (is_array($this->current_feed['options']['post_category'])) {
                $post_categories = $this->current_feed['options']['post_category'];
            }
            if (!empty($cat_ids)) {
                $post_categories = array_merge($post_categories, $cat_ids);
            } elseif ($this->current_feed['options']['undefined_category'] == 'use_default' && empty($post_categories)) {
                $post_categories[] = get_option('default_category');
            }
            $post_categories = array_unique($post_categories);
            $this->post['post_category'] = $post_categories;
            if ($this->current_feed['options']['create_tags'] == 'on') {
                $this->post['tags_input'] = array_merge($this->post['tags_input'], $this->post['categories']);
            }
            if ($this->current_feed['options']['post_tags'] != '') {
                $tags = explode(',', $this->current_feed['options']['post_tags']);
                $this->post['tags_input'] = array_merge($this->post['tags_input'], $tags);
            }
            if ($this->current_feed['options']['article_forge'] == 'on') {
                $ch = curl_init('https://af.articleforge.com/api/initiate_article');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                $sub_keywords = $this->current_feed['options']['article_forge_sub_keywords'];
                if ($this->current_feed['options']['article_forge_tags_as_subkeywords'] == 'on') {
                    $sub_keywords = (mb_strlen($sub_keywords) ? ',' : '') . implode(',', $this->post['tags_input']);
                    if (!mb_strlen(trim($this->current_feed['options']['article_forge_keyword'])) && count($this->post['tags_input'])) {
                        $this->current_feed['options']['article_forge_keyword'] = $this->post['tags_input'][0];
                    }
                }
                curl_setopt($ch, CURLOPT_POSTFIELDS, 'key=' . $this->current_feed['options']['article_forge_api_key']
                        . '&keyword=' . $this->current_feed['options']['article_forge_keyword']
                        . '&sub_keywords=' . $sub_keywords
                        . '&length=' . $this->current_feed['options']['article_forge_length']
                        . '&quality=' . $this->current_feed['options']['article_forge_quality']
                        . '&turing_spinner=' . $this->current_feed['options']['article_forge_turing_spinner']
                        . '&rewrite_sentence=' . $this->current_feed['options']['article_forge_rewrite_sentence']
                        . '&rearrange_sentence=' . $this->current_feed['options']['article_forge_rearrange_sentence']
                        . '&shuffle_paragraphs=' . $this->current_feed['options']['article_forge_shuffle_paragraphs']
                        . '&image=' . $this->current_feed['options']['article_forge_image']
                        . '&video=' . $this->current_feed['options']['article_forge_video']
                        . '&title=1');
                $result = json_decode(curl_exec($ch), true);
                curl_close($ch);
                if ($result['status'] == 'Success') {
                    do {
                        sleep(3);
                        $ch = curl_init('https://af.articleforge.com/api/get_api_progress');
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, 'key=' . $this->current_feed['options']['article_forge_api_key'] . '&ref_key=' . $result['ref_key']);
                        $status = json_decode(curl_exec($ch), true);
                        curl_close($ch);
                    } while ($status['api_status'] != '201');
                    $ch = curl_init('https://af.articleforge.com/api/get_api_article_result');
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, 'key=' . $this->current_feed['options']['article_forge_api_key'] . '&ref_key=' . $result['ref_key']);
                    $result = json_decode(curl_exec($ch), true);
                    curl_close($ch);
                    if ($result['status'] == 'Success') {
                        $article_id = $result['article_id'];
                        preg_match('/<h1>(.*?)<\/h1>(.*?)$/is', $result['article'], $matches);
                        if ($this->current_feed['options']['article_forge_title'] == 'generated') {
                            $this->post['post_title'] = $matches[1];
                        }
                        $article = $matches[2];
                        if ($this->current_feed['options']['article_forge_spintax_view'] == 'on') {
                            $ch = curl_init('https://af.articleforge.com/api/view_article');
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                            curl_setopt($ch, CURLOPT_POST, 1);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, 'key=' . $this->current_feed['options']['article_forge_api_key']
                                    . '&article_id=' . $article_id
                                    . '&spintax_view=1');
                            $result = json_decode(curl_exec($ch), true);
                            curl_close($ch);
                            if ($result['status'] == 'Success' && isset($result['data'])) {
                                $article = $result['data'];
                            }
                        }
                        if ($this->current_feed['options']['article_forge_position'] == 'below') {
                            $this->post['post_content'] .= $article;
                        } elseif ($this->current_feed['options']['article_forge_position'] == 'above') {
                            $this->post['post_content'] = $article . $this->post['post_content'];
                        } elseif ($this->current_feed['options']['article_forge_position'] == 'replace') {
                            $this->post['post_content'] = $article;
                        }
                        $ch = curl_init('https://af.articleforge.com/api/delete_article');
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, 'key=' . $this->current_feed['options']['article_forge_api_key'] . '&article_id=' . $article_id);
                        curl_exec($ch);
                        curl_close($ch);
                    }
                }
                if ($result['status'] != 'Success') {
                    if ($this->current_feed['options']['article_forge_position'] == 'replace') {
                        return;
                    }
                }
            }
            if ($this->current_feed['options']['translator'] != 'none') {
                if (!is_array($this->post['categories'])) {
                    $this->post['categories'] = [];
                }
                if (!is_array($this->post['tags_input'])) {
                    $this->post['tags_input'] = [];
                }
                $packet = ' ' . $this->post['post_title'] . ' ' . CSYN_BLOCK_DIVIDER . ' ' . $this->post['post_content'] . ' ' . CSYN_BLOCK_DIVIDER . ' ' . $this->post['post_excerpt'] . ' ' . CSYN_BLOCK_DIVIDER . ' ' . implode(',', $this->post['categories']) . ' ' . CSYN_BLOCK_DIVIDER . ' ' . implode(',', $this->post['tags_input']) . ' ' . CSYN_BLOCK_DIVIDER;
                if ($this->current_feed['options']['translator'] == 'yandex_translate') {
                    $packet = csyn_yandex_translate($this->current_feed['options']['yandex_api_key'], $packet, $this->current_feed['options']['yandex_translation_dir']);
                } elseif ($this->current_feed['options']['translator'] == 'google_translate') {
                    $packet = csyn_google_translate($this->current_feed['options']['google_api_key'], $packet, $this->current_feed['options']['google_translation_source'], $this->current_feed['options']['google_translation_target']);
                }
                if ($packet === false || $packet === '') {
                    return;
                }
                $translated = explode(CSYN_BLOCK_DIVIDER, $packet);
                $this->post['post_title'] = $translated[0];
                $this->post['post_content'] = $translated[1];
                $this->post['post_excerpt'] = $translated[2];
                $this->post['categories'] = explode(',', $translated[3]);
                $this->post['tags_input'] = explode(',', $translated[4]);
            }
            if ($this->current_feed['options']['base_date'] == 'syndication') {
                $post_date = time();
            } else {
                $post_date = ((int) $this->post['post_date']);
            }
            $post_date += 60 * ($this->current_feed['options']['date_min'] + mt_rand(0, $this->current_feed['options']['date_max'] - $this->current_feed['options']['date_min']));
            $this->post['post_date'] = addslashes(gmdate('Y-m-d H:i:s', $post_date + 3600 * (int) get_option('gmt_offset')));
            $this->post['post_modified'] = $this->post['post_date'];
            $this->post['post_date_gmt'] = addslashes(gmdate('Y-m-d H:i:s', $post_date));
            $this->post['post_modified_gmt'] = $this->post['post_date_gmt'];
            $this->post['post_status'] = $this->current_feed['options']['post_status'];
            $this->post['comment_status'] = $this->current_feed['options']['comment_status'];
            $this->post['ping_status'] = $this->current_feed['options']['ping_status'];
            if (!isset($this->post['post_type'])) {
                $this->post['post_type'] = $this->current_feed['options']['post_type'];
            }
            if (!isset($this->post['post_author']) || $this->post['post_author'] == '') {
                if ($this->current_feed['options']['post_author'] == 0) {
                    $wp_user_search = get_users();
                    shuffle($wp_user_search);
                    $this->post['post_author'] = $wp_user_search[0]->ID;
                } else {
                    $this->post['post_author'] = $this->current_feed['options']['post_author'];
                }
            }
            if (!isset($this->post['media_thumbnail'][0]) && $this->post['enclosure_url'] != '' && stripos($this->post['enclosure_type'], 'image/') !== false) {
                $this->post['media_thumbnail'][0] = $this->post['enclosure_url'];
            }
            if (!isset($this->post['media_thumbnail'][0]) && isset($this->post['media_content'][0]) && $this->post['media_content'][0] != '') {
                $this->post['media_thumbnail'][0] = $this->post['media_content'][0];
            }
            $attachment = '';
            if ($this->current_feed['options']['insert_media_attachments'] != 'no') {
                $attachment = '';
                $video_extensions = wp_get_video_extensions();
                if ($this->post['enclosure_url'] != '') {
                    $attachment .= '<div class="media_block">';
                    $ext = mb_strtolower(pathinfo($this->post['enclosure_url'], PATHINFO_EXTENSION));
                    if (in_array($ext, $video_extensions)) {
                        $attachment .= '<video controls src="' . $this->post['enclosure_url'] . '"';
                        if (isset($this->post['media_thumbnail'][0])) {
                            $attachment .= ' poster="' . $this->post['media_thumbnail'][0] . '"';
                        }
                        $attachment .= '></video>';
                    } else {
                        if (in_array($this->post['enclosure_type'], array('audio/mpeg', 'audio/ogg', 'audio/wav'))) {
                            $attachment .= '<audio controls><source src="' . $this->post['enclosure_url'] . '" type="' . $this->post['enclosure_type'] . '"></audio>';
                        } elseif (stripos($this->post['enclosure_type'], 'image/') !== false) {
                            $attachment .= '<img src="' . $this->post['enclosure_url'] . '">';
                        }
                    }
                    $attachment .= '</div>';
                } else {
                    if (sizeof($this->post['media_content'])) {
                        $attachment .= '<div class="media_block">';
                        for ($i = 0; $i < sizeof($this->post['media_content']); $i++) {
                            $ext = mb_strtolower(pathinfo($this->post['media_content'][$i], PATHINFO_EXTENSION));
                            if (in_array($ext, $video_extensions)) {
                                $attachment .= '<video controls src="' . $this->post['media_content'][$i] . '"';
                                if (isset($this->post['media_thumbnail'][$i])) {
                                    $attachment .= ' poster="' . $this->post['media_thumbnail'][$i] . '"';
                                }
                                $attachment .= '></video>';
                            } elseif (isset($this->post['media_thumbnail'][$i])) {
                                $attachment .= '<a href="' . $this->post['media_content'][$i] . '"><img src="' . $this->post['media_thumbnail'][$i] . '" class="media_thumbnail"></a>';
                            } else {
                                $attachment .= '<img src="' . $this->post['media_content'][$i] . '" class="media_thumbnail">';
                            }
                        }
                        $attachment .= '</div>';
                    } elseif (sizeof($this->post['media_thumbnail'])) {
                        $attachment .= '<div class="media_block">';
                        for ($i = 0; $i < sizeof($this->post['media_thumbnail']); $i++) {
                            $attachment .= '<img src="' . $this->post['media_thumbnail'][$i] . '" class="media_thumbnail">';
                        }
                        $attachment .= '</div>';
                    }
                }
            }
            if ($attachment != '') {
                if ($this->current_feed['options']['insert_media_attachments'] == "top") {
                    $this->post['post_content'] = $attachment . $this->post['post_content'];
                    $this->post['post_excerpt'] = $attachment . $this->post['post_excerpt'];
                } elseif ($this->current_feed['options']['insert_media_attachments'] == "bottom") {
                    $this->post['post_content'] .= $attachment;
                    $this->post['post_excerpt'] .= $attachment;
                }
            }
            $this->post['post_content'] = preg_replace("/<a.*?http:\/\/feeds.wordpress.com\/.*?<\/a>/", '', $this->post['post_content']);
            $this->post['post_excerpt'] = preg_replace("/<a.*?http:\/\/feeds.wordpress.com\/.*?<\/a>/", '', $this->post['post_excerpt']);
            $this->post['post_content'] = preg_replace("/<img.*?http:\/\/stats.wordpress.com\/.*?>/", '', $this->post['post_content']);
            $this->post['post_excerpt'] = preg_replace("/<img.*?http:\/\/stats.wordpress.com\/.*?>/", '', $this->post['post_excerpt']);
            preg_match_all('/<img(.+?)src=[\'\"](.+?)[\'\"](.*?)>/is', $this->post['post_content'] . $this->post['post_excerpt'], $matches);
            $image_urls = $matches[2];
            preg_match_all('/<img.*?srcset=[\'\"](.+?)[\'\"].*?>/is', $this->post['post_content'] . $this->post['post_excerpt'], $matches);
            if (count($matches[1])) {
                foreach ($matches[1] as $item) {
                    preg_match_all('/(.+?)\s+.+?[\,\'\"]/is', $item, $srcsets);
                    if (count($srcsets[1])) {
                        foreach ($srcsets[1] as $link) {
                            $image_urls[] = trim($link);
                        }
                    }
                }
            }
            $image_urls = array_values(array_unique($image_urls));
            if ($this->current_feed['options']['store_images'] == 'on') {
                $home = get_option('home');
                if (count($image_urls)) {
                    for ($i = 0; $i < count($image_urls); $i++) {
                        if (isset($image_urls[$i]) && strpos($image_urls[$i], $home) === false && strpos($image_urls[$i], '//') != 0) {
                            $new_image_url = $media_urls[] = csyn_save_image($image_urls[$i], $this->post['post_title']);
                            $this->post['post_content'] = str_replace($image_urls[$i], $new_image_url, $this->post['post_content']);
                            $this->post['post_excerpt'] = str_replace($image_urls[$i], $new_image_url, $this->post['post_excerpt']);
                            if ($this->show_report) {
                                echo(str_repeat(' ', 1024));
                                flush();
                            }
                        }
                    }
                }
            }
            if ($this->current_feed['options']['set_thumbnail'] == 'first_image') {
                if (isset($image_urls) && count($image_urls)) {
                    $post_thumb_src = $image_urls[0];
                }
            } elseif ($this->current_feed['options']['set_thumbnail'] == 'last_image') {
                if (isset($image_urls) && count($image_urls)) {
                    $post_thumb_src = $image_urls[count($image_urls) - 1];
                }
            } elseif ($this->current_feed['options']['set_thumbnail'] == 'random_image') {
                if (isset($image_urls) && count($image_urls)) {
                    $post_thumb_src = $image_urls[mt_rand(0, count($image_urls) - 1)];
                }
            } elseif ($this->current_feed['options']['set_thumbnail'] == 'media_attachment' && isset($this->post['media_thumbnail'][0])) {
                $post_thumb_src = trim($this->post['media_thumbnail'][0]);
            }
            if (isset($post_thumb_src)) {
                if ($this->current_feed['options']['use_fifu'] == 'on') {
                    $image_url = $post_thumb_src;
                } else {
                    $image_url = $media_urls[] = csyn_save_image($post_thumb_src, $this->post['post_title']);
                }
            }
            $inc_footerss = $this->current_feed['options']['include_post_footers'];
            $title = $this->post['post_title'];
            $content = csyn_fix_white_spaces($this->post['post_content']);
            $excerpt = csyn_fix_white_spaces($this->post['post_excerpt']);
            $packet = ' ' . $title . ' ' . CSYN_BLOCK_DIVIDER . ' ' . $content . ' ';
            if (strlen(trim($excerpt))) {
                $packet .= CSYN_BLOCK_DIVIDER . ' ' . $excerpt . ' ';
            }
            $packet = csyn_morph_content($packet);
            if (substr_count($packet, CSYN_BLOCK_DIVIDER)) {
                $spun_post = explode(CSYN_BLOCK_DIVIDER, $packet);
                $title = $spun_post[0];
                $content = $spun_post[1];
                if (isset($spun_post[2])) {
                    $excerpt = $spun_post[2];
                }
            }
            if ($this->current_feed['options']['preserve_titles'] == "on") {
                $this->post['post_title'] = addslashes($this->post['post_title']);
            } else {
                $this->post['post_title'] = addslashes($title);
            }
            $this->post['post_name'] = $this->post['post_title'];
            $this->post['post_content'] = addslashes(csyn_modify_post_content($content, false));
            $this->post['post_excerpt'] = addslashes(csyn_modify_post_content($excerpt, false, $inc_footerss));
            if (is_numeric($this->current_feed['options']['shorten_excerpts'])) {
                if ($this->current_feed['options']['shorten_excerpts'] > 0) {
                    $words = explode(' ', strip_tags($this->post['post_excerpt']));
                    $this->post['post_excerpt'] = implode(' ', array_slice($words, 0, floor($this->current_feed['options']['shorten_excerpts']) + 1)) . '...';
                } else {
                    $this->post['post_excerpt'] = '';
                }
            }
            $this->post['tags_input'] = array_values(array_unique($this->post['tags_input']));
            if ($this->current_feed['options']['sanitize'] != 'on') {
                remove_filter('content_save_pre', 'wp_filter_post_kses');
                remove_filter('excerpt_save_pre', 'wp_filter_post_kses');
            }
            if (has_action('wpml_switch_language')) {
                if ($this->current_feed['options']['wpml_language'] == '') {
                    do_action('wpml_switch_language', null);
                } else {
                    do_action('wpml_switch_language', $this->current_feed['options']['wpml_language']);
                }
            }
            if (!strlen(trim($this->post['post_content'])) && !strlen(trim($this->post['post_excerpt']))) {
                csyn_delete_media_by_url($media_urls);
                return;
            }
            $post_id = @wp_insert_post($this->post, true);
            if (!is_wp_error($post_id)) {
                if (!is_object($this->current_feed['url'])) {
                    $res = add_post_meta($post_id, 'cyberseo_rss_source', $this->current_feed['url']);
                } else {
                    $res = add_post_meta($post_id, 'cyberseo_rss_source', $this->current_feed['url']->get_id());
                }
                if ($res) {
                    $wp_insert_post_error = false;
                } else {
                    $wp_insert_post_error = 'Can\'t save the feed source URL.';
                }
            } else {
                $wp_insert_post_error = 'Internal WordPress error. ' . $post_id->get_error_message($post_id->get_error_code());
            }
            if ($wp_insert_post_error) {
                if ($this->show_report) {
                    echo '<br />' . $wp_insert_post_error . "<br />";
                }
                $wp_upload_dir = wp_upload_dir();
                if (count($media_urls)) {
                    $media_urls = array_values(array_unique($media_urls));
                    foreach ($media_urls as $url) {
                        preg_match("/\/wp-content\/(.*?)$/", $url, $link_match);
                        preg_match("/.*?\/wp-content\//", $wp_upload_dir['path'], $path_match);
                        if (isset($path_match[0]) && isset($link_match[1])) {
                            @unlink($path_match[0] . $link_match[1]);
                        } else {
                            @unlink(str_replace($wp_upload_dir['url'], $wp_upload_dir['path'], $url));
                        }
                    }
                }
                @wp_delete_post($post_id, true);
                return;
            } else {
                if ($this->current_feed['options']['post_format'] != 'default') {
                    set_post_format($post_id, $this->current_feed['options']['post_format']);
                }
                add_post_meta($post_id, 'cyberseo_post_name', $cybersyn_post_name);
                add_post_meta($post_id, 'cyberseo_post_link', $this->post['link']);
                if (count($csyn_images_to_attach)) {
                    $attach_ids = [];
                    foreach ($csyn_images_to_attach as $image) {
                        if (strlen(trim($image['url']))) {
                            if ($image['title'] != '') {
                                $attach_id = csyn_add_image_to_library($image['url'], $image['title'], $post_id);
                            } else {
                                $attach_id = csyn_add_image_to_library($image['url'], stripslashes($this->post['post_title']), $post_id);
                            }
                            if ($attach_id) {
                                $attach_ids[] = $attach_id;
                            }
                        }
                    }
                    if ($this->current_feed['options']['set_thumbnail'] == 'first_image') {
                        $image_url = $attach_ids[0];
                        set_post_thumbnail($post_id, $image_url);
                    } elseif ($this->current_feed['options']['set_thumbnail'] == 'last_image') {
                        $image_url = $attach_ids[count($attach_ids) - 1];
                        set_post_thumbnail($post_id, $image_url);
                    } elseif ($this->current_feed['options']['set_thumbnail'] == 'random_image') {
                        $image_url = $attach_ids[rand(0, count($attach_ids) - 1)];
                        set_post_thumbnail($post_id, $image_url);
                    }
                }
                if ($this->current_feed['options']['set_thumbnail'] != 'no_thumb') {
                    if (isset($image_url)) {
                        if ($this->current_feed['options']['use_fifu'] != 'on') {
                            $thumb_id = csyn_attach_post_thumbnail($post_id, $image_url, $this->post['post_title']);
                        } else {
                            if (function_exists('fifu_dev_set_image')) {
                                $thumb_id = fifu_dev_set_image($post_id, $image_url);
                            }
                        }
                    }
                    if (isset($post_thumb_src)) {
                        add_post_meta($post_id, 'cyberseo_thumb_source', $post_thumb_src);
                    }
                    if ($this->current_feed['options']['require_thumbnail'] == 'on' && (!isset($thumb_id) || $thumb_id === false)) {
                        wp_delete_post($post_id, true);
                        return;
                    }
                }
                $this->count++;
                $this->failure = false;
            }
            if (has_action('wpml_switch_language')) {
                do_action('wpml_switch_language', null);
            }
        }
    }

    function getCategoryIds($category_names) {
        global $wpdb;
        $cat_ids = [];
        if (is_array($category_names)) {
            foreach ($category_names as $cat_name) {
                if (function_exists('term_exists')) {
                    $cat_id = term_exists($cat_name, 'category');
                    if ($cat_id) {
                        $cat_ids[] = $cat_id['term_id'];
                    } elseif ($this->current_feed['options']['undefined_category'] == 'create_new') {
                        $term = wp_insert_term($cat_name, 'category');
                        if (!is_wp_error($term) && isset($term['term_id'])) {
                            $cat_ids[] = $term['term_id'];
                        }
                    }
                } else {
                    $cat_name_escaped = addslashes($cat_name);
                    $results = $wpdb->get_results("SELECT cat_ID FROM {$wpdb->prefix}categories WHERE (LOWER(cat_name) = LOWER('$cat_name_escaped'))");
                    if ($results) {
                        foreach ($results as $term) {
                            $cat_ids[] = (int) $term->cat_ID;
                        }
                    } elseif ($this->current_feed['options']['undefined_category'] == 'create_new') {
                        if (function_exists('wp_insert_category')) {
                            $cat_id = wp_insert_category(array('cat_name' => $cat_name));
                        } else {
                            $cat_name_sanitized = sanitize_title($cat_name);
                            $wpdb->query("INSERT INTO {$wpdb->prefix}categories SET cat_name='$cat_name_escaped', category_nicename='$cat_name_sanitized'");
                            $cat_id = $wpdb->insert_id;
                        }
                        $cat_ids[] = $cat_id;
                    }
                }
            }
        }
        if ((count($cat_ids) != 0)) {
            $cat_ids = array_unique($cat_ids);
        }
        return $cat_ids;
    }

    function categoryChecklist($post_id = 0, $descendents_and_self = 0, $selected_cats = false) {
        wp_category_checklist($post_id, $descendents_and_self, $selected_cats);
    }

    function showSettings($islocal, $settings) {
        ?>
        <form name="feed_settings" action="<?php echo preg_replace('/\&edit-feed-id\=[0-9]+/', '', csyn_REQUEST_URI()); ?>" method="post">
            <ul class="tabs">
                <li class="active" rel="basic">Basic</li>
                <li rel="advanced">Advanced</li>
                <li rel="media_handling">Media handling</li>
            </ul>
            <div id="basic" class="tab_content">
                <br />
                <table class="form-table">
                    <?php
                    if ($islocal) {
                        if (($this->document_type == 'Instagram' || $this->document_type == 'Twitter') && !$this->edit_existing) {
                            $settings['insert_media_attachments'] = 'top';
                            $settings['store_images'] = 'on';
                        }
                        ?>
                        <tr>
                            <th scope="row">Feed title</th>
                            <td>
                                <input type="text" name="feed_title" style="width:100%" value="<?php echo ($this->edit_existing) ? $this->feeds[(int) $_GET["edit-feed-id"]]['title'] : $this->feed_title; ?>">
                                <p class="description">A title of feed to be used in CyberSEO Lite Syndicator.</p>
                            </td>
                        </tr>
                        <?php if (is_string($this->current_feed_url)) { ?>
                            <tr>
                                <th scope="row">Feed URL</th>
                                <td>
                                    <?php
                                    if (preg_match(CSYN_DUMMY_FEED_PATTERN, $this->current_feed_url)) {
                                        echo '<input type="text" name="url" style="width:100%" value="a dummy feed (no URL)" readonly>';
                                    } else {
                                        echo '<input type="text" name="url" style="width:100%" value="' . htmlspecialchars($this->current_feed_url) . '">';
                                    }
                                    ?>
                                    <p class="description">The URL of the syndicating feed.</p>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                    <tr>
                        <th scope="row">Check for duplicate posts by</th>
                        <td>
                            <select name="duplicate_check_method" size="1">
                                <?php
                                echo '<option ' . (($settings["duplicate_check_method"] == "guid_and_title") ? 'selected ' : '') . 'value="guid_and_title">GUID and title</option>';
                                echo '<option ' . (($settings["duplicate_check_method"] == "guid") ? 'selected ' : '') . 'value="guid">GUID only</option>';
                                echo '<option ' . (($settings["duplicate_check_method"] == "title") ? 'selected ' : '') . 'value="title">Title only</option>';
                                echo '<option ' . (($settings["duplicate_check_method"] == "none") ? 'selected ' : '') . 'value="none">Don\'t check for duplicate posts</option>';
                                ?>
                            </select>
                            <p class="description">Choose the method to skip existing posts.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post type</th>
                        <td>
                            <select name="post_type">
                                <?php
                                $post_types = get_post_types();
                                foreach ($post_types as $post_type) {
                                    echo '<option ' . (($settings["post_type"] == $post_type) ? 'selected ' : '') . 'value="' . $post_type . '">' . $post_type;
                                }
                                ?>
                            </select>
                            <p class="description">Select WordPress <a href="https://developer.wordpress.org/themes/basics/post-types/" target="_blank">post type</a>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post format</th>
                        <td>
                            <select name="post_format">
                                <?php
                                echo '<option ' . (($settings["post_format"] == "default") ? 'selected ' : '') . 'value="default">Default</option>';
                                echo '<option ' . (($settings["post_format"] == "aside") ? 'selected ' : '') . 'value="aside">Aside</option>';
                                echo '<option ' . (($settings["post_format"] == "gallery") ? 'selected ' : '') . 'value="gallery">Gallery</option>';
                                echo '<option ' . (($settings["post_format"] == "link") ? 'selected ' : '') . 'value="link">Link</option>';
                                echo '<option ' . (($settings["post_format"] == "image") ? 'selected ' : '') . 'value="image">Image</option>';
                                echo '<option ' . (($settings["post_format"] == "quote") ? 'selected ' : '') . 'value="quote">Quote</option>';
                                echo '<option ' . (($settings["post_format"] == "status") ? 'selected ' : '') . 'value="status">Status</option>';
                                echo '<option ' . (($settings["post_format"] == "video") ? 'selected ' : '') . 'value="video">Video</option>';
                                echo '<option ' . (($settings["post_format"] == "audio") ? 'selected ' : '') . 'value="audio">Audio</option>';
                                echo '<option ' . (($settings["post_format"] == "chat") ? 'selected ' : '') . 'value="chat">Chat</option>';
                                ?>
                            </select>
                            <p class="description">Set WordPress <a href="https://wordpress.org/support/article/post-formats/" target="_blank">post format</a>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post author</th>
                        <td>
                            <select name="post_author" size="1">
                                <?php
                                $wp_user_search = get_users();
                                foreach ($wp_user_search as $user) {
                                    echo '<option ' . (($settings["post_author"] == $user->ID) ? 'selected ' : '') . 'value="' . $user->ID . '">' . esc_html($user->display_name) . '</option>';
                                }
                                echo '<option ' . (($settings["post_author"] == 0) ? 'selected ' : '') . 'value="0">&lt;random author&gt;';
                                ?>
                            </select>
                            <p class="description">Assign the post author.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Categories</th>
                        <td>
                            <div id="categorydiv">
                                <ul id="categorychecklist" class="list:category categorychecklist form-no-clear">
                                    <div id="categories-all" class="cybersyn-ui-tabs-panel">
                                        <?php
                                        $this->categoryChecklist(NULL, false, $settings['post_category']);
                                        ?>
                                    </div>    
                                </ul>
                            </div>
                            <p class="description">Assign the post to the selected categories.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Undefined categories</th>
                        <td>
                            <select name="undefined_category" size="1">
                                <?php
                                if ($islocal) {
                                    echo '<option ' . (($settings["undefined_category"] == "use_global") ? 'selected ' : '') . 'value="use_global">Use default settings</option>';
                                }
                                echo '<option ' . (($settings["undefined_category"] == "use_default") ? 'selected ' : '') . 'value="use_default">Post to default WordPress category</option>';
                                echo '<option ' . (($settings["undefined_category"] == "create_new") ? 'selected ' : '') . 'value="create_new">Create new categories defined in syndicating post</option>';
                                echo '<option ' . (($settings["undefined_category"] == "drop") ? 'selected ' : '') . 'value="drop">Do not syndicate post that doesn\'t match at least one category defined above</option>';
                                ?>
                            </select>
                            <p class="description">This option defines what the CyberSEO Lite syndicator have to do if none of the post categories mutch the predefined defined ones.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Tags from category names</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="create_tags" ' . (($settings['create_tags'] == 'on') ? 'checked ' : '') . '>when enabled, post category names will be added as post tags.';
                            ?>
                        </td>
                    </tr>
                    <?php
                    if (has_filter('wpml_active_languages')) {
                        $languages = apply_filters('wpml_active_languages', NULL, 'orderby=id&order=desc');
                    } else {
                        $languages = [];
                    }
                    ?>
                    <tr>
                        <th scope="row">WPML language</th>
                        <td>
                            <select name="wpml_language" size="1" if <?php
                            if (!count($languages)) {
                                echo 'disabled';
                            }
                            ?>>
                                        <?php
                                        echo '<option ' . (($settings["wpml_language"] == '') ? 'selected ' : '') . 'value="">Default WPLM language</option>';
                                        echo '<option ' . (($settings["wpml_language"] == 'all') ? 'selected ' : '') . 'value="all">All WPLM languages</option>';
                                        if (count($languages)) {
                                            foreach ($languages as $l) {
                                                echo '<option ' . (($settings["wpml_language"] == $l['language_code']) ? 'selected ' : '') . 'value = "' . $l['language_code'] . '" style = "background-image:url(' . $l['country_flag_url'] . ');">' . $l['native_name'] . '</option>';
                                            }
                                            echo '</select>';
                                        }
                                        ?>
                            </select>
                            <p class="description">Assign a WPML language to every post or page generated from this content source. The <a href="https://www.cyberseo.net/partners/wpml.php" target="_blank">WPML</a> plugin must be installed and activated.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post tags</th>
                        <td>
                            <?php
                            echo '<input type="text" style="width:100%" name="post_tags" value="' . stripslashes($settings['post_tags']) . '">';
                            ?>
                            <p class="description">Separate with commas.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            Check for updates every
                        </th>    
                        <td>    
                            <?php
                            if ($islocal) {
                                echo '<input type="text" name="interval" value="' . $settings['interval'] . '" size="4"> minutes.';
                                echo '<p class="description">If you don\'t need automatic updates, set this parameter to 0.</p>';
                            } else {
                                echo 'Check syndicated feeds for updates every</th><br /><td><input type="text" name="interval" value="' . $settings['interval'] . '" size="4"> minutes. If you don\'t need auto updates, set this parameter to 0.';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Maximum number of posts</th>
                        <td>
                            <?php
                            echo '<input type="text" name="max_items" value="' . $settings['max_items'] . '" size="3">' . '<p class="description">Use low values to decrease the syndication time and improve SEO of your blog.</p>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Republish existing posts</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="push_up" ' . (($settings['push_up'] == 'on') ? 'checked ' : '') . '>if enabled, the existing posts will be republished every time the feed is pulled. Do not enable this option if you are not sure on what you are doing!';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post status</th>
                        <td>
                            <select name="post_status" size="1">
                                <?php
                                echo '<option ' . (($settings["post_status"] == "publish") ? 'selected ' : '') . 'value="publish">Publish immediately</option>';
                                echo '<option ' . (($settings["post_status"] == "pending") ? 'selected ' : '') . 'value="pending">Hold for review</option>';
                                echo '<option ' . (($settings["post_status"] == "draft") ? 'selected ' : '') . 'value="draft">Save as draft</option>';
                                echo '<option ' . (($settings["post_status"] == "private") ? 'selected ' : '') . 'value="private">Save as private</option>';
                                ?>
                            </select></td>
                    </tr>
                    <tr>
                        <th scope="row">Comments</th>
                        <td>
                            <select name="comment_status" size="1">
                                <?php
                                echo '<option ' . (($settings['comment_status'] == 'open') ? 'selected ' : '') . 'value="open">Allow comments on syndicated posts</option>';
                                echo '<option ' . (($settings['comment_status'] == 'closed') ? 'selected ' : '') . 'value="closed">Disallow comments on syndicated posts</option>';
                                ?>
                            </select></td>
                    </tr>
                    <tr>
                        <th scope="row">Pings</th>
                        <td>
                            <select name="ping_status" size="1">
                                <?php
                                echo '<option ' . (($settings['ping_status'] == 'open') ? 'selected ' : '') . 'value="open">Accept pings</option>';
                                echo '<option ' . (($settings['ping_status'] == 'closed') ? 'selected ' : '') . 'value="closed">Don\'t accept pings</option>';
                                ?>
                            </select></td>
                    </tr>
                    <tr>
                        <th scope="row">UTF-8 encoding</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="utf8_encoding" ' . (($settings['utf8_encoding'] == 'on') ? 'checked ' : '') . '>enables UTF-8 encoding.
                            This option converts an ISO-8859-1 string to UTF-8 that may be required when parsing the XML/RSS feeds containing invalid UTF-8 start bytes e.g. <0x92>.';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Convert character encoding</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="convert_encoding" ' . (($settings['convert_encoding'] == 'on') ? 'checked ' : '') . '>enables character encoding conversion. This option might be useful when parsing XML/RSS feeds in national charsets different than UTF-8.';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Sanitize content</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="sanitize" ' . (($settings['sanitize'] == 'on') ? 'checked ' : '') . '>sanitize content for allowed HTML tags for post content.';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Shorten post excerpts</th>
                        <td>
                            <?php
                            echo '<input type="text" name="shorten_excerpts" value="' . $settings['shorten_excerpts'] . '" size="4">';
                            ?>
                            set the max number of words to be left in the post excerpts. Use 0 to remove the excerpts completely or leave it blank to keep the excerpts untouched.
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Base date</th>
                        <td>
                            <select name="base_date" size="1">
                                <?php
                                echo '<option ' . (($settings['base_date'] == 'post') ? 'selected ' : '') . 'value="post">Get date from post</option>';
                                echo '<option ' . (($settings['base_date'] == 'syndication') ? 'selected ' : '') . 'value="syndication">Use syndication date</option>';
                                ?>
                            </select></td>
                    </tr>
                    <tr>
                        <th scope="row">Post date adjustment range</th>
                        <td>
                            <?php
                            echo '<input type="text" name="date_min" value="' . $settings['date_min'] . '" size="6"> .. <input type="text" name="date_max" value="' . $settings['date_max'] . '" size="6">';
                            ?>
                            here you can set the syndication date adjustment range in minutes.
                            <p class="description">This range will be used to randomly adjust the publication date for every aggregated post. For example, if you set the adjustment range as[0..60], the post dates will be increased by a random value between 0 and 60 minutes.</p>
                        </td>
                    </tr>
                </table>
            </div>
            <div id="advanced" class="tab_content">
                <br />
                <table class="form-table">
                    <tr>
                        <th scope="row">Extract full text articles</th>
                            <?php if (get_option(CSYN_FULL_TEXT_EXTRACTOR) != '') { ?>
                            <td>
            <?php echo '<input type="checkbox" name="extract_full_articles" ' . (($settings['extract_full_articles'] == 'on') ? 'checked ' : '') . '>'; ?>
                                when enabled, CyberSEO will try to extract the full articles from shortened RSS feeds.
                                <p class="description"><strong>Important:</strong> if the plugin will not be able to retrieve the full-text article, the post won't be added. <a href="https://www.cyberseo.net/content-syndicator/#extract-full-articles"  target="_blank">Read more....</a></p>
                            </td>
        <?php } else { ?>
                            <td>
                                <input type="checkbox" name="extract_full_articles" disabled>
                                In order to extract full text articles, you must download the <a href="https://www.cyberseo.net/downloads/cybersyn/fivefilters-full-text-rss.zip"  target="_blank">full-text-rss script</a>. Unzip and upload it into the /wp-content/plugins/cybersyn/ directory. After that the full text extraction feature will be instantly available.
                            </td>
        <?php } ?>
                    </tr>
                    <tr>
                        <th scope="row">User agent</th>
                        <td>
                            <?php
                            echo '<input type="text" style="width:100%" name="user_agent" value="' . stripslashes($settings['user_agent']) . '">';
                            echo '<p class="description">Use this field to set a fake <a href="https://en.wikipedia.org/wiki/User_agent" target="_blank">user agent</a>.</p>';
                            ?>
                        </td>
                    </tr>                    
                    <tr>
                        <th scope="row">Translation</th>
                        <td>
                            <select name="translator" size="1" onchange="changeTranslator();">
                                <?php
                                echo '<option ' . (($settings["translator"] == "none") ? 'selected ' : '') . 'value="none">Do not translate</option>';
                                echo '<option ' . (($settings["translator"] == "yandex_translate") ? 'selected ' : '') . 'value="yandex_translate">Use Yandex Translate</option>';
                                echo '<option ' . (($settings["translator"] == "google_translate") ? 'selected ' : '') . 'value="google_translate">Use Google Translate</option>';
                                ?>
                            </select>
                            <p class="description"><strong>Important</strong>: if the plugin will not be able to translate the article, the post won't be added.</p>
                            <table id="yandex_translate_settings" style="width:100%">
                                <tr>
                                    <th>Direction</th>
                                    <td><select name="yandex_translation_dir"> <?php
                                            $langs = CSYN_YANDEX_TRANSLATE_LANGS;
                                            asort($langs);
                                            foreach ($langs as $dir => $lang) {
                                                echo '<option ' . (($settings["yandex_translation_dir"] == $dir) ? 'selected ' : '') . 'value="' . $dir . '">' . $lang . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Yandex API key</th>
                                    <td><?php echo '<input ' . ((CSYN_HIDE_PASSWORDS) ? 'type="password"' : 'type="text"') . ' style="width:100%" name="yandex_api_key" value="' . htmlspecialchars(stripslashes($settings['yandex_api_key']), ENT_QUOTES) . '">'; ?>
                                        <p class="description">Enter your API key above in order to use Yandex Translate.</p>
                                    </td>
                                </tr>
                            </table>
                            <table id="google_translate_settings" style="width:100%">
                                <tr>
                                    <th>Source</th>
                                    <td><select name="google_translation_source">
                                            <?php
                                            $langs = CSYN_GOOGLE_TRANSLATE_LANGS;
                                            asort($langs);
                                            foreach ($langs as $dir => $lang) {
                                                echo '<option ' . (($settings["google_translation_source"] == $dir) ? 'selected ' : '') . 'value="' . $dir . '">' . $lang . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Target</th>
                                    <td><select name="google_translation_target">
                                            <?php
                                            foreach ($langs as $dir => $lang) {
                                                echo '<option ' . (($settings["google_translation_target"] == $dir) ? 'selected ' : '') . 'value="' . $dir . '">' . $lang . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Google API key</th>
                                    <td><?php echo '<input ' . ((CSYN_HIDE_PASSWORDS) ? 'type="password"' : 'type="text"') . ' style="width:100%" name="google_api_key" value="' . htmlspecialchars(stripslashes($settings['google_api_key']), ENT_QUOTES) . '">'; ?>
                                        <p class="description">Enter your API key above in order to use Google Translate. If you don't have one, <a href="https://cloud.google.com/translate/docs/getting-started" target="_blank" title="Get Google API key">get it here</a>. Please note: this is a paid service.</p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Article Forge</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="article_forge" id="article_forge" onchange="cseoChangeArticleForgeState();" ' . (($settings['article_forge'] == 'on') ? 'checked ' : '') . '>';
                            echo '<label for="article_forge">Use the advanced artificial intelligence and deep learning <a href="https://www.cyberseo.net/partners/articleforge.php" target="_blank">Article Forge</a> service to autonatically generate completely unique, on-topic, high-quality articles by a given keyword.</label>';
                            ?>
                            <br /><br />
                            <table id="article_forge_settings">
                                <tr>
                                    <th>Article Forge API key</th>
                                    <td>
        <?php echo '<input ' . ((CSYN_HIDE_PASSWORDS) ? 'type="password"' : 'type="text"') . ' name="article_forge_api_key" value="' . htmlspecialchars(stripslashes($settings['article_forge_api_key']), ENT_QUOTES) . '" size="60">'; ?>
                                        <p class="description">Click here to get your <a href="https://www.cyberseo.net/partners/articleforge.php" target="_blank">Article Forge API key.</a> Please read the <a href="https://www.cyberseo.net/content-syndicator/#article_forge" target="_blank">manual</a>.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Keyword</th>
                                    <td>
        <?php echo '<input type="text" name="article_forge_keyword" value="' . htmlspecialchars(stripslashes($settings['article_forge_keyword']), ENT_QUOTES) . '" size="60">'; ?>
                                        <p class="description">Keyword in should not contain URLs, parentheses, brackets, commas or too many single characters.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Sub keywords</th>
                                    <td>
        <?php echo '<input type="text" name="article_forge_sub_keywords" value="' . htmlspecialchars(stripslashes($settings['article_forge_sub_keywords']), ENT_QUOTES) . '" size="60">'; ?>
                                        <p class="description">A list of sub keywords separated by comma (e.g. subkeyword1,subkeyword2,subkeyword3). Article Forge has a five sub keyword limit per article. If
                                            you enter more than 5 sub keywords, Article Forge will randomly select 5. Article Forge will also ignore any sub keywords longer than 10 characters. Sub Keywords in
                                            should not contain URLs, parentheses, brackets, or too many single characters.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Post tags as sub keys</th>
                                    <td>
                                        <?php
                                        echo '<input type="checkbox" name="article_forge_tags_as_subkeywords" ' . (($settings['article_forge_tags_as_subkeywords'] == 'on') ? 'checked ' : '') . '>when enabled, the post tags (if available) will be used as subkeys for Article Forge.';
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">Spintax view</th>
                                    <td>
                                        <?php
                                        echo '<input type="checkbox" name="article_forge_spintax_view" ' . (($settings['article_forge_spintax_view'] == 'on') ? 'checked ' : '') . '>it is useful to enable this option in order to generate the Spintax version of your article.';
                                        ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Article length</th>
                                    <td>
                                        <select name="article_forge_length" size="1">
                                            <?php
                                            echo '<option ' . (($settings['article_forge_length'] == 'very_short') ? 'selected ' : '') . 'value="very_short">Very short (approximately 50 words)</option>';
                                            echo '<option ' . (($settings['article_forge_length'] == 'short') ? 'selected ' : '') . 'value="short">Short (approximately 200 words)</option>';
                                            echo '<option ' . (($settings['article_forge_length'] == 'medium') ? 'selected ' : '') . 'value="medium">Medium (approximately 500 words)</option>';
                                            echo '<option ' . (($settings['article_forge_length'] == 'long') ? 'selected ' : '') . 'value="long">Long (approximately 750 words)</option>';
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Article quality</th>
                                    <td>
                                        <select name="article_forge_quality" size="1">
                                            <?php
                                            echo '<option ' . (($settings['article_forge_quality'] == '1') ? 'selected ' : '') . 'value="1">Standard</option>';
                                            echo '<option ' . (($settings['article_forge_quality'] == '2') ? 'selected ' : '') . 'value="2">Adventurous</option>';
                                            echo '<option ' . (($settings['article_forge_quality'] == '3') ? 'selected ' : '') . 'value="3">More adventurous</option>';
                                            echo '<option ' . (($settings['article_forge_quality'] == '4') ? 'selected ' : '') . 'value="4">Conservative</option>';
                                            echo '<option ' . (($settings['article_forge_quality'] == '5') ? 'selected ' : '') . 'value="5">More conservative</option>';
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Turing spinner</th>
                                    <td>
                                        <select name="article_forge_turing_spinner" size="1">
                                            <?php
                                            echo '<option ' . (($settings['article_forge_turing_spinner'] == '0') ? 'selected ' : '') . 'value="0">Disabled</option>';
                                            echo '<option ' . (($settings['article_forge_turing_spinner'] == '1') ? 'selected ' : '') . 'value="1">Enabled</option>';
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Rewrite sentence</th>
                                    <td>
                                        <select name="article_forge_rewrite_sentence" size="1">
                                            <?php
                                            echo '<option ' . (($settings['article_forge_rewrite_sentence'] == '0') ? 'selected ' : '') . 'value="0">Disabled</option>';
                                            echo '<option ' . (($settings['article_forge_rewrite_sentence'] == '1') ? 'selected ' : '') . 'value="1">Enabled</option>';
                                            ?>
                                        </select>
                                        <p class="description">This option is not supported since ArticleForge API version 3.0.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Rearrange sentence</th>
                                    <td>
                                        <select name="article_forge_rearrange_sentence" size="1">
                                            <?php
                                            echo '<option ' . (($settings['article_forge_rearrange_sentence'] == '0') ? 'selected ' : '') . 'value="0">Disabled</option>';
                                            echo '<option ' . (($settings['article_forge_rearrange_sentence'] == '1') ? 'selected ' : '') . 'value="1">Enabled</option>';
                                            ?>
                                        </select>
                                        <p class="description">This option is not supported since ArticleForge API version 3.0.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Article position</th>
                                    <td>
                                        <select name="article_forge_position" size="1">
                                            <?php
                                            echo '<option ' . (($settings['article_forge_position'] == 'replace') ? 'selected ' : '') . 'value="replace">Replace the post content</option>';
                                            echo '<option ' . (($settings['article_forge_position'] == 'above') ? 'selected ' : '') . 'value="above">Above the post content</option>';
                                            echo '<option ' . (($settings['article_forge_position'] == 'below') ? 'selected ' : '') . 'value="below">Below the post content</option>';
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Image probability</th>
                                    <td>
                                        <select name="article_forge_image" size="1">
                                            <?php
                                            for ($i = 0; $i <= 10; $i++) {
                                                echo '<option ' . (($settings['article_forge_image'] == $i / 10) ? 'selected ' : '') . 'value="' . ($i / 10) . '">' . ($i * 10) . '%</option>';
                                            }
                                            ?>
                                        </select>
                                        <p class="description">The probability of adding an image into the article.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Video probability</th>
                                    <td>
                                        <select name="article_forge_video" size="1">
                                            <?php
                                            for ($i = 0; $i <= 10; $i++) {
                                                echo '<option ' . (($settings['article_forge_video'] == $i / 10) ? 'selected ' : '') . 'value="' . ($i / 10) . '">' . ($i * 10) . '%</option>';
                                            }
                                            ?>
                                        </select>
                                        <p class="description">The probability of adding a video into the article.</p>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Article title</th>
                                    <td>
                                        <select name="article_forge_title" size="1">
                                            <?php
                                            echo '<option ' . (($settings['article_forge_title'] == 'original') ? 'selected ' : '') . 'value="original">Leave original post title</option>';
                                            echo '<option ' . (($settings['article_forge_title'] == 'generated') ? 'selected ' : '') . 'value="generated">Use generated Article Forge title</option>';
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Content spinner</th>
                        <td>
                            <select name="spinner" size="1">
                                <?php
                                echo '<option ' . (($settings['spinner'] == CSYN_DISABLE_SPINNER) ? 'selected ' : '') . 'value="' . CSYN_DISABLE_SPINNER . '">Disable</option>';
                                echo '<option ' . (($settings['spinner'] == CSYN_SPINNERCHIEF) ? 'selected ' : '') . 'value="' . CSYN_SPINNERCHIEF . '">SpinnerChief</option>';
                                echo '<option ' . (($settings['spinner'] == CSYN_SPINREWRITER) ? 'selected ' : '') . 'value="' . CSYN_SPINREWRITER . '">SpinRewriter</option>';
                                echo '<option ' . (($settings['spinner'] == CSYN_CHIMPREWRITER) ? 'selected ' : '') . 'value="' . CSYN_CHIMPREWRITER . '">ChimpRewriter</option>';
                                echo '<option ' . (($settings['spinner'] == CSYN_WORDAI) ? 'selected ' : '') . 'value="' . CSYN_WORDAI . '">WordAi</option>';
                                echo '<option ' . (($settings['spinner'] == CSYN_XSPINNER) ? 'selected ' : '') . 'value="' . CSYN_XSPINNER . '">X-Spinner</option>';
                                ?>
                            </select>
                            <p class="description">Select a desired text spinner, which must be configured on the <a href="https://www.cyberseo.net/content-spinners/" target="_blank">Content Spinners</a> page.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Don't synonymize titles</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="preserve_titles" ' . (($settings['preserve_titles'] == 'on') ? 'checked ' : '') . '>enable this option to avoid post title synonymization.';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post footers</th>
                        <td>
                            <?php
                            echo '<textarea cols="90" rows="10" wrap="off" name="post_footer" style="margin:0;height:10em;width:100%;">' . stripslashes($settings['post_footer']) . '</textarea>';
                            echo '<p class="description">You may have a several versions of post footer. In such a case your HTML code chunks have to be separated with <strong>&lt;!--more--&gt;</strong> divider.
                                    These changes will be randomly inserted into the posts. <a href="https://www.cyberseo.net/content-syndicator/#headers-and-footers" target="_blank">Read more....</a></p>';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Insert post footers into excerpts</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="include_post_footers" ' . (($settings['include_post_footers'] == 'on') ? 'checked ' : '') . '>enable this option if you want the post footers to be inserted into excerpts.';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
            <div id="media_handling" class="tab_content">       
                <br />
                <table class="form-table">
                    <tr>	
                        <th scope="row">Store images locally</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="store_images" ' . (($settings['store_images'] == 'on') ? 'checked ' : '') . '>if enabled, all images from the syndicating feeds will be copied into the default uploads folder.';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><a name="media-attachments"></a>Media attachments</th>
                        <td>
                            <select name="insert_media_attachments" size="1">
                                <?php
                                echo '<option ' . (($settings["insert_media_attachments"] == "no") ? 'selected ' : '') . 'value="no">Do not insert attachments</option>';
                                echo '<option ' . (($settings["insert_media_attachments"] == "top") ? 'selected ' : '') . 'value="top">Insert attachments at the top of the post</option>';
                                echo '<option ' . (($settings["insert_media_attachments"] == "bottom") ? 'selected ' : '') . 'value="bottom">Insert attachments at the bottom of the post</option>';
                                ?>
                            </select>
                            <p class="description">If enabled the CyberSEO Lite syndicator will insert media
                                attachments (if available) into the aggregating post. The
                                following types of attachments are supported: <strong>&lt;media:content&gt;</strong>,
                                <strong>&lt;media:thumbnail&gt;</strong> and <strong>&lt;enclosure&gt;.</strong>
                                All the aggregated images will contain <strong>class="media_thumbnail"</strong>
                                in the <strong>&lt;img&gt;</strong> tag.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post thumbnails</th>
                        <td>
                            <select name="set_thumbnail" size="1">
                                <?php
                                echo '<option ' . (($settings["set_thumbnail"] == "no_thumb") ? 'selected ' : '') . 'value="no_thumb">Do not create</option>';
                                echo '<option ' . (($settings["set_thumbnail"] == "first_image") ? 'selected ' : '') . 'value="first_image">Create from the first post image</option>';
                                echo '<option ' . (($settings["set_thumbnail"] == "last_image") ? 'selected ' : '') . 'value="last_image">Create from the last post image</option>';
                                echo '<option ' . (($settings["set_thumbnail"] == "random_image") ? 'selected ' : '') . 'value="random_image">Create from a random post image</option>';
                                echo '<option ' . (($settings["set_thumbnail"] == "media_attachment") ? 'selected ' : '') . 'value="media_attachment">Create from the image media attachment</option>';
                                ?>
                            </select>
                            <p class="description">Select the source image for the post thumbnail.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Use FIFU</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="use_fifu" id="use_fifu" ' . (($settings['use_fifu'] == 'on') ? 'checked ' : '') . '> when enabled, the post thumbnail won\'t be stored locally.
                                It will be hotlinked and displayed by the <a href="https://www.cyberseo.net/partners/fifu.php" target="_blank">FIFU</a> plugin, which must be installed and activated.';
                            if (!function_exists('fifu_dev_set_image')) {
                                echo '<p class="description" id="fifu_warning">&#x26A0; <strong>Warning:</strong> FIFU is not detected. If you enable this option, the post thumbnail will not be generated. Please install and activate FIFU first.</p>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Post thumbnail is required</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="require_thumbnail" ' . (($settings['require_thumbnail'] == 'on') ? 'checked ' : '') . '> if the plugin will not be able to create post thumbnail
                                as specified above (e.g. the source image is missing or broken), the post will not be published!';
                            ?>
                        </td>
                    </tr>					
                    <tr>
                        <th scope="row">Embed videos</th>
                        <td>
                            <?php
                            echo '<input type="checkbox" name="embed_videos" ' . (($settings['embed_videos'] == 'on') ? 'checked ' : '');
                            ?>
                            inserts tube video embeds into the post. Supported feed sources: YouTube, Vimeo, Flickr, IGN, DailyMotion.
                            <p class="description">Video feed examples:
                                <a href="https://www.youtube.com/feeds/videos.xml?user=vevo" target="_blank">https://www.youtube.com/feeds/videos.xml?user=vevo</a>,
                                <a href="https://vimeo.com/channels/wefoundthese/videos/rss" target="_blank">https://vimeo.com/channels/wefoundthese/videos/rss</a></p>
                        </td>
                    </tr>					
                </table>			
            </div>					
            <?php
            echo '<div class="submit">';
            if ($islocal) {
                if ($this->edit_existing) {
                    echo '<input class="button-primary" name="update_feed_settings" value="Update Feed Settings" type="submit">&nbsp;&nbsp;';
                    echo '<input class="button" name="cancel" value="Cancel" type="submit">';
                    echo '<input type="hidden" name="feed_id" value="' . (int) $_GET["edit-feed-id"] . '">';
                } else {
                    echo '<input class="button-primary" name="syndicate_feed" value="Syndicate This Feed" type="submit">&nbsp;&nbsp;';
                    echo '<input class="button" name="cancel" value="Cancel" type="submit">';
                    if (is_object($this->current_feed_url)) {
                        echo '<input type="hidden" name="feed_url" value="' . base64_encode(gzcompress(serialize($this->current_feed_url))) . '">';
                    } else {
                        echo '<input type="hidden" name="feed_url" value="' . htmlspecialchars($this->current_feed_url) . '">';
                    }
                }
            } else {
                echo '<input class="button-primary" name="update_default_settings" value="Update default settings" type="submit">';
            }
            echo "</div>";
            wp_nonce_field('xml_syndicator');
            ?>
        </form>
        <script type='text/javascript'>
            changeTranslator();
            changeArticleForgeState();
        </script>
        <?php
    }

    function getUpdateTime($id) {
        $time = time();
        $interval = 60 * (int) $this->feeds[$id]['options']['interval'];
        if (isset($this->feeds_updated[$id])) {
            $updated = (int) $this->feeds_updated[$id];
        } else {
            $updated = (int) $this->feeds[$id]['updated'];
        }
        if ($this->feeds[$id]['options']['interval'] == 0) {
            return "never";
        } elseif (($time - $updated) >= $interval) {
            return "asap";
        } else {
            return "in " . (int) (($interval - ($time - $updated)) / 60) . " minutes";
        }
    }

    function showMainPage($showsettings = true) {
        ?>
        <div class="metabox-holder postbox-container" style="width:100%;">
            <?php
            if (!function_exists('get_plugin_data')) {
                require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            }
            $plugin_data = get_plugin_data(DIRNAME(__FILE__) . "/cybersyn.php");
            echo csyn_file_get_contents('https://www.cyberseo.net/info/CyberSEO/ad-lite.php?site=' . urlencode(site_url()) . '&plugin_ver=' . $plugin_data['Version']);
            ?>
            <form action="<?php echo csyn_REQUEST_URI(); ?>" method="post">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            RSS/Atom source:
                        </th>
                        <td>
                            <input type="text" style="width:100%;" name="feed_url" value="">
                        </td>
                        <td>
                            <span style="width:100%;"><input class="button-primary" name="new_feed" value="&nbsp; Syndicate &raquo; &nbsp;" type="submit"></span>
                        </td>
                    </tr>
                </table>
                <?php wp_nonce_field('xml_syndicator'); ?>
            </form>
            <form id="syndycated_feeds" action="<?php echo csyn_REQUEST_URI(); ?>" method="post">
                <?php
                if (count($this->feeds) > 0) {
                    $display_feeds = [];
                    for ($i = 0; $i < count($this->feeds); $i++) {
                        $feed_item = '<tr>';
                        $feed_item .= '<th><input name="feed_ids[]" value="' . $i . '" type="checkbox"></th>';
                        $feed_item .= '<td>' . $this->feeds[$i]['title'] . ' [<a href="' . csyn_REQUEST_URI() . '&edit-feed-id=' . $i . '">edit</a>]</td>';
                        if (is_string($this->feeds[$i]['url'])) {
                            if (preg_match(CSYN_DUMMY_FEED_PATTERN, $this->feeds[$i]['url'])) {
                                $feed_item .= '<td>-</td>';
                            } else {
                                $feed_item .= '<td><a href="' . $this->feeds[$i]['url'] . '" target="_blank">' . csyn_chop_str(htmlspecialchars($this->feeds[$i]['url']), 100) . '</a></td>';
                            }
                        }
                        $feed_item .= '<td>' . $this->getUpdateTime($i) . '</td>';
                        if (isset($this->feeds_updated[$i])) {
                            $last_update = $this->feeds_updated[$i];
                        } else {
                            $last_update = $this->feeds[$i]['updated'];
                        }
                        if ($last_update) {
                            $feed_item .= '<td>' . intval((time() - $last_update) / 60) . ' minutes ago</td>';
                        } else {
                            $feed_item .= '<td> - </td>';
                        }
                        $feed_item .= '</tr>';
                        $display_feeds[] .= '<!--' . $this->feeds[$i]['title'] . $i . '-->' . $feed_item . PHP_EOL;
                    }
                    if (get_option(CSYN_SORT_FEED_SOURCES) == 'name') {
                        asort($display_feeds);
                    }
                    echo '<table class="widefat" style="margin-top: .5em" width="100%">';
                    echo '<tr style="background: #f0f0f0;">';
                    echo '<th scope="row" style="width:3%;"><input type="checkbox" onclick="checkAllLs(document.getElementById(\'syndycated_feeds\'));"></th>';
                    echo '<th scope="row" style="font-weight: 600; width:25%;">Feed title</th>';
                    echo '<th scope="row" style="font-weight: 600; width:50%;">URL</th>';
                    echo '<th scope="row" style="font-weight: 600; width:10%;">Next update</th>';
                    echo '<th scope="row" style="font-weight: 600; width:12%;">Last update</th>';
                    echo "</tr>";
                    $i = 0;
                    foreach ($display_feeds as $item) {
                        if ($i++ % 2) {
                            $item = str_replace('<tr>', '<tr class="alternate">', $item);
                        }
                        echo $item;
                    }
                    echo "</table>";
                    ?>
                    &nbsp;
                    <table width="100%">
                        <tr>
                            <td>
                                <div align="left">
                                    <input class="button-primary" name="check_for_updates" value="Pull selected feeds now!" type="submit">
                                </div>
                            </td>
                            <td>
                                <div align="right">
                                    <input class="button secondary" name="delete_feeds_and_posts" value="Delete selected feeds and syndicated posts" type="submit">
                                    <input class="button secondary" name="delete_feeds" value="Delete selected feeds" type="submit">
                                    <input class="button secondary" name="delete_posts" value="Delete posts syndycated from selected feeds" type="submit">
                                </div>
                            </td>
                        </tr>
                    </table>
                    <?php
                }
                ?>
                <table width="100%">
                    <tr>
                        <td>
                            <div align="right">
                                <input class="button secondary" name="alter_default_settings" value="Alter default settings" type="submit">
                            </div>
                        </td>
                    </tr>
                </table>
                <?php
                wp_nonce_field('xml_syndicator');
                ?>
            </form>
            <?php
            if ($showsettings) {
                $this->showSettings(false, $this->global_options);
            }
            ?>
        </div>
        <?php
    }

}

function csyn_admin_head() {
    ?>
    <style type="text/css">
        .error a {
            color: #100;
        }
        div.cybersyn-ui-tabs-panel {
            margin: 0;
            padding-left: 6pt;
            max-height: 13em;
            width: 50%;
            overflow: auto;
            border: 1px solid #666;
            background-color: white;
        }
        ul.tabs {
            margin: 0;
            padding: 0;
            float: left;
            list-style: none;
            height: 32px;
            border-bottom: 1px solid #DDD;
            border-left: 1px solid #DDD;
            width: 100%;
        }
        ul.tabs li {
            float: left;
            margin: 0;
            cursor: pointer;
            padding: 0px 21px ;
            height: 31px;
            line-height: 31px;
            border: 1px solid #DDD;
            border-left: none;
            font-weight: bold;
            background: #EEE;
            overflow: hidden;
            position: relative;
        }
        ul.tabs li:hover {
            background: #DDD;
        }
        ul.tabs li.active{
            background: #FFF;
            border-bottom: 1px solid #FFF;
        }
        .tab_container {
            -webkit-box-shadow:inset 0px 0px 0px 1px #DDD;
            -moz-box-shadow:inset 0px 0px 0px 1px #DDD;
            box-shadow:inset 0px 0px 0px 1px #DDD;
            clear: both;
            float: left;
            width: 100%;
            background: #FFF;
        }
        .tab_content {
            padding: 20px;
            display: none;
        }
        .cseo-button {
            text-decoration: none;
            cursor: pointer;
            color: #333;
            padding: 4pt 8pt;
            border-style: solid;
            border-color: #2271b1;
            background-color: #fff;
            border-width: 1pt;
            border-radius: 3pt;
        }
        .cseo-button:hover {
            background-color: #eee;
        }
    </style>
    <script type="text/javascript">
        jQuery(document).ready(function () {
            jQuery(".tab_content").hide();
            jQuery(".tab_content:first").show();
            jQuery("ul.tabs li").click(function () {
                jQuery("ul.tabs li").removeClass("active");
                jQuery(this).addClass("active");
                jQuery(".tab_content").hide();
                var activeTab = jQuery(this).attr("rel");
                jQuery("#" + activeTab).show();
            });
        });
        function checkAllLs(form) {
            for (i = 0, n = form.elements.length; i < n; i++) {
                if (form.elements[i].type === "checkbox" && !(form.elements[i].getAttribute('onclick', 2))) {
                    if (form.elements[i].checked === true)
                        form.elements[i].checked = false;
                    else
                        form.elements[i].checked = true;
                }
            }
        }
        function checkAll(form)
        {
            for (i = 0, n = form.elements.length; i < n; i++) {
                if (form.elements[i].type === "checkbox") {
                    form.elements[i].checked = true;
                }
            }
        }
        function uncheckAll(form)
        {
            for (i = 0, n = form.elements.length; i < n; i++) {
                if (form.elements[i].type === "checkbox") {
                    form.elements[i].checked = false;
                }
            }
        }
        function inverseSelection(form)
        {
            for (i = 0, n = form.elements.length; i < n; i++) {
                if (form.elements[i].type === "checkbox") {
                    if (form.elements[i].checked === true)
                        form.elements[i].checked = false;
                    else
                        form.elements[i].checked = true;
                }
            }
        }
        function changeMode() {
            if (general_settings.<?php echo CSYN_RSS_PULL_MODE; ?>.value === "auto") {
                auto.style.display = "block";
                cron.style.display = "none";
            } else {
                auto.style.display = "none";
                cron.style.display = "block";
            }
        }
        function switchQODS() {
            if (expert_box_override.style.display === "none") {
                expert_box_override.style.display = "block";
                show_override_box.style.display = "none";
                hide_override_box.style.display = "inline";
            } else {
                expert_box_override.style.display = "none";
                show_override_box.style.display = "inline";
                hide_override_box.style.display = "none";
            }
        }
        function changeTranslator() {
            yandex_translate_settings.style.display = "none";
            google_translate_settings.style.display = "none";
            if (feed_settings.translator.value === "yandex_translate") {
                yandex_translate_settings.style.display = 'inline';
            }
            if (feed_settings.translator.value === "google_translate") {
                google_translate_settings.style.display = 'inline';
            }
        }
        function changePreviewMode() {
            switch (preview_mode_switch.value) {
                case "post_view":
                    post_view.style.display = "block";
                    attachment_view.style.display = "none";
                    break;
                case "attachment_view":
                    post_view.style.display = "none";
                    attachment_view.style.display = "block";
                    break;
            }
        }
        function changeArticleForgeState() {
            if (document.getElementById("article_forge").checked) {
                article_forge_settings.style.display = "inline";
            } else {
                article_forge_settings.style.display = "none";
            }
        }
    </script>
    <?php
}

function csyn_site_head() {
    ?>
    <style type="text/css">
        #cseo-product-gallery {
            width: 500pt;
            margin: 0 auto;
            padding: 20pt;
            border-color: #ccc;
            border-width: 1pt;
            border-style: solid;
            border-radius: 4pt;
        }
        #cseo-product-galley-fullimage {
            list-style: none;
            width: auto;
            height: 400pt;
            margin: 0pt;
            padding: 0pt;
            overflow: hidden;
        }
        #cseo-product-galley-fullimage li img {
            display: block;
            margin: 0 auto;
            width: auto;
            height: 400pt;
        }
        #cseo-product-galley-thumbimage {
            list-style: none;
            overflow: hidden;
            float: left;
        }
        #cseo-product-galley-thumbimage li {
            float: left;
        }
        #cseo-product-galley-thumbimage li img {
            position:relative;
            float: left;
            border: 1pt solid white;
            opacity: 0.7;
            width: auto;
            height: 50pt;
            border-style: solid;
            border-width: 1px;
            border-color: transparent;
        }
        #cseo-product-galley-thumbimage li img:hover {
            opacity: 1;
            border-style: solid;
            border-color: #eee;
        }
        .cseo-product-galley-button {
            font-family: Arial,Helvetica,sans-serif;
            font-size: 32pt;
            font-weight: bold;
            box-shadow: 1pt 1pt 1pt 0 rgba(0, 0, 0, 0.4);
            border-radius :12pt;
            background-image: linear-gradient(#ffe700, #ff9700);
            text-decoration: none !important;
            cursor: pointer;
            color: black !important;
            border-width: 2pt;
            border-style: solid;
            border-color: #ff9100;
            padding: 12pt 28pt;
        }
        .cseo-product-galley-button:hover {
            margin: 1pt 1pt;
            color: black;
            background-image: linear-gradient(#ffd700, #ff8700);
        }
    </style>
    <?php
}

function csyn_hide_thumbnail($html) {
    if (is_single() || is_page()) {
        return '';
    } else {
        return $html;
    }
}

function csyn_page_template_redirect() {
    if (isset($_GET['out'])) {
        wp_redirect(html_entity_decode(csyn_xor(base64_decode(urldecode($_GET['out'])), get_option(CSYN_RAND_SHA))));
        exit();
    }
}

if (get_option('cxxx_hide_images') !== false) {
    if (get_option('cxxx_hide_images') == 'on') {
        update_option(CSYN_POST_IMAGES, 'hide_all');
    }
}
if (get_option('cxxx_hide_first_image') !== false) {
    delete_option('cxxx_hide_first_image');
}
if (get_option('cxxx_morphing_syntax_rules') !== false) {
    delete_option('cxxx_morphing_syntax_rules');
}
if (get_option(CSYN_ENABLE_DEBUG_MODE) == 'on') {
    error_reporting(-1);
    ini_set('display_errors', 'On');
}
if (is_admin()) {
    csyn_default_options();
}
$csyn_syndicator = new CyberSyn_Syndicator();
if (!is_admin()) {
    add_filter('cron_schedules', 'csyn_add_cuctom_cron_interval');
    add_filter('get_the_guid', 'csyn_fake_guid');
    add_action('wp_head', 'csyn_site_head');
    if (isset($_GET['pull-feeds']) && $_GET['pull-feeds'] == get_option(CSYN_CRON_MAGIC)) {
        require_once(ABSPATH . 'wp-admin/includes/taxonomy.php');
        add_action('shutdown', 'csyn_update_feeds');
    }
    if (get_option(CSYN_CANONICAL_LINK) == 'on') {
        remove_action('wp_head', 'rel_canonical');
        add_action('wp_head', 'csyn_rel_canonical');
    }
    if (get_option(CSYN_LINK_TO_SOURCE) == 'on') {
        add_filter('post_link', 'csyn_permalink');
    }
    if (get_option(CSYN_URLS_ENCRYPT) == 'on') {
        add_action('template_redirect', 'csyn_page_template_redirect');
    }
    if (get_option(CSYN_RSS_PULL_MODE) == "auto") {
        if (function_exists('wp_next_scheduled')) {
            add_action('update_by_wp_cron', 'csyn_update_feeds');
            if (!wp_next_scheduled('update_by_wp_cron')) {
                wp_schedule_event(time(), csyn_get_cuctom_cron_interval_name(), 'update_by_wp_cron');
            }
        } else {
            add_action('shutdown', 'csyn_update_feeds');
        }
    } else {
        if (function_exists('wp_clear_scheduled_hook') && wp_next_scheduled('update_by_wp_cron')) {
            wp_clear_scheduled_hook('update_by_wp_cron');
        }
    }
    if (get_option(CSYN_POST_IMAGES) != "keep" || get_option(CSYN_URLS_NOFOLLOW) == "on" || get_option(CSYN_URLS_NOREFERRER) == "on" || get_option(CSYN_URLS_TARGET_BLANK) == "on" || get_option(CSYN_URLS_TARGET_BLANK) == "on") {
        add_filter('the_content', 'csyn_runtime_post_modification');
        add_filter('the_excerpt', 'csyn_runtime_post_modification');
    }
    if (isset($_GET['custom_tags'])) {
        add_action('rss2_item', 'csyn_rss2_item');
    }
    if (get_option(CSYN_POST_IMAGES) == 'hide_featured_in_single') {
        add_filter('post_thumbnail_html', 'csyn_hide_thumbnail');
    }
} else {
    add_action('admin_bar_menu', 'csyn_add_admin_menu_item', 999);
    add_action('admin_head', 'csyn_admin_head');
    add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'csyn_plugins_action_link');
}
register_deactivation_hook(__FILE__, 'csyn_deactivation');
if (get_option(CSYN_KEEP_IMAGES) != "on") {
    add_action('before_delete_post', 'csyn_delete_post_media');
}

function csyn_upgrade_to_pro_menu() {
    // empty
}

function cybersyn_fix_menu_url($url) {
    if (preg_match('/(?:cyberseo_lite_upgrade_to_premium)$/i', $url)) {
        remove_filter('clean_url', 'cybersyn_fix_menu_url', 10);
        return 'https://www.cyberseo.net/';
    }
    return $url;
}

function csyn_main_menu() {
    $icon = 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dy'
            . 'YXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIg'
            . 'eD0iMHB4IiB5PSIwcHgiIHdpZHRoPSIyMHB4IiBoZWlnaHQ9IjIwcHgiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZW5hYmxlLWJhY2tncm91bmQ9Im5ldyAwIDAgMjAgMjAiIHhtbDpzcGFjZT0icHJlc2VydmUiPiAgPGltYWdlIGlkPSJpbWFnZTAiIHdp'
            . 'ZHRoPSIyMCIgaGVpZ2h0PSIyMCIgeD0iMCIgeT0iMCIKICAgIGhyZWY9ImRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBQlFBQUFBVUNBTUFBQUM2ViswL0FBQUFCR2RCVFVFQUFMR1BDL3hoQlFBQUFDQmpTRkpO'
            . 'CkFBQjZKZ0FBZ0lRQUFQb0FBQUNBNkFBQWRUQUFBT3BnQUFBNm1BQUFGM0NjdWxFOEFBQUIrMUJNVkVYLy8vLzE5UFB5OHZERHY3YSsKdWJYeDhPL3o4L0w3K3ZxN3Nxdkl3cm4vL3Y2dnFabll5N0w0OU8zczZ1YWNsSURaMWRLcG9ZN0h3Ny9Jdzc5'
            . 'N2RXMmNsSC9OdnAzZgp6ck9xbzVIRXdMVGkyY2Z0NDlQTnliNi91YkQyOVBQT3lzYnU3ZTN3OE8zYTFNcjYrUGZCdkxqVHpzank4ZkRmM05uaTROdnk4T3paCjF0RC8vLy8vLy8vNit2bng4TzcvL3Y3cDUrUDE4L0w5L1B2dzcrejUrZmYvLy8vLy8v'
            . 'Ly8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8KLy8vLy92Ly8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLwovLy8wOC9QKy9mMy8vdjcxOVBQLy8vLy8vLy9Qd0tMLy8vLy8v'
            . 'Ly8zOS9hNnQ3VEx5TVgwOC9QMDlQVFF6Y3ZlMmRhNnRyUDI5dlgvCi8vL2V6N1N3cXBucDV0L3o4L0oyY0dpdnFxWHY3Kzd4OFBDdnFxWHk4ZkgvLy8vLy8vL3Q2dVc5dDZqMDlQTC8vLy8vLy8vLy8vLzcKKy92UXpzdnA1K2ZGd3IvNStmbi8vLy82'
            . 'K3ZyQ3dMem01T1BMeWNmNit2ci8vLy8yOXZYbjV1TC8vLy8vLy8vLy8vLysvZjMvLy8vLwovLy85L1B6Ly8vL3M2K2VtbjQzZjJzNy8vLy8vLy8vLy8vLy8vLy8vLy8vbTRkYXpyWjMvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vCi8vLy8vLy8vLy8v'
            . 'Ly8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLzRjWTlkQUFBQXFIUlNUbE1BQUFBQUFBQUEKQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFCZTlKYUZZRldFUGJxK0RRVmM2RnpRd1Z0aGdMVzB1R0JvT1Ridkt4OFBGWW1W'
            . 'awpaVjhyS2RiUjJOTE16MmhtYVd4clc5Q2l4bVZUYlRZT1o5ZkxTa3ZJWlNzREpXVTdCekNQdlFFRHRWd0ZXMjQzUlIrV3FsblYwRjBYClg4M09aekFMS21ZelRZV3RXdFREMDJwZlVFY1pjTTFFSXpBNU54SklKREl0eXh4WVl6RUhVbmgxZERvOExB'
            . 'VWluRkZ4QUFBQUFXSkwKUjBRQWlBVWRTQUFBQUFsd1NGbHpBQUFMRXdBQUN4TUJBSnFjR0FBQUFBZDBTVTFGQitZRkhRVXFOVmxKbU8wQUFBRW1TVVJCVkJqVApZMkFnR2pBQ0FST3pySnk4Z3FLU3Nnb0xLeHNRUUdUWU9WVFYxRFUwdFRpNUVLcTFk'
            . 'WFQxOUEwTWpZeE5UTTFnWXVZV2xsYldsamEyCmRyYjJEbzVPRURGbkt4ZFhOM2NQVHk5dkgxOGZQMjlUb0JBM2o3OUxnRlZna0tlSHQxZHdpTDFYYUJndkh3Ti9lRVJrVkxSQVRLeG4KUkZ4OFFtSlNhSEtLSUVOcW1tMWtlb1pRWnBhclQzYU9zRWh1'
            . 'WG41QklVTlJjVWxwV1hsRlpWVjFSRTF0WFgxRGFLTjVFME56UzJ0YgpkVUI3UUllN1Q2ZFhWMFJFYUdOM0QwTnZuM2RidjBkMWdNK0VpWk84dlNLOGZTZFBtY29nS21icjB1L2g0Ums2YmZvTWh3aHY3OURKCjRoSU1rbEl6WjdWVlYzdTJnYlJIUkhS'
            . 'NnpaYVdBYmwranMwc1MwdkxXZDRPRGc3ZWMrZEJ2VGwvd2NKRml4Y3ZYZ0lFUzVjdEp6NkEKY1FFQWlIcFU2aEQ2eHNjQUFBQWxkRVZZZEdSaGRHVTZZM0psWVhSbEFESXdNakl0TURVdE1qbFVNREk2TkRJNk5UTXJNRE02TURDcQp6QkV5QUFBQUpY'
            . 'UkZXSFJrWVhSbE9tMXZaR2xtZVFBeU1ESXlMVEExTFRJNVZEQXlPalF5T2pVekt6QXpPakF3MjVHcGpnQUFBQUJKClJVNUVya0pnZ2c9PSIgLz4KPC9zdmc+Cg==';
    add_menu_page('Feed Syndicator', 'CyberSEO Lite', 'manage_options', 'cybersyn', 'csyn_xml_syndicator_menu', $icon);
    add_submenu_page('cybersyn', 'General Settings', 'General Settings', 'manage_options', 'cybersyn_general_settings', 'csyn_options_menu');
    add_submenu_page('cybersyn', 'Content Spinners', 'Content Spinners', 'manage_options', 'cybersyn_synonymizer', 'csyn_synonymizer_menu');
    add_submenu_page('cybersyn', 'Upgrade To Premium', "<strong style=\"color: #FCB214;\">Get CyberSEO Pro</strong> &#x2B50;", "manage_options", "cyberseo_lite_upgrade_to_premium", 'csyn_upgrade_to_pro_menu');
    add_filter('clean_url', 'cybersyn_fix_menu_url', 10, 3);
}

if (is_admin()) {
    add_action('admin_menu', 'csyn_main_menu');
}
?>